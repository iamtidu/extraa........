import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/message.dart';

class MessageService {
  static final MessageService _instance = MessageService._internal();
  factory MessageService() => _instance;
  MessageService._internal();

  late SharedPreferences _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // Save message to local storage
  Future<void> saveMessage(Message message) async {
    // Get chat ID: use chatId if available, otherwise use groupId
    String chatId;
    if (message.chatId != null && message.chatId!.isNotEmpty) {
      chatId = message.chatId!;
    } else if (message.groupId != null) {
      chatId = 'group_${message.groupId}';
    } else {
      chatId = 'unknown_chat';
    }
    
    final messages = await getMessages(chatId);
    
    // Add new message
    messages.add(message);
    
    // Keep only last 100 messages per chat
    if (messages.length > 100) {
      messages.removeAt(0);
    }
    
    // Save to storage
    final messagesJson = json.encode(messages.map((msg) => msg.toMap()).toList());
    await _prefs.setString('messages_$chatId', messagesJson);
  }

  // Get messages for a chat
  Future<List<Message>> getMessages(String chatId) async {
    final messagesJson = _prefs.getString('messages_$chatId');
    if (messagesJson == null) return [];
    
    try {
      final List<dynamic> messagesList = json.decode(messagesJson);
      return messagesList.map((msgMap) => Message.fromMap(msgMap)).toList();
    } catch (e) {
      print('Error parsing messages: $e');
      return [];
    }
  }

  // Clear messages for a chat
  Future<void> clearMessages(String chatId) async {
    await _prefs.remove('messages_$chatId');
  }

  // Get all chat IDs with messages
  Future<List<String>> getAllChatIds() async {
    final keys = _prefs.getKeys();
    final chatIds = keys.where((key) => key.startsWith('messages_')).map((key) => 
      key.replaceFirst('messages_', '')
    ).toList();
    
    return chatIds;
  }

  // Get last message for a chat
  Future<Message?> getLastMessage(String chatId) async {
    final messages = await getMessages(chatId);
    return messages.isNotEmpty ? messages.last : null;
  }

  // Get unread message count for a chat
  Future<int> getUnreadCount(String chatId, int lastReadId) async {
    final messages = await getMessages(chatId);
    return messages.where((msg) => msg.id! > lastReadId).length;
  }
}