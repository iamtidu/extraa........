import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/user.dart';
import '../models/friend_request.dart';
import '../models/group.dart';
import '../models/group_member.dart';

class LocalStorageService {
  static final LocalStorageService _instance = LocalStorageService._internal();
  factory LocalStorageService() => _instance;
  LocalStorageService._internal();

  late SharedPreferences _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _initializeTestData();
  }

  void _initializeTestData() {
    if (!_prefs.containsKey('users')) {
      // Insert 4 test users
      final testUsers = [
        User(
          id: 1,
          name: 'Udit Kumar',
          username: 'udit',
          email: 'u@gmail.com',
          password: '123456',
          createdAt: DateTime.now(),
        ),
        User(
          id: 2,
          name: 'Addi',
          username: 'Addi',
          email: 'a@gmail.com',
          password: '123456',
          createdAt: DateTime.now(),
        ),
        User(
          id: 3,
          name: 'Aditya Kumar',
          username: 'charlie',
          email: 'ak@gmail.com',
          password: '12345',
          createdAt: DateTime.now(),
        ),
        User(
          id: 4,
          name: 'Diana Prince',
          username: 'diana',
          email: 'diana@test.com',
          password: 'password123',
          createdAt: DateTime.now(),
        ),
      ];

      _saveUsers(testUsers);
    }
  }

  // User operations
  List<User> _getUsers() {
    final usersJson = _prefs.getString('users');
    if (usersJson == null) return [];
    
    final List<dynamic> usersList = json.decode(usersJson);
    return usersList.map((userMap) => User.fromMap(userMap)).toList();
  }

  void _saveUsers(List<User> users) {
    final usersJson = json.encode(users.map((user) => user.toMap()).toList());
    _prefs.setString('users', usersJson);
  }

  Future<User?> getUserByEmailAndPassword(String email, String password) async {
    final users = _getUsers();
    return users.firstWhere(
      (user) => user.email == email && user.password == password,
      orElse: () => User(
        id: 0,
        name: '',
        username: '',
        email: '',
        password: '',
        createdAt: DateTime.now(),
      ),
    );
  }

  Future<User?> getUserByEmailOrUsername(String email, String username) async {
    final users = _getUsers();
    try {
      return users.firstWhere(
        (user) => user.email == email || user.username == username,
      );
    } catch (e) {
      return null;
    }
  }
// Chat operations
List<Map<String, dynamic>> _getChats() {
  final chatsJson = _prefs.getString('chats');
  if (chatsJson == null) return [];
  
  final List<dynamic> chatsList = json.decode(chatsJson);
  return chatsList.map((chat) => Map<String, dynamic>.from(chat)).toList();
}

void _saveChats(List<Map<String, dynamic>> chats) {
  final chatsJson = json.encode(chats);
  _prefs.setString('chats', chatsJson);
}

Future<List<Map<String, dynamic>>> getChatMessages(String chatId) async {
  final messagesJson = _prefs.getString('messages_$chatId');
  if (messagesJson == null) return [];
  
  final List<dynamic> messagesList = json.decode(messagesJson);
  return messagesList.map((msg) => Map<String, dynamic>.from(msg)).toList();
}

Future<void> saveChatMessage(String chatId, Map<String, dynamic> message) async {
  final messages = await getChatMessages(chatId);
  messages.add(message);
  
  final messagesJson = json.encode(messages);
  _prefs.setString('messages_$chatId', messagesJson);
}
  Future<int> insertUser(User user) async {
    final users = _getUsers();
    final newId = users.isNotEmpty ? users.last.id! + 1 : 1;
    user.id = newId;
    users.add(user);
    _saveUsers(users);
    return newId;
  }

  Future<bool> updateUser(User updatedUser) async {
    final users = _getUsers();
    final index = users.indexWhere((user) => user.id == updatedUser.id);
    if (index != -1) {
      users[index] = updatedUser;
      _saveUsers(users);
      return true;
    }
    return false;
  }

  Future<List<User>> getAllUsersExcept(int excludedUserId) async {
    final users = _getUsers();
    return users.where((user) => user.id != excludedUserId).toList();
  }

  Future<User?> getUserById(int userId) async {
    final users = _getUsers();
    try {
      return users.firstWhere((user) => user.id == userId);
    } catch (e) {
      return null;
    }
  }

  // Friend request operations
  List<FriendRequest> _getFriendRequests() {
    final requestsJson = _prefs.getString('friend_requests');
    if (requestsJson == null) return [];
    
    final List<dynamic> requestsList = json.decode(requestsJson);
    return requestsList.map((reqMap) => FriendRequest.fromMap(reqMap)).toList();
  }

  void _saveFriendRequests(List<FriendRequest> requests) {
    final requestsJson = json.encode(requests.map((req) => req.toMap()).toList());
    _prefs.setString('friend_requests', requestsJson);
  }

  Future<int> sendFriendRequest(int senderId, int receiverId) async {
    final requests = _getFriendRequests();
    final newId = requests.isNotEmpty ? requests.last.id! + 1 : 1;
    
    final request = FriendRequest(
      id: newId,
      senderId: senderId,
      receiverId: receiverId,
      status: 'pending',
      createdAt: DateTime.now(),
    );
    
    requests.add(request);
    _saveFriendRequests(requests);
    return newId;
  }

  Future<List<FriendRequest>> getFriendRequestsForUser(int userId) async {
    final requests = _getFriendRequests();
    return requests.where((req) => req.receiverId == userId && req.status == 'pending').toList();
  }

  Future<bool> updateFriendRequestStatus(int requestId, String status) async {
    final requests = _getFriendRequests();
    final index = requests.indexWhere((req) => req.id == requestId);
    if (index != -1) {
      requests[index].status = status;
      _saveFriendRequests(requests);
      return true;
    }
    return false;
  }

  Future<int?> getFriendRequestIdBetweenUsers(int user1, int user2) async {
  final requests = _getFriendRequests();

  try {
    final req = requests.firstWhere((r) =>
      r.status == 'accepted' &&
      (
        (r.senderId == user1 && r.receiverId == user2) ||
        (r.senderId == user2 && r.receiverId == user1)
      )
    );
    return req.id;
  } catch (e) {
    return null;
  }
}

  Future<List<User>> getFriends(int userId) async {
    final requests = _getFriendRequests();
    final users = _getUsers();
    
    final acceptedRequests = requests.where((req) => 
      req.status == 'accepted' && 
      (req.senderId == userId || req.receiverId == userId)
    ).toList();
    
    final friendIds = acceptedRequests.map((req) => 
      req.senderId == userId ? req.receiverId : req.senderId
    ).toSet();
    
    return users.where((user) => friendIds.contains(user.id)).toList();
  }

  Future<bool> isFriendRequestSent(int senderId, int receiverId) async {
    final requests = _getFriendRequests();
    return requests.any((req) => 
      req.senderId == senderId && 
      req.receiverId == receiverId && 
      req.status == 'pending'
    );
  }

   List<Group> _getGroups() {
    final groupsJson = _prefs.getString('groups');
    if (groupsJson == null) return [];
    
    final List<dynamic> groupsList = json.decode(groupsJson);
    return groupsList.map((groupMap) => Group.fromMap(groupMap)).toList();
  }

  void _saveGroups(List<Group> groups) {
    final groupsJson = json.encode(groups.map((group) => group.toMap()).toList());
    _prefs.setString('groups', groupsJson);
  }

  Future<int> createGroup(String name, String? description, int adminId) async {
    final groups = _getGroups();
    final newId = groups.isNotEmpty ? groups.last.id! + 1 : 1;
    
    final group = Group(
      id: newId,
      name: name,
      description: description,
      adminId: adminId,
      createdAt: DateTime.now(),
    );
    
    groups.add(group);
    _saveGroups(groups);
    return newId;
  }

  Future<bool> updateGroup(Group updatedGroup) async {
    final groups = _getGroups();
    final index = groups.indexWhere((group) => group.id == updatedGroup.id);
    if (index != -1) {
      groups[index] = updatedGroup;
      _saveGroups(groups);
      return true;
    }
    return false;
  }

  Future<bool> deleteGroup(int groupId) async {
    final groups = _getGroups();
    final index = groups.indexWhere((group) => group.id == groupId);
    if (index != -1) {
      groups.removeAt(index);
      _saveGroups(groups);
      
      // Also remove group members
      final members = _getGroupMembers();
      final memberIds = members.where((m) => m.groupId == groupId).map((m) => m.id).toList();
      for (var memberId in memberIds) {
        final memberIndex = members.indexWhere((m) => m.id == memberId);
        if (memberIndex != -1) {
          members.removeAt(memberIndex);
        }
      }
      _saveGroupMembers(members);
      
      return true;
    }
    return false;
  }

  Future<List<Group>> getUserGroups(int userId) async {
    final groups = _getGroups();
    final members = _getGroupMembers();
    
    final userMemberGroups = members
        .where((member) => member.userId == userId && member.status == 'accepted')
        .map((member) => member.groupId)
        .toList();
    
    final userAdminGroups = groups
        .where((group) => group.adminId == userId)
        .map((group) => group.id!)
        .toList();
    
    final allUserGroupIds = {...userMemberGroups, ...userAdminGroups};
    
    return groups.where((group) => allUserGroupIds.contains(group.id)).toList();
  }

  Future<Group?> getGroupById(int groupId) async {
    final groups = _getGroups();
    try {
      return groups.firstWhere((group) => group.id == groupId);
    } catch (e) {
      return null;
    }
  }

  // Group member operations
  List<GroupMember> _getGroupMembers() {
    final membersJson = _prefs.getString('group_members');
    if (membersJson == null) return [];
    
    final List<dynamic> membersList = json.decode(membersJson);
    return membersList.map((memberMap) => GroupMember.fromMap(memberMap)).toList();
  }

  void _saveGroupMembers(List<GroupMember> members) {
    final membersJson = json.encode(members.map((member) => member.toMap()).toList());
    _prefs.setString('group_members', membersJson);
  }

  Future<bool> addGroupMember(int groupId, int userId, String status) async {
    final members = _getGroupMembers();
    final newId = members.isNotEmpty ? members.last.id! + 1 : 1;
    
    final member = GroupMember(
      id: newId,
      groupId: groupId,
      userId: userId,
      status: status,
      joinedAt: status == 'accepted' ? DateTime.now() : null,
    );
    
    members.add(member);
    _saveGroupMembers(members);
    return true;
  }

  Future<bool> removeGroupMember(int groupId, int userId) async {
    final members = _getGroupMembers();
    final index = members.indexWhere((member) => 
      member.groupId == groupId && member.userId == userId
    );
    
    if (index != -1) {
      members.removeAt(index);
      _saveGroupMembers(members);
      return true;
    }
    return false;
  }

  Future<bool> updateGroupMemberStatus(int groupId, int userId, String status) async {
    final members = _getGroupMembers();
    final index = members.indexWhere((member) => 
      member.groupId == groupId && member.userId == userId
    );
    
    if (index != -1) {
      members[index].status = status;
      if (status == 'accepted') {
        members[index].joinedAt = DateTime.now();
      }
      _saveGroupMembers(members);
      return true;
    }
    return false;
  }

  Future<List<User>> getGroupMembers(int groupId) async {
    final members = _getGroupMembers();
    final users = _getUsers();
    
    final memberIds = members
        .where((member) => member.groupId == groupId && member.status == 'accepted')
        .map((member) => member.userId)
        .toList();
    
    return users.where((user) => memberIds.contains(user.id)).toList();
  }

  

  Future<List<Group>> getPendingGroupInvites(int userId) async {
    final groups = _getGroups();
    final members = _getGroupMembers();
    
    final pendingGroupIds = members
        .where((member) => member.userId == userId && member.status == 'pending')
        .map((member) => member.groupId)
        .toSet();
    
    return groups.where((group) => pendingGroupIds.contains(group.id)).toList();
  }
}