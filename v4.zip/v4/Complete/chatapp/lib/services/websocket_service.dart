import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;

class WebSocketService {
  WebSocketChannel? _channel;
  StreamController<Map<String, dynamic>> _messageController = 
      StreamController<Map<String, dynamic>>.broadcast();
  
  final String _serverUrl = 'ws://localhost:8080';
  bool _isConnected = false;
  String? _currentChatId;
  int? _currentUserId;

  Stream<Map<String, dynamic>> get messageStream => _messageController.stream;
  bool get isConnected => _isConnected;
  String? get currentChatId => _currentChatId;

  Future<void> connectToChat(String chatId, int userId, String userName) async {
    try {
      // Disconnect from previous chat if any
      if (_channel != null && _isConnected) {
        _channel!.sink.close();
      }
      
      print('Connecting to WebSocket at $_serverUrl');
      _channel = WebSocketChannel.connect(Uri.parse(_serverUrl));
      _currentChatId = chatId;
      _currentUserId = userId;
      
      // Listen for messages
      _channel!.stream.listen(
        (message) {
          try {
            print('Received WebSocket message: $message');
            final data = Map<String, dynamic>.from(json.decode(message));
            _messageController.add(data);
            
            // Handle connection confirmation
            if (data['type'] == 'connected') {
              _isConnected = true;
              print('WebSocket connected successfully');
              
              // Register for this chat
              _registerForChat(chatId, userId, userName);
              
              // Request message history
              _requestHistory(chatId);
            }
          } catch (e) {
            print('Error parsing WebSocket message: $e');
          }
        },
        onError: (error) {
          print('WebSocket error: $error');
          _isConnected = false;
          _reconnect();
        },
        onDone: () {
          print('WebSocket disconnected');
          _isConnected = false;
          _reconnect();
        },
      );
      
    } catch (e) {
      print('Failed to connect WebSocket: $e');
      _isConnected = false;
      _startMockConnection(chatId, userId, userName);
    }
  }
  
  void _registerForChat(String chatId, int userId, String userName) {
    final registerMessage = {
      'type': 'register',
      'chatId': chatId,
      'userId': userId,
      'userName': userName,
      'timestamp': DateTime.now().toIso8601String(),
    };
    
    sendMessage(registerMessage);
  }
  
  void _requestHistory(String chatId) {
    final historyMessage = {
      'type': 'history',
      'chatId': chatId,
      'timestamp': DateTime.now().toIso8601String(),
    };
    
    sendMessage(historyMessage);
  }
  
  void _reconnect() {
    if (_currentChatId != null && _currentUserId != null) {
      print('Attempting to reconnect in 3 seconds...');
      Timer(Duration(seconds: 3), () {
        connectToChat(_currentChatId!, _currentUserId!, 'User $_currentUserId');
      });
    }
  }
  
  void _startMockConnection(String chatId, int userId, String userName) {
    // Mock connection for testing if server is not running
    print('Using mock WebSocket connection for chat $chatId');
    _isConnected = true;
    
    // Simulate receiving connection confirmation
    Timer(Duration(milliseconds: 500), () {
      _messageController.add({
        'type': 'connected',
        'message': 'Mock connection established',
        'timestamp': DateTime.now().toIso8601String(),
      });
    });
    
    // Simulate receiving messages every 2 seconds
    Timer.periodic(Duration(seconds: 2), (timer) {
      if (!_isConnected) timer.cancel();
      
      _messageController.add({
        'type': 'message',
        'chatId': chatId,
        'senderId': userId == 1 ? 2 : 1,
        'senderName': userId == 1 ? 'Bob' : 'Alice',
        'content': 'This is a mock message from the server',
        'timestamp': DateTime.now().toIso8601String(),
      });
    });
  }

  void sendMessage(Map<String, dynamic> message) {
    if (_channel != null && _isConnected) {
      try {
        print('Sending WebSocket message: $message');
        _channel!.sink.add(json.encode(message));
      } catch (e) {
        print('Error sending message: $e');
      }
    } else {
      print('WebSocket not connected. Message not sent: $message');
    }
  }
  
  void sendTypingIndicator(bool isTyping, String userName) {
    if (_currentChatId != null && _currentUserId != null) {
      final typingMessage = {
        'type': 'typing',
        'chatId': _currentChatId,
        'userId': _currentUserId,
        'userName': userName,
        'isTyping': isTyping,
        'timestamp': DateTime.now().toIso8601String(),
      };
      
      sendMessage(typingMessage);
    }
  }

  void disconnect() {
    _isConnected = false;
    _channel?.sink.close(status.normalClosure);
    _channel = null;
    _currentChatId = null;
    _currentUserId = null;
    print('WebSocket disconnected');
  }
}