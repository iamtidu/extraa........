// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';

// class ApiService {
//   static const String _baseUrl = 'http://10.0.2.2:3000/api'; // For Android emulator
//   // static const String _baseUrl = 'http://localhost:3000/api'; // For iOS simulator
//   // static const String _baseUrl = 'http://YOUR_IP_ADDRESS:3000/api'; // For physical device

//   // Singleton instance
//   static final ApiService _instance = ApiService._internal();
//   factory ApiService() => _instance;
//   ApiService._internal();

//   // Get authorization header
//   Future<Map<String, String>> _getHeaders() async {
//     final prefs = await SharedPreferences.getInstance();
//     final token = prefs.getString('auth_token') ?? '';
    
//     return {
//       'Content-Type': 'application/json',
//       'Authorization': 'Bearer $token',
//     };
//   }

//   // Save token
//   Future<void> saveToken(String token) async {
//     final prefs = await SharedPreferences.getInstance();
//     await prefs.setString('auth_token', token);
//   }

//   // Get token
//   Future<String?> getToken() async {
//     final prefs = await SharedPreferences.getInstance();
//     return prefs.getString('auth_token');
//   }

//   // Remove token (logout)
//   Future<void> removeToken() async {
//     final prefs = await SharedPreferences.getInstance();
//     await prefs.remove('auth_token');
//   }

//   // Generic GET request
//   Future<dynamic> get(String endpoint, {Map<String, String>? queryParams}) async {
//     try {
//       final uri = Uri.parse('$_baseUrl/$endpoint').replace(
//         queryParameters: queryParams,
//       );
      
//       final response = await http.get(
//         uri,
//         headers: await _getHeaders(),
//       );

//       return _handleResponse(response);
//     } catch (e) {
//       throw Exception('Network error: $e');
//     }
//   }

//   // Generic POST request
//   Future<dynamic> post(String endpoint, dynamic data) async {
//     try {
//       final response = await http.post(
//         Uri.parse('$_baseUrl/$endpoint'),
//         headers: await _getHeaders(),
//         body: json.encode(data),
//       );

//       return _handleResponse(response);
//     } catch (e) {
//       throw Exception('Network error: $e');
//     }
//   }

//   // Generic PUT request
//   Future<dynamic> put(String endpoint, dynamic data) async {
//     try {
//       final response = await http.put(
//         Uri.parse('$_baseUrl/$endpoint'),
//         headers: await _getHeaders(),
//         body: json.encode(data),
//       );

//       return _handleResponse(response);
//     } catch (e) {
//       throw Exception('Network error: $e');
//     }
//   }

//   // Generic DELETE request (UPDATED with queryParams)
//   Future<dynamic> delete(String endpoint, {Map<String, String>? queryParams}) async {
//     try {
//       final uri = Uri.parse('$_baseUrl/$endpoint').replace(
//         queryParameters: queryParams,
//       );
      
//       final response = await http.delete(
//         uri,
//         headers: await _getHeaders(),
//       );

//       return _handleResponse(response);
//     } catch (e) {
//       throw Exception('Network error: $e');
//     }
//   }

//   // Handle response
//   dynamic _handleResponse(http.Response response) {
//     final statusCode = response.statusCode;
//     final responseBody = json.decode(response.body);

//     if (statusCode >= 200 && statusCode < 300) {
//       return responseBody;
//     } else {
//       final errorMessage = responseBody['error'] ?? 'Request failed with status: $statusCode';
//       throw Exception(errorMessage);
//     }
//   }
// }

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // Different URLs for different platforms
  static String get _baseUrl {
    // For web platform
    return 'http://localhost:3000/api';
  }

  // Singleton instance
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  // Get authorization header
  Future<Map<String, String>> _getHeaders() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token') ?? '';
    
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  // Save token
  Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
  }

  // Get token
  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  // Remove token (logout)
  Future<void> removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
  }

  // Generic GET request
  Future<dynamic> get(String endpoint, {Map<String, String>? queryParams}) async {
    try {
      final uri = Uri.parse('$_baseUrl/$endpoint').replace(
        queryParameters: queryParams,
      );
      
      final response = await http.get(
        uri,
        headers: await _getHeaders(),
      );

      return _handleResponse(response);
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Generic POST request
  Future<dynamic> post(String endpoint, dynamic data) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/$endpoint'),
        headers: await _getHeaders(),
        body: json.encode(data),
      );

      return _handleResponse(response);
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Generic PUT request
  Future<dynamic> put(String endpoint, dynamic data) async {
    try {
      final response = await http.put(
        Uri.parse('$_baseUrl/$endpoint'),
        headers: await _getHeaders(),
        body: json.encode(data),
      );

      return _handleResponse(response);
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Generic DELETE request
  Future<dynamic> delete(String endpoint, {Map<String, String>? queryParams}) async {
    try {
      final uri = Uri.parse('$_baseUrl/$endpoint').replace(
        queryParameters: queryParams,
      );
      
      final response = await http.delete(
        uri,
        headers: await _getHeaders(),
      );

      return _handleResponse(response);
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Handle response
  dynamic _handleResponse(http.Response response) {
    final statusCode = response.statusCode;
    final responseBody = json.decode(response.body);

    if (statusCode >= 200 && statusCode < 300) {
      return responseBody;
    } else {
      final errorMessage = responseBody['error'] ?? 'Request failed with status: $statusCode';
      throw Exception(errorMessage);
    }
  }
}