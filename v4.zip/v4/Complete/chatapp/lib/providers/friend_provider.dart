import 'package:flutter/foundation.dart';
import '../database/database_repository.dart';
import '../models/user.dart';
import '../models/friend_request.dart';

class FriendProvider with ChangeNotifier {
  final DatabaseRepository _dbRepository = DatabaseRepository();
  
  List<User> _allUsers = [];
  List<User> _friends = [];
  List<FriendRequest> _pendingRequests = [];
  Map<int, User> _requestSenders = {}; // Map requestId -> sender User
  bool _isLoading = false;

  List<User> get allUsers => _allUsers;
  List<User> get friends => _friends;
  List<FriendRequest> get pendingRequests => _pendingRequests;
  bool get isLoading => _isLoading;

  // Helper to get sender for a request
  User? getSenderForRequest(int requestId) {
    return _requestSenders[requestId];
  }

  Future<void> loadUsers(int currentUserId) async {
    _isLoading = true;
    notifyListeners();
    
    try {
      _allUsers = await _dbRepository.getAllUsersExcept(currentUserId);
      _friends = await _dbRepository.getFriends(currentUserId);
      _pendingRequests = await _dbRepository.getFriendRequestsForUser(currentUserId);
      
      // Load sender details for each request
      _requestSenders.clear();
      for (var request in _pendingRequests) {
        final sender = await _dbRepository.getUserById(request.senderId);
        if (sender != null) {
          _requestSenders[request.id!] = sender;
        }
      }
    } catch (e) {
      print('Error loading users: $e');
    }
    
    _isLoading = false;
    notifyListeners();
  }

  Future<bool> sendFriendRequest(int senderId, int receiverId) async {
    try {
      final isAlreadySent = await _dbRepository.isFriendRequestSent(senderId, receiverId);
      if (isAlreadySent) {
        return false; // Request already sent
      }
      
      final requestId = await _dbRepository.sendFriendRequest(senderId, receiverId);
      if (requestId > 0) {
        // Reload data to reflect changes
        await loadUsers(senderId);
        return true;
      }
      return false;
    } catch (e) {
      print('Error sending friend request: $e');
      return false;
    }
  }

  Future<bool> acceptFriendRequest(int requestId, int currentUserId) async {
    try {
      final success = await _dbRepository.updateFriendRequestStatus(requestId, 'accepted');
      if (success) {
        await loadUsers(currentUserId);
        return true;
      }
      return false;
    } catch (e) {
      print('Error accepting friend request: $e');
      return false;
    }
  }

  Future<bool> rejectFriendRequest(int requestId, int currentUserId) async {
    try {
      final success = await _dbRepository.updateFriendRequestStatus(requestId, 'rejected');
      if (success) {
        await loadUsers(currentUserId);
        return true;
      }
      return false;
    } catch (e) {
      print('Error rejecting friend request: $e');
      return false;
    }
  }

  // Future<bool> removeFriend(int friendId, int currentUserId) async {
  //   // Find the friend request between these users
  //   try {
  //     // Get all accepted friend requests
  //     final friends = await _dbRepository.getFriends(currentUserId);
  //     final isFriend = friends.any((friend) => friend.id == friendId);
      
  //     if (!isFriend) {
  //       return false;
  //     }
      
  //     // In a real app, you would update the friend request status to 'rejected'
  //     // For simplicity, we'll just reload the data
  //     await loadUsers(currentUserId);
  //     return true;
  //   } catch (e) {
  //     print('Error removing friend: $e');
  //     return false;
  //   }
  // }

 Future<bool> removeFriend(int friendId, int currentUserId) async {
  try {
    final requestId =
        await _dbRepository.getFriendRequestIdBetweenUsers(
      currentUserId,
      friendId,
    );

    if (requestId == null) {
      return false;
    }

    final success = await _dbRepository.updateFriendRequestStatus(
      requestId,
      'removed', // or 'rejected'
    );

    if (success) {
      await loadUsers(currentUserId);
      return true;
    }

    return false;
  } catch (e) {
    print('Error removing friend: $e');
    return false;
  }
}


  bool isFriend(int userId) {
    return _friends.any((friend) => friend.id == userId);
  }

  bool hasPendingRequestFrom(int userId, int currentUserId) {
    return _pendingRequests.any((request) => 
      request.senderId == userId && request.receiverId == currentUserId
    );
  }

  bool hasSentRequestTo(int userId, int currentUserId) {
    return _pendingRequests.any((request) => 
      request.senderId == currentUserId && request.receiverId == userId
    );
  }

  // Get pending request ID between two users
  int? getPendingRequestId(int senderId, int receiverId) {
    try {
      final request = _pendingRequests.firstWhere((req) => 
        req.senderId == senderId && req.receiverId == receiverId
      );
      return request.id;
    } catch (e) {
      return null;
    }
  }
}