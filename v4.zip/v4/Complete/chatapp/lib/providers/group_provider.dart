import 'package:flutter/foundation.dart';
import '../database/database_repository.dart';
import '../models/group.dart';
import '../models/group_member.dart';
import '../models/user.dart';

class GroupProvider with ChangeNotifier {
  final DatabaseRepository _dbRepository = DatabaseRepository();
  
  List<Group> _myGroups = [];
  List<Group> _pendingGroupInvites = [];
  bool _isLoading = false;

  List<Group> get myGroups => _myGroups;
  List<Group> get pendingGroupInvites => _pendingGroupInvites;
  bool get isLoading => _isLoading;

  Future<void> loadGroups(int currentUserId) async {
    _isLoading = true;
    notifyListeners();
    
    try {
      // Load groups where user is admin or member
      _myGroups = await _dbRepository.getUserGroups(currentUserId);
      
      // Load pending group invites
      _pendingGroupInvites = await _dbRepository.getPendingGroupInvites(currentUserId);
    } catch (e) {
      print('Error loading groups: $e');
    }
    
    _isLoading = false;
    notifyListeners();
  }

  Future<bool> createGroup(String name, String? description, int adminId, List<int> memberIds) async {
    try {
      // FIXED: Now passing all 4 parameters including memberIds
      final groupId = await _dbRepository.createGroup(name, description, adminId, memberIds);
      if (groupId > 0) {
        // Note: The admin and other members are already added in the backend
        // So we don't need to add them individually here
        
        await loadGroups(adminId);
        return true;
      }
      return false;
    } catch (e) {
      print('Error creating group: $e');
      return false;
    }
  }

  Future<bool> updateGroup(Group group) async {
    try {
      final success = await _dbRepository.updateGroup(group);
      if (success) {
        await loadGroups(group.adminId);
        return true;
      }
      return false;
    } catch (e) {
      print('Error updating group: $e');
      return false;
    }
  }

  Future<bool> deleteGroup(int groupId, int currentUserId) async {
    try {
      final success = await _dbRepository.deleteGroup(groupId);
      if (success) {
        await loadGroups(currentUserId);
        return true;
      }
      return false;
    } catch (e) {
      print('Error deleting group: $e');
      return false;
    }
  }

  Future<bool> addGroupMember(int groupId, int userId) async {
    try {
      final success = await _dbRepository.addGroupMember(groupId, userId, 'pending');
      if (success) {
        await loadGroups(userId);
        return true;
      }
      return false;
    } catch (e) {
      print('Error adding group member: $e');
      return false;
    }
  }

  Future<bool> removeGroupMember(int groupId, int userId, int currentUserId) async {
    try {
      final success = await _dbRepository.removeGroupMember(groupId, userId);
      if (success) {
        await loadGroups(currentUserId);
        return true;
      }
      return false;
    } catch (e) {
      print('Error removing group member: $e');
      return false;
    }
  }

  Future<bool> acceptGroupInvite(int groupId, int userId) async {
    try {
      final success = await _dbRepository.updateGroupMemberStatus(groupId, userId, 'accepted');
      if (success) {
        await loadGroups(userId);
        return true;
      }
      return false;
    } catch (e) {
      print('Error accepting group invite: $e');
      return false;
    }
  }

  Future<bool> rejectGroupInvite(int groupId, int userId) async {
    try {
      final success = await _dbRepository.removeGroupMember(groupId, userId);
      if (success) {
        await loadGroups(userId);
        return true;
      }
      return false;
    } catch (e) {
      print('Error rejecting group invite: $e');
      return false;
    }
  }

  Future<List<User>> getGroupMembers(int groupId) async {
    try {
      return await _dbRepository.getGroupMembers(groupId);
    } catch (e) {
      print('Error getting group members: $e');
      return [];
    }
  }

  Future<bool> isUserAdmin(int groupId, int userId) async {
    try {
      final group = await _dbRepository.getGroupById(groupId);
      return group?.adminId == userId;
    } catch (e) {
      print('Error checking admin status: $e');
      return false;
    }
  }
}