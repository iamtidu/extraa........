// import 'package:flutter/foundation.dart';
// import '../database/database_repository.dart';
// import '../models/user.dart';

// class AuthProvider with ChangeNotifier {
//   User? _currentUser;
//   DatabaseRepository _dbRepository = DatabaseRepository();

//   User? get currentUser => _currentUser;

//   Future<bool> login(String email, String password) async {
//     final user = await _dbRepository.getUserByEmailAndPassword(email, password);
//     if (user != null) {
//       _currentUser = user;
//       notifyListeners();
//       return true;
//     }
//     return false;
//   }

//   Future<bool> register(String name, String username, String email, String password) async {
//     final existingUser = await _dbRepository.getUserByEmailOrUsername(email, username);
//     if (existingUser != null) {
//       return false;
//     }

//     final user = User(
//       name: name,
//       username: username,
//       email: email,
//       password: password,
//       createdAt: DateTime.now(),
//     );

//     final userId = await _dbRepository.insertUser(user);
//     if (userId > 0) {
//       user.id = userId;
//       _currentUser = user;
//       notifyListeners();
//       return true;
//     }
//     return false;
//   }

//   void logout() {
//     _currentUser = null;
//     notifyListeners();
//   }

//   Future<bool> updateProfile(User updatedUser) async {
//     final success = await _dbRepository.updateUser(updatedUser);
//     if (success) {
//       _currentUser = updatedUser;
//       notifyListeners();
//       return true;
//     }
//     return false;
//   }
// }

// import 'package:flutter/foundation.dart';
// import '../database/database_repository.dart';
// import '../models/user.dart';

// class AuthProvider with ChangeNotifier {
//   User? _currentUser;
//   DatabaseRepository _dbRepository = DatabaseRepository();

//   User? get currentUser => _currentUser;

//   Future<void> initialize() async {
//     await _dbRepository.init();
//   }

//   Future<bool> login(String email, String password) async {
//     final user = await _dbRepository.getUserByEmailAndPassword(email, password);
//     if (user != null && user.id != 0) {
//       _currentUser = user;
//       notifyListeners();
//       return true;
//     }
//     return false;
//   }

//   Future<bool> register(String name, String username, String email, String password) async {
//     final existingUser = await _dbRepository.getUserByEmailOrUsername(email, username);
//     if (existingUser != null) {
//       return false;
//     }

//     final user = User(
//       name: name,
//       username: username,
//       email: email,
//       password: password,
//       createdAt: DateTime.now(),
//     );

//     final userId = await _dbRepository.insertUser(user);
//     if (userId > 0) {
//       user.id = userId;
//       _currentUser = user;
//       notifyListeners();
//       return true;
//     }
//     return false;
//   }

//   void logout() {
//     _currentUser = null;
//     notifyListeners();
//   }

//   Future<bool> updateProfile(User updatedUser) async {
//     final success = await _dbRepository.updateUser(updatedUser);
//     if (success) {
//       _currentUser = updatedUser;
//       notifyListeners();
//       return true;
//     }
//     return false;
//   }
// }

import 'package:flutter/foundation.dart';
import '../database/database_repository.dart';
import '../models/user.dart';
import '../services/api_service.dart';

class AuthProvider with ChangeNotifier {
  User? _currentUser;
  DatabaseRepository _dbRepository = DatabaseRepository();
  final ApiService _api = ApiService();

  User? get currentUser => _currentUser;

  Future<void> initialize() async {
    await _dbRepository.init();
    
    // Check if we have a saved token and get user data
    final token = await _api.getToken();
    if (token != null) {
      try {
        // You may want to fetch current user data here
        // For now, we'll just initialize
      } catch (e) {
        // Token invalid, clear it
        await _api.removeToken();
      }
    }
  }

  Future<bool> login(String email, String password) async {
    final user = await _dbRepository.getUserByEmailAndPassword(email, password);
    if (user != null && user.id != 0) {
      _currentUser = user;
      notifyListeners();
      return true;
    }
    return false;
  }

  Future<bool> register(String name, String username, String email, String password) async {
    // Check existing user is now handled by backend
    final user = User(
      name: name,
      username: username,
      email: email,
      password: password,
      createdAt: DateTime.now(),
    );

    final userId = await _dbRepository.insertUser(user);
    if (userId > 0) {
      user.id = userId;
      _currentUser = user;
      notifyListeners();
      return true;
    }
    return false;
  }

  void logout() {
    _api.removeToken();
    _currentUser = null;
    notifyListeners();
  }

  Future<bool> updateProfile(User updatedUser) async {
    final success = await _dbRepository.updateUser(updatedUser);
    if (success) {
      _currentUser = updatedUser;
      notifyListeners();
      return true;
    }
    return false;
  }
}