import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'chat_app.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    // Users table
    await db.execute('''
      CREATE TABLE users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');

    // Friend requests table
    await db.execute('''
      CREATE TABLE friend_requests(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER NOT NULL,
        receiver_id INTEGER NOT NULL,
        status TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (sender_id) REFERENCES users (id),
        FOREIGN KEY (receiver_id) REFERENCES users (id)
      )
    ''');

    // Chats table (one-to-one)
    await db.execute('''
      CREATE TABLE chats(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user1_id INTEGER NOT NULL,
        user2_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user1_id) REFERENCES users (id),
        FOREIGN KEY (user2_id) REFERENCES users (id)
      )
    ''');

    // Groups table
    await db.execute('''
      CREATE TABLE groups(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        admin_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (admin_id) REFERENCES users (id)
      )
    ''');

    // Group members table
    await db.execute('''
      CREATE TABLE group_members(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        status TEXT NOT NULL, -- 'pending', 'accepted'
        joined_at TEXT,
        FOREIGN KEY (group_id) REFERENCES groups (id),
        FOREIGN KEY (user_id) REFERENCES users (id)
      )
    ''');

    // Messages table
    await db.execute('''
      CREATE TABLE messages(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        chat_id INTEGER,
        group_id INTEGER,
        sender_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (chat_id) REFERENCES chats (id),
        FOREIGN KEY (group_id) REFERENCES groups (id),
        FOREIGN KEY (sender_id) REFERENCES users (id)
      )
    ''');

    // Insert 4 test users
    await _insertTestUsers(db);
  }

  Future<void> _insertTestUsers(Database db) async {
    final testUsers = [
      {
        'name': 'Alice Johnson',
        'username': 'alice',
        'email': 'alice@test.com',
        'password': 'password123',
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'name': 'Bob Smith',
        'username': 'bob',
        'email': 'bob@test.com',
        'password': 'password123',
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'name': 'Charlie Brown',
        'username': 'charlie',
        'email': 'charlie@test.com',
        'password': 'password123',
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'name': 'Diana Prince',
        'username': 'diana',
        'email': 'diana@test.com',
        'password': 'password123',
        'created_at': DateTime.now().toIso8601String(),
      },
    ];

    for (var user in testUsers) {
      await db.insert('users', user);
    }
  }
}