// import 'package:sqflite/sqflite.dart';
// import '../models/user.dart';
// import '../models/friend_request.dart';
// import 'database_helper.dart';

// class DatabaseRepository {
//   final DatabaseHelper _dbHelper = DatabaseHelper();

//   // User operations
//   Future<User?> getUserByEmailAndPassword(String email, String password) async {
//     final db = await _dbHelper.database;
//     final List<Map<String, dynamic>> maps = await db.query(
//       'users',
//       where: 'email = ? AND password = ?',
//       whereArgs: [email, password],
//     );
//     if (maps.isNotEmpty) {
//       return User.fromMap(maps.first);
//     }
//     return null;
//   }

//   Future<User?> getUserByEmailOrUsername(String email, String username) async {
//     final db = await _dbHelper.database;
//     final List<Map<String, dynamic>> maps = await db.query(
//       'users',
//       where: 'email = ? OR username = ?',
//       whereArgs: [email, username],
//     );
//     if (maps.isNotEmpty) {
//       return User.fromMap(maps.first);
//     }
//     return null;
//   }

//   Future<int> insertUser(User user) async {
//     final db = await _dbHelper.database;
//     return await db.insert('users', user.toMap());
//   }

//   Future<bool> updateUser(User user) async {
//     final db = await _dbHelper.database;
//     final count = await db.update(
//       'users',
//       user.toMap(),
//       where: 'id = ?',
//       whereArgs: [user.id],
//     );
//     return count > 0;
//   }

//   Future<List<User>> getAllUsersExcept(int excludedUserId) async {
//     final db = await _dbHelper.database;
//     final List<Map<String, dynamic>> maps = await db.query(
//       'users',
//       where: 'id != ?',
//       whereArgs: [excludedUserId],
//     );
//     return List.generate(maps.length, (i) => User.fromMap(maps[i]));
//   }

//   Future<User?> getUserById(int userId) async {
//     final db = await _dbHelper.database;
//     final List<Map<String, dynamic>> maps = await db.query(
//       'users',
//       where: 'id = ?',
//       whereArgs: [userId],
//     );
//     if (maps.isNotEmpty) {
//       return User.fromMap(maps.first);
//     }
//     return null;
//   }

//   // Friend request operations
//   Future<int> sendFriendRequest(int senderId, int receiverId) async {
//     final db = await _dbHelper.database;
//     final request = FriendRequest(
//       senderId: senderId,
//       receiverId: receiverId,
//       status: 'pending',
//       createdAt: DateTime.now(),
//     );
//     return await db.insert('friend_requests', request.toMap());
//   }

//   Future<List<FriendRequest>> getFriendRequestsForUser(int userId) async {
//     final db = await _dbHelper.database;
//     final List<Map<String, dynamic>> maps = await db.query(
//       'friend_requests',
//       where: 'receiver_id = ? AND status = ?',
//       whereArgs: [userId, 'pending'],
//     );
//     return List.generate(maps.length, (i) => FriendRequest.fromMap(maps[i]));
//   }

//   Future<bool> updateFriendRequestStatus(int requestId, String status) async {
//     final db = await _dbHelper.database;
//     final count = await db.update(
//       'friend_requests',
//       {'status': status},
//       where: 'id = ?',
//       whereArgs: [requestId],
//     );
//     return count > 0;
//   }

//   Future<List<User>> getFriends(int userId) async {
//     final db = await _dbHelper.database;
//     final query = '''
//       SELECT u.* FROM users u
//       JOIN friend_requests fr ON 
//         (fr.sender_id = u.id AND fr.receiver_id = ?) OR 
//         (fr.receiver_id = u.id AND fr.sender_id = ?)
//       WHERE fr.status = 'accepted'
//     ''';
//     final List<Map<String, dynamic>> maps = await db.rawQuery(query, [userId, userId]);
//     return List.generate(maps.length, (i) => User.fromMap(maps[i]));
//   }

//   Future<bool> isFriendRequestSent(int senderId, int receiverId) async {
//     final db = await _dbHelper.database;
//     final List<Map<String, dynamic>> maps = await db.query(
//       'friend_requests',
//       where: 'sender_id = ? AND receiver_id = ? AND status = ?',
//       whereArgs: [senderId, receiverId, 'pending'],
//     );
//     return maps.isNotEmpty;
//   }
// }


// import '../models/user.dart';
// import '../models/friend_request.dart';
// import '../services/local_storage_service.dart';
// import '../models/group.dart';


// class DatabaseRepository {
//   final LocalStorageService _storage = LocalStorageService();

//   Future<void> init() async {
//     await _storage.init();
//   }

//   // User operations
//   Future<User?> getUserByEmailAndPassword(String email, String password) async {
//     return await _storage.getUserByEmailAndPassword(email, password);
//   }

//   Future<User?> getUserByEmailOrUsername(String email, String username) async {
//     return await _storage.getUserByEmailOrUsername(email, username);
//   }

//   Future<int> insertUser(User user) async {
//     return await _storage.insertUser(user);
//   }

//   Future<bool> updateUser(User user) async {
//     return await _storage.updateUser(user);
//   }

//   Future<List<User>> getAllUsersExcept(int excludedUserId) async {
//     return await _storage.getAllUsersExcept(excludedUserId);
//   }

//   Future<User?> getUserById(int userId) async {
//     return await _storage.getUserById(userId);
//   }

//   // Friend request operations
//   Future<int> sendFriendRequest(int senderId, int receiverId) async {
//     return await _storage.sendFriendRequest(senderId, receiverId);
//   }

//   Future<List<FriendRequest>> getFriendRequestsForUser(int userId) async {
//     return await _storage.getFriendRequestsForUser(userId);
//   }

//   Future<bool> updateFriendRequestStatus(int requestId, String status) async {
//     return await _storage.updateFriendRequestStatus(requestId, status);
//   }

//   Future<List<User>> getFriends(int userId) async {
//     return await _storage.getFriends(userId);
//   }

//   Future<bool> isFriendRequestSent(int senderId, int receiverId) async {
//     return await _storage.isFriendRequestSent(senderId, receiverId);
//   }

//   // Group operations
//   Future<int> createGroup(String name, String? description, int adminId) async {
//     return await _storage.createGroup(name, description, adminId);
//   }

//   Future<bool> updateGroup(Group group) async {
//     return await _storage.updateGroup(group);
//   }

//   Future<bool> deleteGroup(int groupId) async {
//     return await _storage.deleteGroup(groupId);
//   }

//   Future<List<Group>> getUserGroups(int userId) async {
//     return await _storage.getUserGroups(userId);
//   }

//   Future<Group?> getGroupById(int groupId) async {
//     return await _storage.getGroupById(groupId);
//   }

//   // Group member operations
//   Future<bool> addGroupMember(int groupId, int userId, String status) async {
//     return await _storage.addGroupMember(groupId, userId, status);
//   }

//   Future<bool> removeGroupMember(int groupId, int userId) async {
//     return await _storage.removeGroupMember(groupId, userId);
//   }

//   Future<bool> updateGroupMemberStatus(int groupId, int userId, String status) async {
//     return await _storage.updateGroupMemberStatus(groupId, userId, status);
//   }

//   Future<List<User>> getGroupMembers(int groupId) async {
//     return await _storage.getGroupMembers(groupId);
//   }

//   Future<List<Group>> getPendingGroupInvites(int userId) async {
//     return await _storage.getPendingGroupInvites(userId);
//   }

//   Future<int?> getFriendRequestIdBetweenUsers(int user1, int user2) async {
//   return await _storage.getFriendRequestIdBetweenUsers(user1, user2);
// }

  
// }

import 'package:flutter/foundation.dart';
import '../models/user.dart';
import '../models/friend_request.dart';
import '../models/group.dart';
import '../models/message.dart';
import '../services/api_service.dart';

class DatabaseRepository {
  final ApiService _api = ApiService();

  // No need for init method for API
  Future<void> init() async {
    // Check if token exists
    final token = await _api.getToken();
    if (token != null) {
      // Token exists, verify it by getting user profile
      try {
        await _api.get('auth/me');
      } catch (e) {
        // Token invalid, remove it
        await _api.removeToken();
      }
    }
  }

  // User operations
  Future<User?> getUserByEmailAndPassword(String email, String password) async {
    try {
      final response = await _api.post('auth/login', {
        'email': email,
        'password': password,
      });
      
      if (response['success']) {
        // Save token
        await _api.saveToken(response['token']);
        
        // Convert to User object
        final userData = response['user'];
        return User.fromMap(userData);
      }
      return null;
    } catch (e) {
      if (kDebugMode) print('Login error: $e');
      return null;
    }
  }

  Future<User?> getUserByEmailOrUsername(String email, String username) async {
    try {
      // This is handled in register endpoint on backend
      return null;
    } catch (e) {
      if (kDebugMode) print('Get user by email/username error: $e');
      return null;
    }
  }

  Future<int> insertUser(User user) async {
    try {
      final response = await _api.post('auth/register', {
        'name': user.name,
        'username': user.username,
        'email': user.email,
        'password': user.password,
      });
      
      if (response['success']) {
        // Save token
        await _api.saveToken(response['token']);
        
        // Return user ID
        final userData = response['user'];
        return userData['id'];
      }
      return 0;
    } catch (e) {
      if (kDebugMode) print('Register error: $e');
      return 0;
    }
  }

  Future<bool> updateUser(User user) async {
    try {
      final response = await _api.put('auth/profile', {
        'name': user.name,
        'username': user.username,
        'email': user.email,
      });
      
      return response['success'];
    } catch (e) {
      if (kDebugMode) print('Update user error: $e');
      return false;
    }
  }

  Future<List<User>> getAllUsersExcept(int excludedUserId) async {
    try {
      final response = await _api.get('friends/users/except/$excludedUserId');
      
      if (response['success']) {
        final List<dynamic> usersList = response['users'];
        return usersList.map((userMap) => User.fromMap(userMap)).toList();
      }
      return [];
    } catch (e) {
      if (kDebugMode) print('Get all users error: $e');
      return [];
    }
  }

  Future<User?> getUserById(int userId) async {
    try {
      final response = await _api.get('friends/users/$userId');
      
      if (response['success']) {
        return User.fromMap(response['user']);
      }
      return null;
    } catch (e) {
      if (kDebugMode) print('Get user by ID error: $e');
      return null;
    }
  }

  // Friend request operations
  Future<int> sendFriendRequest(int senderId, int receiverId) async {
    try {
      final response = await _api.post('friends/friend-requests/send', {
        'senderId': senderId,
        'receiverId': receiverId,
      });
      
      if (response['success']) {
        return response['requestId'];
      }
      return 0;
    } catch (e) {
      if (kDebugMode) print('Send friend request error: $e');
      return 0;
    }
  }

  Future<List<FriendRequest>> getFriendRequestsForUser(int userId) async {
    try {
      final response = await _api.get('friends/friend-requests/user/$userId');
      
      if (response['success']) {
        final List<dynamic> requestsList = response['requests'];
        return requestsList.map((reqMap) => FriendRequest.fromMap(reqMap)).toList();
      }
      return [];
    } catch (e) {
      if (kDebugMode) print('Get friend requests error: $e');
      return [];
    }
  }

  Future<bool> updateFriendRequestStatus(int requestId, String status) async {
    try {
      final response = await _api.put(
        'friends/friend-requests/$requestId/status',
        {'status': status},
      );
      
      return response['success'];
    } catch (e) {
      if (kDebugMode) print('Update friend request status error: $e');
      return false;
    }
  }

  Future<List<User>> getFriends(int userId) async {
    try {
      final response = await _api.get('friends/friends/$userId');
      
      if (response['success']) {
        final List<dynamic> friendsList = response['friends'];
        return friendsList.map((userMap) => User.fromMap(userMap)).toList();
      }
      return [];
    } catch (e) {
      if (kDebugMode) print('Get friends error: $e');
      return [];
    }
  }

  Future<bool> isFriendRequestSent(int senderId, int receiverId) async {
    try {
      final response = await _api.get(
        'friends/friend-requests/check/$senderId/$receiverId',
      );
      
      if (response['success']) {
        return response['isSent'];
      }
      return false;
    } catch (e) {
      if (kDebugMode) print('Check friend request sent error: $e');
      return false;
    }
  }

  Future<int?> getFriendRequestIdBetweenUsers(int user1, int user2) async {
    try {
      final response = await _api.get(
        'friends/friend-requests/between/$user1/$user2',
      );
      
      if (response['success']) {
        return response['requestId'];
      }
      return null;
    } catch (e) {
      if (kDebugMode) print('Get friend request ID error: $e');
      return null;
    }
  }

  // Group operations
  Future<int> createGroup(String name, String? description, int adminId, List<int> memberIds) async {
    try {
      final response = await _api.post('groups/groups/create', {
        'name': name,
        'description': description,
        'adminId': adminId,
        'memberIds': memberIds,
      });
      
      if (response['success']) {
        return response['groupId'];
      }
      return 0;
    } catch (e) {
      if (kDebugMode) print('Create group error: $e');
      return 0;
    }
  }

  Future<bool> updateGroup(Group group) async {
    try {
      final response = await _api.put('groups/groups/${group.id}', {
        'name': group.name,
        'description': group.description,
        'adminId': group.adminId,
      });
      
      return response['success'];
    } catch (e) {
      if (kDebugMode) print('Update group error: $e');
      return false;
    }
  }

  Future<bool> deleteGroup(int groupId) async {
    try {
      final response = await _api.delete('groups/groups/$groupId');
      return response['success'];
    } catch (e) {
      if (kDebugMode) print('Delete group error: $e');
      return false;
    }
  }

  Future<List<Group>> getUserGroups(int userId) async {
    try {
      final response = await _api.get('groups/groups/user/$userId');
      
      if (response['success']) {
        final List<dynamic> groupsList = response['groups'];
        return groupsList.map((groupMap) => Group.fromMap(groupMap)).toList();
      }
      return [];
    } catch (e) {
      if (kDebugMode) print('Get user groups error: $e');
      return [];
    }
  }

  Future<Group?> getGroupById(int groupId) async {
    try {
      final response = await _api.get('groups/groups/$groupId');
      
      if (response['success']) {
        return Group.fromMap(response['group']);
      }
      return null;
    } catch (e) {
      if (kDebugMode) print('Get group by ID error: $e');
      return null;
    }
  }

  // Group member operations
  Future<bool> addGroupMember(int groupId, int userId, String status) async {
    try {
      final response = await _api.post('groups/groups/members/add', {
        'groupId': groupId,
        'userId': userId,
        'status': status,
      });
      
      return response['success'];
    } catch (e) {
      if (kDebugMode) print('Add group member error: $e');
      return false;
    }
  }

  Future<bool> removeGroupMember(int groupId, int userId) async {
    try {
      final response = await _api.delete(
        'groups/groups/members/remove',
        queryParams: {
          'groupId': groupId.toString(),
          'userId': userId.toString(),
        },
      );
      
      return response['success'];
    } catch (e) {
      if (kDebugMode) print('Remove group member error: $e');
      return false;
    }
  }

  Future<bool> updateGroupMemberStatus(int groupId, int userId, String status) async {
    try {
      final response = await _api.put(
        'groups/$groupId/members/$userId/status',
        {'status': status},
      );
      
      return response['success'];
    } catch (e) {
      if (kDebugMode) print('Update group member status error: $e');
      return false;
    }
  }

  Future<List<User>> getGroupMembers(int groupId) async {
    try {
      final response = await _api.get('groups/groups/$groupId/members');
      
      if (response['success']) {
        final List<dynamic> membersList = response['members'];
        return membersList.map((userMap) => User.fromMap(userMap)).toList();
      }
      return [];
    } catch (e) {
      if (kDebugMode) print('Get group members error: $e');
      return [];
    }
  }

  Future<List<Group>> getPendingGroupInvites(int userId) async {
    try {
      final response = await _api.get('groups/groups/invites/pending/$userId');
      
      if (response['success']) {
        final List<dynamic> groupsList = response['groups'];
        return groupsList.map((groupMap) => Group.fromMap(groupMap)).toList();
      }
      return [];
    } catch (e) {
      if (kDebugMode) print('Get pending group invites error: $e');
      return [];
    }
  }

  Future<bool> isUserAdmin(int groupId, int userId) async {
    try {
      final response = await _api.get('groups/groups/$groupId/admin/$userId');
      
      if (response['success']) {
        return response['isAdmin'];
      }
      return false;
    } catch (e) {
      if (kDebugMode) print('Check admin status error: $e');
      return false;
    }
  }

  // Message operations
  Future<void> saveMessage(Message message) async {
    try {
      await _api.post('messages/messages/save', {
        'senderId': message.senderId,
        'receiverId': message.receiverId,
        'groupId': message.groupId,
        'content': message.content,
        'chatId': message.chatId,
      });
    } catch (e) {
      if (kDebugMode) print('Save message error: $e');
    }
  }

  Future<List<Message>> getMessages(String chatId) async {
    try {
      final response = await _api.get('messages/messages/chat/$chatId');
      
      if (response['success']) {
        final List<dynamic> messagesList = response['messages'];
        return messagesList.map((msgMap) => Message.fromMap(msgMap)).toList();
      }
      return [];
    } catch (e) {
      if (kDebugMode) print('Get messages error: $e');
      return [];
    }
  }

  Future<void> clearMessages(String chatId) async {
    try {
      await _api.delete('messages/messages/chat/$chatId');
    } catch (e) {
      if (kDebugMode) print('Clear messages error: $e');
    }
  }

  Future<List<String>> getAllChatIds(int userId) async {
    try {
      final response = await _api.get('messages/chats/user/$userId');
      
      if (response['success']) {
        final List<dynamic> chatIdsList = response['chatIds'];
        return chatIdsList.map((chatId) => chatId.toString()).toList();
      }
      return [];
    } catch (e) {
      if (kDebugMode) print('Get chat IDs error: $e');
      return [];
    }
  }

  Future<Message?> getLastMessage(String chatId) async {
    try {
      final response = await _api.get('messages/messages/last/$chatId');
      
      if (response['success'] && response['lastMessage'] != null) {
        return Message.fromMap(response['lastMessage']);
      }
      return null;
    } catch (e) {
      if (kDebugMode) print('Get last message error: $e');
      return null;
    }
  }

  Future<void> markMessagesAsRead(String chatId, int userId) async {
    try {
      await _api.put('messages/messages/read/$chatId/$userId', {});
    } catch (e) {
      if (kDebugMode) print('Mark as read error: $e');
    }
  }

  Future<int> getUnreadCount(String chatId, int userId) async {
    try {
      final response = await _api.get('messages/messages/unread/$chatId/$userId');
      
      if (response['success']) {
        return response['count'] ?? 0;
      }
      return 0;
    } catch (e) {
      if (kDebugMode) print('Get unread count error: $e');
      return 0;
    }
  }
}