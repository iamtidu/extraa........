class Message {
  int? id;
  int senderId;
  int? receiverId;
  int? groupId;
  String content;
  String? chatId;
  bool isRead;
  DateTime createdAt;

  Message({
    this.id,
    required this.senderId,
    this.receiverId,
    this.groupId,
    required this.content,
    this.chatId,
    this.isRead = false,
    required this.createdAt,
  });

  factory Message.fromMap(Map<String, dynamic> map) {
    return Message(
      id: map['_id'] != null ? int.tryParse(map['_id'].toString()) ?? map['id'] : map['id'],
      senderId: map['senderId'] is String 
          ? int.tryParse(map['senderId']) ?? map['senderId']['_id'] ?? 0
          : map['senderId'] ?? 0,
      receiverId: map['receiverId'],
      groupId: map['groupId'],
      content: map['content'] ?? '',
      chatId: map['chatId'],
      isRead: map['isRead'] ?? false,
      createdAt: map['createdAt'] != null 
          ? DateTime.parse(map['createdAt'].toString())
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'senderId': senderId,
      'receiverId': receiverId,
      'groupId': groupId,
      'content': content,
      'chatId': chatId,
      'isRead': isRead,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}