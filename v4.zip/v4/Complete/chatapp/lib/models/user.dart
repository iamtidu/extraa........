class User {
  String? id; // Changed from int? to String?
  String name;
  String username;
  String email;
  String password;
  DateTime createdAt;

  User({
    this.id,
    required this.name,
    required this.username,
    required this.email,
    required this.password,
    required this.createdAt,
  });

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['_id']?.toString() ?? map['id']?.toString(), // Handle both _id and id
      name: map['name'] ?? '',
      username: map['username'] ?? '',
      email: map['email'] ?? '',
      password: map['password'] ?? '', // Note: Backend won't send password
      createdAt: map['createdAt'] != null 
          ? DateTime.parse(map['createdAt'].toString())
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'name': name,
      'username': username,
      'email': email,
      'password': password,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  // For API calls
  Map<String, dynamic> toApiMap() {
    return {
      'name': name,
      'username': username,
      'email': email,
    };
  }
}