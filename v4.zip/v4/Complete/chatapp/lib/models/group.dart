class Group {
  String? id; // Changed to String
  String name;
  String? description;
  String adminId; // Changed to String
  DateTime createdAt;

  Group({
    this.id,
    required this.name,
    this.description,
    required this.adminId,
    required this.createdAt,
  });

  factory Group.fromMap(Map<String, dynamic> map) {
    return Group(
      id: map['_id']?.toString() ?? map['id']?.toString(),
      name: map['name'] ?? '',
      description: map['description'],
      adminId: map['adminId']?.toString() ?? '',
      createdAt: map['createdAt'] != null 
          ? DateTime.parse(map['createdAt'].toString())
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'name': name,
      'description': description,
      'adminId': adminId,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}