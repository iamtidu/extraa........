class GroupMember {
  int? id;
  int groupId;
  int userId;
  String status; // 'pending', 'accepted'
  DateTime? joinedAt;

  GroupMember({
    this.id,
    required this.groupId,
    required this.userId,
    required this.status,
    this.joinedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'group_id': groupId,
      'user_id': userId,
      'status': status,
      'joined_at': joinedAt?.toIso8601String(),
    };
  }

  factory GroupMember.fromMap(Map<String, dynamic> map) {
    return GroupMember(
      id: map['id'],
      groupId: map['group_id'],
      userId: map['user_id'],
      status: map['status'],
      joinedAt: map['joined_at'] != null ? DateTime.parse(map['joined_at']) : null,
    );
  }
}