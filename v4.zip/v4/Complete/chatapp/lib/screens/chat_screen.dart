// import 'dart:async'; // Add this import for Timer
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import '../providers/auth_provider.dart';
// import '../models/user.dart';
// import '../models/message.dart';
// import '../models/group.dart';
// import '../services/websocket_service.dart';
// import '../services/message_service.dart';

// class ChatScreen extends StatefulWidget {
//   final User? friend;
//   final Group? group;
//   final bool isGroup;

//   const ChatScreen({
//     this.friend,
//     this.group,
//     this.isGroup = false,
//   });

//   @override
//   _ChatScreenState createState() => _ChatScreenState();
// }

// class _ChatScreenState extends State<ChatScreen> {
//   final TextEditingController _messageController = TextEditingController();
//   final WebSocketService _webSocketService = WebSocketService();
//   final MessageService _messageService = MessageService();
//   final List<Message> _messages = [];
//   bool _isConnected = false;
//   bool _isTyping = false;
//   Timer? _typingTimer;
//   String _chatId = '';
//   late User _currentUser;

//   @override
//   void initState() {
//     super.initState();
//     _initializeChat();
//   }

//   void _initializeChat() async {
//     await _messageService.init();
    
//     final authProvider = context.read<AuthProvider>();
//     _currentUser = authProvider.currentUser!;
    
//     // Generate chat ID
//     if (widget.isGroup && widget.group != null) {
//       _chatId = 'group_${widget.group!.id}';
//     } else if (widget.friend != null) {
//       // For one-on-one chat, create consistent chat ID
//       final sortedIds = [_currentUser.id, widget.friend!.id]..sort();
//       _chatId = 'chat_${sortedIds[0]}_${sortedIds[1]}';
//     } else {
//       _chatId = 'unknown_chat';
//     }
    
//     // Load existing messages
//     final existingMessages = await _messageService.getMessages(_chatId);
//     setState(() {
//       _messages.addAll(existingMessages);
//       _messages.sort((a, b) => a.createdAt.compareTo(b.createdAt));
//     });
    
//     // Connect to WebSocket
//     _connectWebSocket();
//   }

//   void _connectWebSocket() {
//     _webSocketService.connectToChat(
//       _chatId,
//       _currentUser.id!,
//       _currentUser.name,
//     );
    
//     // Listen for incoming messages
//     _webSocketService.messageStream.listen((data) {
//       _handleIncomingMessage(data);
//     });
//   }

//   void _handleIncomingMessage(Map<String, dynamic> data) {
//     switch (data['type']) {
//       case 'connected':
//         setState(() => _isConnected = true);
//         break;
        
//       case 'history':
//         final List<dynamic> history = data['messages'] ?? [];
//         final newMessages = history.map((msg) => Message.fromWebSocket(msg)).toList();
        
//         // Filter out duplicates and add new messages
//         final existingIds = _messages.map((m) => m.id).toSet();
//         final uniqueNewMessages = newMessages.where((msg) => 
//           !existingIds.contains(msg.id)
//         ).toList();
        
//         setState(() {
//           _messages.addAll(uniqueNewMessages);
//           _messages.sort((a, b) => a.createdAt.compareTo(b.createdAt));
//         });
        
//         // Save new messages to persistence
//         for (var msg in uniqueNewMessages) {
//           _messageService.saveMessage(msg);
//         }
//         break;
        
//       case 'message':
//         final message = Message.fromWebSocket(data);
//         setState(() {
//           _messages.add(message);
//           _messages.sort((a, b) => a.createdAt.compareTo(b.createdAt));
//         });
        
//         // Save to persistence
//         _messageService.saveMessage(message);
//         break;
        
//       case 'typing':
//         // Show typing indicator
//         if (data['isTyping'] == true && data['userId'] != _currentUser.id) {
//           _showTypingIndicator(data['userName']);
//         }
//         break;
//     }
//   }

//   void _showTypingIndicator(String userName) {
//     // You can implement typing indicator UI here
//     // For now, we'll just print to console
//     print('$userName is typing...');
//   }

//   void _sendMessage() {
//     if (_messageController.text.trim().isEmpty) {
//       return;
//     }

//     final messageContent = _messageController.text.trim();
    
//     // Create message object
//     final message = Message(
//       id: DateTime.now().millisecondsSinceEpoch,
//       chatId: widget.isGroup ? null : _chatId,
//       groupId: widget.isGroup && widget.group != null ? widget.group!.id : null,
//       senderId: _currentUser.id!,
//       senderName: _currentUser.name,
//       content: messageContent,
//       createdAt: DateTime.now(),
//       isDelivered: true,
//     );

//     // Add to local list immediately
//     setState(() {
//       _messages.add(message);
//       _messages.sort((a, b) => a.createdAt.compareTo(b.createdAt));
//     });

//     // Save to persistence
//     _messageService.saveMessage(message);

//     // Send via WebSocket
//     _webSocketService.sendMessage({
//       'type': 'message',
//       'chatId': _chatId,
//       'senderId': _currentUser.id,
//       'senderName': _currentUser.name,
//       'content': messageContent,
//       'timestamp': DateTime.now().toIso8601String(),
//       'isGroup': widget.isGroup,
//     });

//     // Clear input
//     _messageController.clear();
    
//     // Reset typing indicator
//     _webSocketService.sendTypingIndicator(false, _currentUser.name);
//     _isTyping = false;
//   }

//   void _onTypingChanged(String text) {
//     if (!_isTyping && text.isNotEmpty) {
//       _isTyping = true;
//       _webSocketService.sendTypingIndicator(true, _currentUser.name);
//     } else if (_isTyping && text.isEmpty) {
//       _isTyping = false;
//       _webSocketService.sendTypingIndicator(false, _currentUser.name);
//     }
    
//     // Reset typing timer
//     _typingTimer?.cancel();
//     _typingTimer = Timer(Duration(seconds: 2), () {
//       if (_isTyping) {
//         _isTyping = false;
//         _webSocketService.sendTypingIndicator(false, _currentUser.name);
//       }
//     });
//   }

//   @override
//   void dispose() {
//     _typingTimer?.cancel();
//     _webSocketService.disconnect();
//     _messageController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final authProvider = context.watch<AuthProvider>();
//     final currentUser = authProvider.currentUser!;

//     return Scaffold(
//       appBar: AppBar(
//         title: widget.isGroup
//             ? Text(widget.group?.name ?? 'Group Chat')
//             : Text(widget.friend?.name ?? 'Chat'),
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back),
//           onPressed: () => Navigator.pop(context),
//         ),
//         actions: [
//           Icon(
//             _isConnected ? Icons.wifi : Icons.wifi_off,
//             color: _isConnected ? Colors.green : Colors.red,
//           ),
//           SizedBox(width: 8),
//         ],
//       ),
//       body: Column(
//         children: [
//           // Connection status
//           Container(
//             padding: EdgeInsets.all(8),
//             color: _isConnected ? Colors.green[50] : Colors.red[50],
//             child: Row(
//               children: [
//                 Icon(
//                   _isConnected ? Icons.check_circle : Icons.error,
//                   color: _isConnected ? Colors.green : Colors.red,
//                   size: 16,
//                 ),
//                 SizedBox(width: 8),
//                 Expanded(
//                   child: Text(
//                     _isConnected 
//                       ? 'Connected to chat server'
//                       : 'Connecting to chat server...',
//                     style: TextStyle(
//                       color: _isConnected ? Colors.green : Colors.red,
//                       fontSize: 12,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
          
//           // Messages
//           Expanded(
//             child: _messages.isEmpty
//                 ? Center(
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Icon(Icons.chat, size: 64, color: Colors.grey),
//                         SizedBox(height: 16),
//                         Text(
//                           'No messages yet',
//                           style: TextStyle(color: Colors.grey),
//                         ),
//                         SizedBox(height: 8),
//                         Text(
//                           widget.isGroup
//                               ? 'Start the conversation in your group'
//                               : 'Say hello to ${widget.friend?.name ?? "your friend"}!',
//                           style: TextStyle(color: Colors.grey, fontSize: 12),
//                         ),
//                       ],
//                     ),
//                   )
//                 : ListView.builder(
//                     reverse: false,
//                     padding: EdgeInsets.all(8),
//                     itemCount: _messages.length,
//                     itemBuilder: (context, index) {
//                       final message = _messages[index];
//                       final isSentByMe = message.senderId == currentUser.id;
                      
//                       return _buildMessageBubble(message, isSentByMe);
//                     },
//                   ),
//           ),
          
//           // Message input
//           Container(
//             padding: EdgeInsets.all(8),
//             decoration: BoxDecoration(
//               color: Colors.grey[100],
//               border: Border(top: BorderSide(color: Colors.grey[300]!)),
//             ),
//             child: Row(
//               children: [
//                 Expanded(
//                   child: TextField(
//                     controller: _messageController,
//                     decoration: InputDecoration(
//                       hintText: 'Type a message...',
//                       border: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(24),
//                       ),
//                       contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//                     ),
//                     onChanged: _onTypingChanged,
//                     onSubmitted: (_) => _sendMessage(),
//                   ),
//                 ),
//                 SizedBox(width: 8),
//                 CircleAvatar(
//                   backgroundColor: Colors.blue,
//                   child: IconButton(
//                     icon: Icon(Icons.send, color: Colors.white),
//                     onPressed: _sendMessage,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildMessageBubble(Message message, bool isSentByMe) {
//     return Align(
//       alignment: isSentByMe ? Alignment.centerRight : Alignment.centerLeft,
//       child: Container(
//         margin: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
//         padding: EdgeInsets.all(12),
//         decoration: BoxDecoration(
//           color: isSentByMe ? Colors.blue[100] : Colors.grey[200],
//           borderRadius: BorderRadius.circular(16),
//         ),
//         constraints: BoxConstraints(
//           maxWidth: MediaQuery.of(context).size.width * 0.7,
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             if (!isSentByMe && (widget.isGroup || message.senderId != _currentUser.id))
//               Text(
//                 message.senderName,
//                 style: TextStyle(
//                   fontWeight: FontWeight.bold,
//                   fontSize: 12,
//                   color: Colors.blue,
//                 ),
//               ),
//             if (!isSentByMe && (widget.isGroup || message.senderId != _currentUser.id)) 
//               SizedBox(height: 4),
//             Text(
//               message.content,
//               style: TextStyle(fontSize: 16),
//             ),
//             SizedBox(height: 4),
//             Row(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 Text(
//                   _formatTime(message.createdAt),
//                   style: TextStyle(
//                     fontSize: 10,
//                     color: Colors.grey,
//                   ),
//                 ),
//                 SizedBox(width: 4),
//                 if (isSentByMe)
//                   Icon(
//                     message.isDelivered ? Icons.done_all : Icons.done,
//                     size: 12,
//                     color: message.isRead ? Colors.blue : Colors.grey,
//                   ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   String _formatTime(DateTime date) {
//     return '${date.hour}:${date.minute.toString().padLeft(2, '0')}';
//   }
// }


import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/auth_provider.dart';
import '../models/user.dart';
import '../models/message.dart';
import '../models/group.dart';
import '../services/websocket_service.dart';
import '../services/message_service.dart';
import '../providers/friend_provider.dart';

class ChatScreen extends StatefulWidget {
  final User? friend;
  final Group? group;
  final bool isGroup;

  const ChatScreen({
    this.friend,
    this.group,
    this.isGroup = false,
  });

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final WebSocketService _webSocketService = WebSocketService();
  final MessageService _messageService = MessageService();
  final List<Message> _messages = [];
  
  bool _isConnected = false;
  bool _isTyping = false;
  Timer? _typingTimer;
  String _chatId = '';
  late User _currentUser;
  Map<int, String> _userNames = {}; // Store user names for display

  @override
  void initState() {
    super.initState();
    _initializeChat();
  }

  void _initializeChat() async {
    await _messageService.init();
    
    final authProvider = context.read<AuthProvider>();
    _currentUser = authProvider.currentUser!;
    
    if (widget.isGroup && widget.group != null) {
      _chatId = 'group_${widget.group!.id}';
    } else if (widget.friend != null) {
      final sortedIds = [_currentUser.id, widget.friend!.id]..sort();
      _chatId = 'chat_${sortedIds[0]}_${sortedIds[1]}';
    } else {
      _chatId = 'unknown_chat';
    }
    
    final existingMessages = await _messageService.getMessages(_chatId);
    setState(() {
      _messages.addAll(existingMessages);
      _messages.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    });

    _connectWebSocket();
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _connectWebSocket() {
    _webSocketService.connectToChat(_chatId, _currentUser.id!, _currentUser.name);
    _webSocketService.messageStream.listen((data) => _handleIncomingMessage(data));
  }

  void _handleIncomingMessage(Map<String, dynamic> data) {
    switch (data['type']) {
      case 'connected':
        setState(() => _isConnected = true);
        break;
      case 'message':
        final message = _createMessageFromWebSocket(data);
        setState(() {
          _messages.add(message);
          _messages.sort((a, b) => a.createdAt.compareTo(b.createdAt));
        });
        _messageService.saveMessage(message);
        _scrollToBottom();
        break;
      case 'typing':
        if (data['isTyping'] == true && data['userId'] != _currentUser.id) {
          _showTypingIndicator(data['userName']);
        }
        break;
      case 'history':
        // Handle message history from server
        final history = data['messages'] as List?;
        if (history != null) {
          final messages = history.map((msgData) => _createMessageFromWebSocket(msgData)).toList();
          setState(() {
            _messages.addAll(messages);
            _messages.sort((a, b) => a.createdAt.compareTo(b.createdAt));
          });
        }
        break;
    }
  }

  Message _createMessageFromWebSocket(Map<String, dynamic> data) {
    // Store user name for display
    if (data['senderId'] != null && data['senderName'] != null) {
      _userNames[data['senderId']] = data['senderName'];
    }

    return Message(
      id: data['id'] ?? DateTime.now().millisecondsSinceEpoch,
      senderId: data['senderId'] ?? 0,
      receiverId: data['receiverId'],
      groupId: data['groupId'],
      content: data['content'] ?? '',
      chatId: data['chatId'],
      createdAt: data['timestamp'] != null 
          ? DateTime.parse(data['timestamp'])
          : DateTime.now(),
    );
  }

  void _showTypingIndicator(String userName) {
    print('$userName is typing...');
  }

  void _sendMessage() async {
    if (_messageController.text.trim().isEmpty) return;

    // 🔒 ALWAYS VERIFY FROM DB (NOT LOCAL CACHE)
    if (!widget.isGroup && widget.friend != null) {
      final friendProvider = context.read<FriendProvider>();
      await friendProvider.loadUsers(_currentUser.id!);

      final isFriend = friendProvider.isFriend(widget.friend!.id!);

      if (!isFriend) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('You can only chat with your friends'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }
    }

    final messageContent = _messageController.text.trim();
    final now = DateTime.now();

    final message = Message(
      id: DateTime.now().millisecondsSinceEpoch,
      senderId: _currentUser.id!,
      receiverId: widget.isGroup ? null : widget.friend?.id,
      groupId: widget.isGroup && widget.group != null ? widget.group!.id : null,
      content: messageContent,
      chatId: _chatId,
      createdAt: now,
    );

    setState(() {
      _messages.add(message);
      _messages.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    });

    _messageService.saveMessage(message);

    _webSocketService.sendMessage({
      'type': 'message',
      'chatId': _chatId,
      'senderId': _currentUser.id,
      'senderName': _currentUser.name,
      'content': messageContent,
      'timestamp': now.toIso8601String(),
      'isGroup': widget.isGroup,
    });

    _messageController.clear();
    _webSocketService.sendTypingIndicator(false, _currentUser.name);
    _isTyping = false;
    _scrollToBottom();
  }

  String _formatToIST(DateTime date) {
    var indianTime = date.toLocal(); 
    return DateFormat('hh:mm a').format(indianTime);
  }

  void _onTypingChanged(String text) {
    if (!_isTyping && text.isNotEmpty) {
      _isTyping = true;
      _webSocketService.sendTypingIndicator(true, _currentUser.name);
    } else if (_isTyping && text.isEmpty) {
      _isTyping = false;
      _webSocketService.sendTypingIndicator(false, _currentUser.name);
    }
    _typingTimer?.cancel();
    _typingTimer = Timer(Duration(seconds: 2), () {
      if (_isTyping) {
        _isTyping = false;
        _webSocketService.sendTypingIndicator(false, _currentUser.name);
      }
    });
  }

  String _getSenderName(int senderId) {
    if (senderId == _currentUser.id) {
      return 'You';
    }
    
    // Try to get from stored names
    if (_userNames.containsKey(senderId)) {
      return _userNames[senderId]!;
    }
    
    // Get from friend or group
    if (!widget.isGroup && widget.friend != null && senderId == widget.friend!.id) {
      return widget.friend!.name;
    }
    
    // For groups, we might not have the name yet
    return 'User $senderId';
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    _scrollController.dispose();
    _webSocketService.disconnect();
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final currentUser = authProvider.currentUser!;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isGroup ? (widget.group?.name ?? 'Group') : (widget.friend?.name ?? 'Chat')),
        actions: [
          Icon(_isConnected ? Icons.circle : Icons.circle_outlined, 
               color: _isConnected ? Colors.green : Colors.red, size: 12),
          SizedBox(width: 16),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(color: Color(0xFFE5DDD5)),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final message = _messages[index];
                  final isSentByMe = message.senderId == currentUser.id;
                  return _buildMessageBubble(message, isSentByMe);
                },
              ),
            ),
            _buildInputArea(),
          ],
        ),
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      color: Colors.transparent,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(25),
              ),
              child: TextField(
                controller: _messageController,
                minLines: 1,
                maxLines: 5,
                keyboardType: TextInputType.multiline,
                onChanged: _onTypingChanged,
                decoration: InputDecoration(
                  hintText: 'Type a message...',
                  contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  border: InputBorder.none,
                ),
              ),
            ),
          ),
          SizedBox(width: 5),
          GestureDetector(
            onTap: _sendMessage,
            child: CircleAvatar(
              radius: 24,
              backgroundColor: Color(0xFF075E54),
              child: Icon(Icons.send, color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(Message message, bool isSentByMe) {
    final senderName = _getSenderName(message.senderId);
    
    return Align(
      alignment: isSentByMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(bottom: 8, left: isSentByMe ? 64 : 0, right: isSentByMe ? 0 : 64),
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isSentByMe ? Color(0xFFDCF8C6) : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(12),
            topRight: Radius.circular(12),
            bottomLeft: isSentByMe ? Radius.circular(12) : Radius.circular(0),
            bottomRight: isSentByMe ? Radius.circular(0) : Radius.circular(12),
          ),
          boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 1, offset: Offset(0, 1))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!isSentByMe && widget.isGroup)
              Text(senderName, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.blueGrey)),
            Text(message.content, style: TextStyle(fontSize: 16)),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _formatToIST(message.createdAt),
                  style: TextStyle(fontSize: 10, color: Colors.black54),
                ),
                if (isSentByMe) ...[
                  SizedBox(width: 4),
                  Icon(Icons.done_all, size: 14, color: Colors.blue),
                ]
              ],
            ),
          ],
        ),
      ),
    );
  }
}