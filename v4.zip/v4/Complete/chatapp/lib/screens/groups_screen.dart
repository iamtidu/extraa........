import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/group_provider.dart';
import '../models/group.dart'; // Ensure this import exists
import 'create_group_screen.dart';
import 'group_details_screen.dart';
import 'chat_screen.dart';
import '../models/user.dart';

class GroupsScreen extends StatefulWidget {
  @override
  _GroupsScreenState createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadGroups();
    });
  }

  void _loadGroups() {
    final authProvider = context.read<AuthProvider>();
    final groupProvider = context.read<GroupProvider>();
    
    if (authProvider.currentUser != null) {
      groupProvider.loadGroups(authProvider.currentUser!.id!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final groupProvider = context.watch<GroupProvider>();
    final currentUser = authProvider.currentUser;

    if (currentUser == null) {
      return Center(child: Text('Please login'));
    }

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Groups'),
          actions: [
            IconButton(
              icon: Icon(Icons.add),
              onPressed: () => _createNewGroup(context, currentUser),
            ),
            IconButton(
              icon: Icon(Icons.refresh),
              onPressed: () => _loadGroups(),
            ),
          ],
          bottom: TabBar(
            tabs: [
              Tab(text: 'My Groups', icon: Icon(Icons.group)),
              Tab(text: 'Invites', icon: Icon(Icons.person_add)),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildMyGroupsTab(groupProvider, currentUser),
            _buildInvitesTab(groupProvider, currentUser),
          ],
        ),
      ),
    );
  }

  Widget _buildMyGroupsTab(GroupProvider groupProvider, User currentUser) {
    if (groupProvider.isLoading) {
      return Center(child: CircularProgressIndicator());
    }

    if (groupProvider.myGroups.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.group_outlined, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No groups yet', style: TextStyle(color: Colors.grey)),
            SizedBox(height: 8),
            Text('Create a group or accept an invite'),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: groupProvider.myGroups.length,
      itemBuilder: (context, index) {
        final group = groupProvider.myGroups[index];
        final isAdmin = group.adminId == currentUser.id;

        return Card(
          margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.blue,
              child: Icon(Icons.group, color: Colors.white),
            ),
            title: Text(group.name),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (group.description != null) Text(group.description!),
                Text(isAdmin ? 'Admin' : 'Member'),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.chat, color: Colors.blue),
                  onPressed: () => _openGroupChat(group),
                ),
                IconButton(
                  icon: Icon(Icons.info, color: Colors.grey),
                  onPressed: () => _viewGroupDetails(group, currentUser),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildInvitesTab(GroupProvider groupProvider, User currentUser) {
    if (groupProvider.isLoading) {
      return Center(child: CircularProgressIndicator());
    }

    if (groupProvider.pendingGroupInvites.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.person_add_disabled, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No pending invites', style: TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: groupProvider.pendingGroupInvites.length,
      itemBuilder: (context, index) {
        final group = groupProvider.pendingGroupInvites[index];

        return Card(
          margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.orange,
              child: Icon(Icons.group_add, color: Colors.white),
            ),
            title: Text(group.name),
            subtitle: group.description != null ? Text(group.description!) : null,
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.check, color: Colors.green),
                  onPressed: () => _acceptGroupInvite(group.id!, currentUser.id!, groupProvider),
                ),
                IconButton(
                  icon: Icon(Icons.close, color: Colors.red),
                  onPressed: () => _rejectGroupInvite(group.id!, currentUser.id!, groupProvider),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _createNewGroup(BuildContext context, User currentUser) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CreateGroupScreen(),
      ),
    );
  }

  void _openGroupChat(Group group) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatScreen(
          group: group, // FIXED: Pass group object instead of groupId
          isGroup: true,
        ),
      ),
    );
  }

  void _viewGroupDetails(Group group, User currentUser) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => GroupDetailsScreen(group: group),
      ),
    );
  }

  void _acceptGroupInvite(int groupId, int userId, GroupProvider groupProvider) async {
    final success = await groupProvider.acceptGroupInvite(groupId, userId);
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(success ? 'Joined group!' : 'Failed to join group'),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  void _rejectGroupInvite(int groupId, int userId, GroupProvider groupProvider) async {
    final success = await groupProvider.rejectGroupInvite(groupId, userId);
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(success ? 'Invite rejected' : 'Failed to reject invite'),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }
}