import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/friend_provider.dart';
import '../providers/group_provider.dart';
import '../models/user.dart';

class CreateGroupScreen extends StatefulWidget {
  @override
  _CreateGroupScreenState createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final Set<int> _selectedMembers = {};
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadFriends();
    });
  }

  void _loadFriends() {
    final authProvider = context.read<AuthProvider>();
    final friendProvider = context.read<FriendProvider>();
    
    if (authProvider.currentUser != null) {
      friendProvider.loadUsers(authProvider.currentUser!.id!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final friendProvider = context.watch<FriendProvider>();
    final currentUser = authProvider.currentUser;

    if (currentUser == null) {
      return Center(child: Text('Please login'));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Create New Group'),
        actions: [
          _isLoading
              ? Padding(
                  padding: EdgeInsets.only(right: 16),
                  child: CircularProgressIndicator(),
                )
              : IconButton(
                  icon: Icon(Icons.check),
                  onPressed: _createGroup,
                ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Group name
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Group Name*',
                  prefixIcon: Icon(Icons.group),
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter group name';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              
              // Group description
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: 'Description (optional)',
                  prefixIcon: Icon(Icons.description),
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
              SizedBox(height: 30),
              
              // Select members section
              Text(
                'Select Members:',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              
              if (friendProvider.isLoading)
                Center(child: CircularProgressIndicator())
              else if (friendProvider.friends.isEmpty)
                Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(
                    child: Column(
                      children: [
                        Icon(Icons.people_outline, size: 48, color: Colors.grey),
                        SizedBox(height: 10),
                        Text(
                          'No friends to add',
                          style: TextStyle(color: Colors.grey),
                        ),
                        SizedBox(height: 5),
                        Text(
                          'Add friends first from the Users tab',
                          style: TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                )
              else
                _buildFriendsList(friendProvider),
              
              SizedBox(height: 20),
              
              // Selected members count
              if (_selectedMembers.isNotEmpty)
                Card(
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Row(
                      children: [
                        Icon(Icons.group_add, color: Colors.blue),
                        SizedBox(width: 10),
                        Text(
                          '${_selectedMembers.length} member${_selectedMembers.length == 1 ? '' : 's'} selected',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFriendsList(FriendProvider friendProvider) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: friendProvider.friends.length,
      itemBuilder: (context, index) {
        final friend = friendProvider.friends[index];
        final isSelected = _selectedMembers.contains(friend.id);

        return Card(
          margin: EdgeInsets.symmetric(vertical: 4),
          child: CheckboxListTile(
            title: Text(friend.name),
            subtitle: Text('@${friend.username}'),
            secondary: CircleAvatar(
              backgroundColor: Colors.blue,
              child: Text(
                friend.name[0].toUpperCase(),
                style: TextStyle(color: Colors.white),
              ),
            ),
            value: isSelected,
            onChanged: (value) {
              setState(() {
                if (value == true) {
                  _selectedMembers.add(friend.id!);
                } else {
                  _selectedMembers.remove(friend.id!);
                }
              });
            },
          ),
        );
      },
    );
  }

  void _createGroup() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true);

      final authProvider = context.read<AuthProvider>();
      final groupProvider = context.read<GroupProvider>();
      final currentUser = authProvider.currentUser!;

      final success = await groupProvider.createGroup(
        _nameController.text,
        _descriptionController.text.isNotEmpty ? _descriptionController.text : null,
        currentUser.id!,
        _selectedMembers.toList(),
      );

      setState(() => _isLoading = false);

      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Group created successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to create group'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }
}