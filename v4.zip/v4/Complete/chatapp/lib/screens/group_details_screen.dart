import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/group_provider.dart';
import '../models/group.dart';
import '../models/user.dart';
import 'edit_group_screen.dart';

class GroupDetailsScreen extends StatefulWidget {
  final Group group;

  const GroupDetailsScreen({required this.group});

  @override
  _GroupDetailsScreenState createState() => _GroupDetailsScreenState();
}

class _GroupDetailsScreenState extends State<GroupDetailsScreen> {
  List<User> _members = [];
  bool _isLoading = true;
  bool _isAdmin = false;

  @override
  void initState() {
    super.initState();
    _loadGroupDetails();
  }

  void _loadGroupDetails() async {
    final authProvider = context.read<AuthProvider>();
    final groupProvider = context.read<GroupProvider>();
    final currentUser = authProvider.currentUser!;

    setState(() {
      _isLoading = true;
      _isAdmin = widget.group.adminId == currentUser.id;
    });

    final members = await groupProvider.getGroupMembers(widget.group.id!);
    
    setState(() {
      _members = members;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final currentUser = authProvider.currentUser!;

    return Scaffold(
      appBar: AppBar(
        title: Text('Group Details'),
        actions: _isAdmin
            ? [
                IconButton(
                  icon: Icon(Icons.edit),
                  onPressed: () => _editGroup(context),
                ),
              ]
            : null,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Group info
                  Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.group, size: 40, color: Colors.blue),
                              SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      widget.group.name,
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(height: 4),
                                    Text(
                                      _isAdmin ? 'You are admin' : 'Member',
                                      style: TextStyle(
                                        color: _isAdmin ? Colors.green : Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 16),
                          if (widget.group.description != null)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Description:',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(widget.group.description!),
                              ],
                            ),
                          SizedBox(height: 8),
                          Text(
                            'Created: ${_formatDate(widget.group.createdAt)}',
                            style: TextStyle(color: Colors.grey, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ),
                  
                  SizedBox(height: 20),
                  
                  // Members section
                  Text(
                    'Members (${_members.length})',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  
                  if (_members.isEmpty)
                    Center(
                      child: Column(
                        children: [
                          Icon(Icons.people_outline, size: 64, color: Colors.grey),
                          SizedBox(height: 16),
                          Text('No members yet', style: TextStyle(color: Colors.grey)),
                        ],
                      ),
                    )
                  else
                    _buildMembersList(),
                ],
              ),
            ),
    );
  }

  Widget _buildMembersList() {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: _members.length,
      itemBuilder: (context, index) {
        final member = _members[index];
        final isAdmin = member.id == widget.group.adminId;

        return Card(
          margin: EdgeInsets.symmetric(vertical: 4),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.blue,
              child: Text(
                member.name[0].toUpperCase(),
                style: TextStyle(color: Colors.white),
              ),
            ),
            title: Text(member.name),
            subtitle: Text('@${member.username}'),
            trailing: isAdmin
                ? Chip(
                    label: Text('Admin'),
                    backgroundColor: Colors.green[100],
                  )
                : _isAdmin
                    ? IconButton(
                        icon: Icon(Icons.person_remove, color: Colors.red),
                        onPressed: () => _removeMember(member.id!),
                      )
                    : null,
          ),
        );
      },
    );
  }

  void _editGroup(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditGroupScreen(group: widget.group),
      ),
    ).then((_) {
      // Refresh group details when returning
      _loadGroupDetails();
    });
  }

  void _removeMember(int memberId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Remove Member'),
        content: Text('Are you sure you want to remove this member from the group?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Remove', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      final groupProvider = context.read<GroupProvider>();
      final authProvider = context.read<AuthProvider>();
      final currentUser = authProvider.currentUser!;

      final success = await groupProvider.removeGroupMember(
        widget.group.id!,
        memberId,
        currentUser.id!,
      );

      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Member removed successfully'),
            backgroundColor: Colors.green,
          ),
        );
        _loadGroupDetails();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to remove member'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}