import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../services/message_service.dart';
import '../database/database_repository.dart';
import '../models/user.dart';
import '../models/group.dart';
import '../models/message.dart'; // Add this import
import 'chat_screen.dart';

class ChatListScreen extends StatefulWidget {
  @override
  _ChatListScreenState createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  final MessageService _messageService = MessageService();
  final DatabaseRepository _dbRepository = DatabaseRepository();
  List<Map<String, dynamic>> _chats = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadChats();
  }

  void _loadChats() async {
    await _messageService.init();
    final authProvider = context.read<AuthProvider>();
    final currentUser = authProvider.currentUser!;

    // Get all chat IDs with messages
    final chatIds = await _messageService.getAllChatIds();
    
    final List<Map<String, dynamic>> chats = [];
    
    for (var chatId in chatIds) {
      final lastMessage = await _messageService.getLastMessage(chatId);
      if (lastMessage != null) {
        
        if (chatId.startsWith('chat_')) {
          // One-on-one chat
          final ids = chatId.replaceFirst('chat_', '').split('_');
          final otherUserId = ids[0] == currentUser.id.toString() 
              ? int.parse(ids[1]) 
              : int.parse(ids[0]);
          
          final otherUser = await _dbRepository.getUserById(otherUserId);
          if (otherUser != null) {
            chats.add({
              'type': 'user',
              'id': chatId,
              'user': otherUser,
              'lastMessage': lastMessage,
              'unreadCount': await _messageService.getUnreadCount(chatId, 0),
            });
          }
        } else if (chatId.startsWith('group_')) {
          // Group chat
          final groupId = int.tryParse(chatId.replaceFirst('group_', ''));
          if (groupId != null) {
            final group = await _dbRepository.getGroupById(groupId);
            if (group != null) {
              chats.add({
                'type': 'group',
                'id': chatId,
                'group': group,
                'lastMessage': lastMessage,
                'unreadCount': await _messageService.getUnreadCount(chatId, 0),
              });
            }
          }
        }
      }
    }
    
    // Sort by last message time (newest first)
    chats.sort((a, b) => 
      (b['lastMessage'] as Message).createdAt.compareTo((a['lastMessage'] as Message).createdAt)
    );
    
    setState(() {
      _chats = chats;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final currentUser = authProvider.currentUser;

    if (currentUser == null) {
      return Center(child: Text('Please login'));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Chats'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () => _loadChats(),
          ),
        ],
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _buildChatList(),
    );
  }

  Widget _buildChatList() {
    if (_chats.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.chat_bubble_outline, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No conversations yet', style: TextStyle(color: Colors.grey)),
            SizedBox(height: 8),
            Text(
              'Start a chat with a friend or join a group',
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: _chats.length,
      itemBuilder: (context, index) {
        final chat = _chats[index];
        final lastMessage = chat['lastMessage'] as Message; // Fixed cast
        final unreadCount = chat['unreadCount'] as int;

        return ListTile(
          leading: CircleAvatar(
            backgroundColor: Colors.blue,
            child: chat['type'] == 'user'
                ? Text(
                    (chat['user'] as User).name[0].toUpperCase(),
                    style: TextStyle(color: Colors.white),
                  )
                : Icon(Icons.group, color: Colors.white),
          ),
          title: Text(
            chat['type'] == 'user'
                ? (chat['user'] as User).name
                : (chat['group'] as Group).name,
          ),
          subtitle: Text(
            lastMessage.content,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _formatTime(lastMessage.createdAt),
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              if (unreadCount > 0)
                Container(
                  margin: EdgeInsets.only(top: 4),
                  padding: EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    unreadCount > 9 ? '9+' : unreadCount.toString(),
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                    ),
                  ),
                ),
            ],
          ),
          onTap: () {
            if (chat['type'] == 'user') {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ChatScreen(
                    friend: chat['user'] as User,
                    isGroup: false,
                  ),
                ),
              );
            } else {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ChatScreen(
                    group: chat['group'] as Group,
                    isGroup: true,
                  ),
                ),
              );
            }
          },
        );
      },
    );
  }

  String _formatTime(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(Duration(days: 1));
    final messageDate = DateTime(date.year, date.month, date.day);

    if (messageDate == today) {
      return '${date.hour}:${date.minute.toString().padLeft(2, '0')}';
    } else if (messageDate == yesterday) {
      return 'Yesterday';
    } else {
      return '${date.day}/${date.month}';
    }
  }
}