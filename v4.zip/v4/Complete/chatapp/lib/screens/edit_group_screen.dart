import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/group_provider.dart';
import '../providers/friend_provider.dart';
import '../models/group.dart';
import '../models/user.dart';

class EditGroupScreen extends StatefulWidget {
  final Group group;

  const EditGroupScreen({required this.group});

  @override
  _EditGroupScreenState createState() => _EditGroupScreenState();
}

class _EditGroupScreenState extends State<EditGroupScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _descriptionController;
  final Set<int> _selectedMembers = {};
  final Set<int> _currentMembers = {};
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.group.name);
    _descriptionController = TextEditingController(text: widget.group.description ?? '');
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadData();
    });
  }

  void _loadData() async {
    final authProvider = context.read<AuthProvider>();
    final friendProvider = context.read<FriendProvider>();
    final groupProvider = context.read<GroupProvider>();
    
    // Load friends
    if (authProvider.currentUser != null) {
      friendProvider.loadUsers(authProvider.currentUser!.id!);
    }
    
    // Load current members
    final members = await groupProvider.getGroupMembers(widget.group.id!);
    setState(() {
      _currentMembers.addAll(members.map((m) => m.id!));
      _selectedMembers.addAll(_currentMembers);
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final friendProvider = context.watch<FriendProvider>();
    final currentUser = authProvider.currentUser;

    if (currentUser == null) {
      return Center(child: Text('Please login'));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Group'),
        actions: [
          _isLoading
              ? Padding(
                  padding: EdgeInsets.only(right: 16),
                  child: CircularProgressIndicator(),
                )
              : IconButton(
                  icon: Icon(Icons.save),
                  onPressed: _saveChanges,
                ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Group name
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Group Name*',
                  prefixIcon: Icon(Icons.group),
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter group name';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              
              // Group description
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: 'Description (optional)',
                  prefixIcon: Icon(Icons.description),
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
              SizedBox(height: 30),
              
              // Select members section
              Text(
                'Group Members:',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              
              if (friendProvider.isLoading)
                Center(child: CircularProgressIndicator())
              else if (friendProvider.friends.isEmpty)
                Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(
                    child: Column(
                      children: [
                        Icon(Icons.people_outline, size: 48, color: Colors.grey),
                        SizedBox(height: 10),
                        Text(
                          'No friends to add',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                )
              else
                _buildFriendsList(friendProvider),
              
              SizedBox(height: 20),
              
              // Stats
              Card(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Current members:', style: TextStyle(color: Colors.grey)),
                          Text('${_currentMembers.length}'),
                        ],
                      ),
                      SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Selected to add:', style: TextStyle(color: Colors.grey)),
                          Text('${_selectedMembers.length - _currentMembers.length}'),
                        ],
                      ),
                      SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('To be removed:', style: TextStyle(color: Colors.grey)),
                          Text('${_currentMembers.length - _selectedMembers.intersection(_currentMembers).length}'),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFriendsList(FriendProvider friendProvider) {
    final friends = friendProvider.friends;
    
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: friends.length,
      itemBuilder: (context, index) {
        final friend = friends[index];
        final isSelected = _selectedMembers.contains(friend.id);
        final isCurrentMember = _currentMembers.contains(friend.id);

        return Card(
          margin: EdgeInsets.symmetric(vertical: 4),
          color: isCurrentMember ? Colors.grey[100] : null,
          child: CheckboxListTile(
            title: Text(friend.name),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('@${friend.username}'),
                if (isCurrentMember)
                  Text(
                    'Current member',
                    style: TextStyle(color: Colors.green, fontSize: 12),
                  ),
              ],
            ),
            secondary: CircleAvatar(
              backgroundColor: Colors.blue,
              child: Text(
                friend.name[0].toUpperCase(),
                style: TextStyle(color: Colors.white),
              ),
            ),
            value: isSelected,
            onChanged: (value) {
              setState(() {
                if (value == true) {
                  _selectedMembers.add(friend.id!);
                } else {
                  _selectedMembers.remove(friend.id!);
                }
              });
            },
          ),
        );
      },
    );
  }

  void _saveChanges() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true);

      final authProvider = context.read<AuthProvider>();
      final groupProvider = context.read<GroupProvider>();
      final currentUser = authProvider.currentUser!;

      // Update group info
      final updatedGroup = Group(
        id: widget.group.id,
        name: _nameController.text,
        description: _descriptionController.text.isNotEmpty ? _descriptionController.text : null,
        adminId: widget.group.adminId,
        createdAt: widget.group.createdAt,
      );

      final groupUpdated = await groupProvider.updateGroup(updatedGroup);
      
      // Update members
      if (groupUpdated) {
        // Add new members
        final newMembers = _selectedMembers.difference(_currentMembers);
        for (var memberId in newMembers) {
          await groupProvider.addGroupMember(widget.group.id!, memberId);
        }
        
        // Remove unselected current members (except admin)
        final membersToRemove = _currentMembers.difference(_selectedMembers);
        for (var memberId in membersToRemove) {
          if (memberId != widget.group.adminId) { // Don't remove admin
            await groupProvider.removeGroupMember(widget.group.id!, memberId, currentUser.id!);
          }
        }
      }

      setState(() => _isLoading = false);

      if (groupUpdated) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Group updated successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update group'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }
}