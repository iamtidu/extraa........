import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/friend_provider.dart';
import '../models/user.dart';
import 'chat_screen.dart';

class FriendsScreen extends StatefulWidget {
  @override
  _FriendsScreenState createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadFriends();
    });
  }

  void _loadFriends() {
    final authProvider = context.read<AuthProvider>();
    final friendProvider = context.read<FriendProvider>();
    
    if (authProvider.currentUser != null) {
      friendProvider.loadUsers(authProvider.currentUser!.id!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final friendProvider = context.watch<FriendProvider>();
    final currentUser = authProvider.currentUser;

    if (currentUser == null) {
      return Center(child: Text('Please login'));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Friends'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () => _loadFriends(),
          ),
        ],
      ),
      body: friendProvider.isLoading
          ? Center(child: CircularProgressIndicator())
          : _buildFriendsList(friendProvider),
    );
  }

  Widget _buildFriendsList(FriendProvider friendProvider) {
    if (friendProvider.friends.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.people_outline, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No friends yet', style: TextStyle(color: Colors.grey)),
            SizedBox(height: 8),
            Text('Add friends from the Users tab'),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: friendProvider.friends.length,
      itemBuilder: (context, index) {
        final friend = friendProvider.friends[index];

        return Card(
          margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.blue,
              child: Text(
                friend.name[0].toUpperCase(),
                style: TextStyle(color: Colors.white),
              ),
            ),
            title: Text(friend.name),
            subtitle: Text('@${friend.username}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.chat, color: Colors.blue),
                  onPressed: () => _openChat(friend),
                ),
                IconButton(
                  icon: Icon(Icons.person_remove, color: Colors.red),
                  onPressed: () => _removeFriend(friend.id!, friendProvider),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _openChat(User friend) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatScreen(
          friend: friend,
          isGroup: false,
        ),
      ),
    );
  }

  void _removeFriend(int friendId, FriendProvider friendProvider) async {
    final authProvider = context.read<AuthProvider>();
    final currentUser = authProvider.currentUser!;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Remove Friend'),
        content: Text('Are you sure you want to remove this friend?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              final success = await friendProvider.removeFriend(friendId, currentUser.id!);
              
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(success ? 'Friend removed' : 'Failed to remove friend'),
                  backgroundColor: success ? Colors.green : Colors.red,
                ),
              );
            },
            child: Text('Remove', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}