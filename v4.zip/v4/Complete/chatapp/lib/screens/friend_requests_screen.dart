import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/friend_provider.dart';
import '../models/user.dart';
import '../models/friend_request.dart';

class FriendRequestsScreen extends StatefulWidget {
  @override
  _FriendRequestsScreenState createState() => _FriendRequestsScreenState();
}

class _FriendRequestsScreenState extends State<FriendRequestsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadRequests();
    });
  }

  void _loadRequests() {
    final authProvider = context.read<AuthProvider>();
    final friendProvider = context.read<FriendProvider>();
    
    if (authProvider.currentUser != null) {
      friendProvider.loadUsers(authProvider.currentUser!.id!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final friendProvider = context.watch<FriendProvider>();
    final currentUser = authProvider.currentUser;

    if (currentUser == null) {
      return Center(child: Text('Please login'));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Friend Requests'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () => _loadRequests(),
          ),
        ],
      ),
      body: friendProvider.isLoading
          ? Center(child: CircularProgressIndicator())
          : _buildRequestsList(friendProvider),
    );
  }

  Widget _buildRequestsList(FriendProvider friendProvider) {
    if (friendProvider.pendingRequests.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.person_add_disabled, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No pending requests', style: TextStyle(color: Colors.grey)),
            SizedBox(height: 8),
            Text(
              'When someone sends you a friend request,\nit will appear here.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 14),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: friendProvider.pendingRequests.length,
      itemBuilder: (context, index) {
        final request = friendProvider.pendingRequests[index];
        final sender = friendProvider.getSenderForRequest(request.id!);

        return Card(
          margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.blue,
              child: sender != null 
                  ? Text(
                      sender.name[0].toUpperCase(),
                      style: TextStyle(color: Colors.white),
                    )
                  : Icon(Icons.person, color: Colors.white),
            ),
            title: Text(sender?.name ?? 'Unknown User'),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (sender != null) Text('@${sender.username}'),
                Text(
                  'Sent ${_formatTime(request.createdAt)}',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.check, color: Colors.green),
                  onPressed: () => _acceptRequest(request.id!, sender, friendProvider),
                ),
                IconButton(
                  icon: Icon(Icons.close, color: Colors.red),
                  onPressed: () => _rejectRequest(request.id!, friendProvider),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _acceptRequest(int requestId, User? sender, FriendProvider friendProvider) async {
    final authProvider = context.read<AuthProvider>();
    final currentUserId = authProvider.currentUser!.id!;
    
    final success = await friendProvider.acceptFriendRequest(requestId, currentUserId);
    
    final senderName = sender?.name ?? 'the user';
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success 
            ? 'You are now friends with $senderName!'
            : 'Failed to accept request',
        ),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  void _rejectRequest(int requestId, FriendProvider friendProvider) async {
    final authProvider = context.read<AuthProvider>();
    final currentUserId = authProvider.currentUser!.id!;
    
    final success = await friendProvider.rejectFriendRequest(requestId, currentUserId);
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success 
            ? 'Friend request rejected'
            : 'Failed to reject request',
        ),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  String _formatTime(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays > 0) {
      return '${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hour${difference.inHours > 1 ? 's' : ''} ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''} ago';
    } else {
      return 'Just now';
    }
  }
}