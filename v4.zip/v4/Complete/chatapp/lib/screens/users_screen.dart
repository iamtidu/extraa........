import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/friend_provider.dart';
import '../models/user.dart';
import 'chat_screen.dart';

class UsersScreen extends StatefulWidget {
  @override
  _UsersScreenState createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadUsers();
    });
  }

  void _loadUsers() {
    final authProvider = context.read<AuthProvider>();
    final friendProvider = context.read<FriendProvider>();
    
    if (authProvider.currentUser != null) {
      friendProvider.loadUsers(authProvider.currentUser!.id!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final friendProvider = context.watch<FriendProvider>();
    final currentUser = authProvider.currentUser;

    if (currentUser == null) {
      return Center(child: Text('Please login'));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('All Users'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () => _loadUsers(),
          ),
        ],
      ),
      body: friendProvider.isLoading
          ? Center(child: CircularProgressIndicator())
          : _buildUsersList(friendProvider, currentUser),
    );
  }

  Widget _buildUsersList(FriendProvider friendProvider, User currentUser) {
    if (friendProvider.allUsers.isEmpty) {
      return Center(child: Text('No users found'));
    }

    return ListView.builder(
      itemCount: friendProvider.allUsers.length,
      itemBuilder: (context, index) {
        final user = friendProvider.allUsers[index];
        final isFriend = friendProvider.isFriend(user.id!);

        return Card(
          margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.blue,
              child: Text(
                user.name[0].toUpperCase(),
                style: TextStyle(color: Colors.white),
              ),
            ),
            title: Text(user.name),
            subtitle: Text('@${user.username}'),
            trailing: _buildUserActionButton(isFriend, user, currentUser, friendProvider),
            onTap: () {
              if (isFriend) {
                _openChat(user);
              }
            },
          ),
        );
      },
    );
  }

  Widget _buildUserActionButton(
    bool isFriend, 
    User user, 
    User currentUser,
    FriendProvider friendProvider,
  ) {
    // Check if there's a pending request from this user to current user
    final hasPendingRequestFromUser = friendProvider.hasPendingRequestFrom(user.id!, currentUser.id!);
    
    // Check if current user has sent request to this user
    final hasSentRequestToUser = friendProvider.hasSentRequestTo(user.id!, currentUser.id!);
    
    if (isFriend) {
      return ElevatedButton(
        onPressed: () => _openChat(user),
        child: Text('Chat'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.green,
          foregroundColor: Colors.white,
        ),
      );
    } else if (hasSentRequestToUser) {
      return Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.orange[100],
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.pending, size: 16, color: Colors.orange),
            SizedBox(width: 4),
            Text('Request Sent', style: TextStyle(color: Colors.orange[800])),
          ],
        ),
      );
    } else if (hasPendingRequestFromUser) {
      // Find the request ID
      final requestId = friendProvider.getPendingRequestId(user.id!, currentUser.id!);
      
      if (requestId != null) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            ElevatedButton(
              onPressed: () => _acceptRequest(requestId, currentUser.id!, friendProvider),
              child: Text('Accept'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
              ),
            ),
            SizedBox(width: 8),
            OutlinedButton(
              onPressed: () => _rejectRequest(requestId, currentUser.id!, friendProvider),
              child: Text('Reject'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.red,
                side: BorderSide(color: Colors.red),
              ),
            ),
          ],
        );
      } else {
        return ElevatedButton(
          onPressed: () => _sendFriendRequest(user.id!, currentUser.id!, friendProvider),
          child: Text('Add Friend'),
        );
      }
    } else {
      return ElevatedButton(
        onPressed: () => _sendFriendRequest(user.id!, currentUser.id!, friendProvider),
        child: Text('Add Friend'),
      );
    }
  }

  void _sendFriendRequest(int receiverId, int senderId, FriendProvider friendProvider) async {
    final success = await friendProvider.sendFriendRequest(senderId, receiverId);
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(success ? 'Friend request sent!' : 'Failed to send request'),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  // Add these missing methods:
  void _acceptRequest(int requestId, int currentUserId, FriendProvider friendProvider) async {
    final success = await friendProvider.acceptFriendRequest(requestId, currentUserId);
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(success ? 'Friend request accepted!' : 'Failed to accept request'),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  void _rejectRequest(int requestId, int currentUserId, FriendProvider friendProvider) async {
    final success = await friendProvider.rejectFriendRequest(requestId, currentUserId);
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(success ? 'Friend request rejected' : 'Failed to reject request'),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  void _openChat(User friend) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatScreen(
          friend: friend,
          isGroup: false,
        ),
      ),
    );
  }
}