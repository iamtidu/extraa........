const express = require('express');
const router = express.Router();
const friendController = require('../controllers/friendController');
const auth = require('../middleware/auth');

// Apply auth middleware to all routes
router.use(auth);

// User operations
router.get('/users/except/:excludedUserId', friendController.getAllUsersExcept);
router.get('/users/:userId', friendController.getUserById);

// Friend request operations
router.post('/friend-requests/send', friendController.sendFriendRequest);
router.get('/friend-requests/user/:userId', friendController.getFriendRequestsForUser);
router.put('/friend-requests/:requestId/status', friendController.updateFriendRequestStatus);
router.get('/friends/:userId', friendController.getFriends);
router.get('/friend-requests/check/:senderId/:receiverId', friendController.isFriendRequestSent);
router.get('/friend-requests/between/:user1/:user2', friendController.getFriendRequestIdBetweenUsers);

module.exports = router;