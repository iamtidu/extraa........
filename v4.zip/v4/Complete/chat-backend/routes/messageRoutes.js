const express = require('express');
const router = express.Router();
const messageController = require('../controllers/messageController');
const auth = require('../middleware/auth');

// Apply auth middleware to all routes
router.use(auth);

// Message operations
router.post('/messages/save', messageController.saveMessage);
router.get('/messages/chat/:chatId', messageController.getMessages);
router.delete('/messages/chat/:chatId', messageController.clearMessages);
router.get('/chats/user/:userId', messageController.getAllChatIds);
router.get('/messages/last/:chatId', messageController.getLastMessage);
router.put('/messages/read/:chatId/:userId', messageController.markAsRead);
router.get('/messages/unread/:chatId/:userId', messageController.getUnreadCount);

module.exports = router;