const express = require('express');
const router = express.Router();
const groupController = require('../controllers/groupController');
const auth = require('../middleware/auth');

// Apply auth middleware to all routes
router.use(auth);

// Group operations
router.post('/groups/create', groupController.createGroup);
router.put('/groups/:groupId', groupController.updateGroup);
router.delete('/groups/:groupId', groupController.deleteGroup);
router.get('/groups/user/:userId', groupController.getUserGroups);
router.get('/groups/:groupId', groupController.getGroupById);

// Group member operations
router.post('/groups/members/add', groupController.addGroupMember);
router.delete('/groups/members/remove', groupController.removeGroupMember);
router.put('/groups/:groupId/members/:userId/status', groupController.updateGroupMemberStatus);
router.get('/groups/:groupId/members', groupController.getGroupMembers);
router.get('/groups/invites/pending/:userId', groupController.getPendingGroupInvites);
router.get('/groups/:groupId/admin/:userId', groupController.isUserAdmin);

module.exports = router;