const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('MongoDB Connected Successfully');
    
    // Initialize test data
    await initializeTestData();
  } catch (error) {
    console.error('MongoDB Connection Error:', error);
    process.exit(1);
  }
};

const initializeTestData = async () => {
  const User = require('../models/User');
  
  // Check if test users exist
  const userCount = await User.countDocuments();
  
  if (userCount === 0) {
    const bcrypt = require('bcryptjs');
    const testUsers = [
      {
        name: 'Udit Kumar',
        username: 'udit',
        email: 'u@gmail.com',
        password: await bcrypt.hash('123456', 10),
      },
      {
        name: 'Addi',
        username: 'Addi',
        email: 'a@gmail.com',
        password: await bcrypt.hash('123456', 10),
      },
      {
        name: 'Aditya Kumar',
        username: 'charlie',
        email: 'ak@gmail.com',
        password: await bcrypt.hash('12345', 10),
      },
      {
        name: 'Diana Prince',
        username: 'diana',
        email: 'diana@test.com',
        password: await bcrypt.hash('password123', 10),
      },
    ];
    
    await User.insertMany(testUsers);
    console.log('Test users initialized');
  }
};

module.exports = connectDB;