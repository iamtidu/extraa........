const Group = require('../models/Group');
const GroupMember = require('../models/GroupMember');
const User = require('../models/User');

// Create group
exports.createGroup = async (req, res) => {
  try {
    const { name, description, adminId, memberIds } = req.body;
    
    // Check if admin exists
    const admin = await User.findById(adminId);
    if (!admin) {
      return res.status(404).json({ error: 'Admin user not found' });
    }
    
    // Create group
    const group = new Group({
      name,
      description,
      adminId
    });
    
    await group.save();
    
    // Add admin as accepted member
    await GroupMember.create({
      groupId: group._id,
      userId: adminId,
      status: 'accepted'
    });
    
    // Add other members as pending
    if (memberIds && memberIds.length > 0) {
      const memberPromises = memberIds
        .filter(memberId => memberId !== adminId)
        .map(async (memberId) => {
          const user = await User.findById(memberId);
          if (user) {
            return GroupMember.create({
              groupId: group._id,
              userId: memberId,
              status: 'pending'
            });
          }
        });
      
      await Promise.all(memberPromises);
    }
    
    res.status(201).json({
      success: true,
      groupId: group._id,
      message: 'Group created successfully'
    });
    
  } catch (error) {
    console.error('Create group error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Update group
exports.updateGroup = async (req, res) => {
  try {
    const { groupId } = req.params;
    const updateData = req.body;
    
    const group = await Group.findByIdAndUpdate(
      groupId,
      updateData,
      { new: true, runValidators: true }
    );
    
    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }
    
    res.json({
      success: true,
      group,
      message: 'Group updated successfully'
    });
    
  } catch (error) {
    console.error('Update group error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Delete group
exports.deleteGroup = async (req, res) => {
  try {
    const { groupId } = req.params;
    
    // Delete group and all members
    await Promise.all([
      Group.findByIdAndDelete(groupId),
      GroupMember.deleteMany({ groupId })
    ]);
    
    res.json({
      success: true,
      message: 'Group deleted successfully'
    });
    
  } catch (error) {
    console.error('Delete group error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get user groups
exports.getUserGroups = async (req, res) => {
  try {
    const { userId } = req.params;
    
    // Find groups where user is admin or accepted member
    const [adminGroups, memberGroups] = await Promise.all([
      Group.find({ adminId: userId }),
      GroupMember.find({ 
        userId, 
        status: 'accepted' 
      }).populate('groupId')
    ]);
    
    const memberGroupIds = memberGroups.map(mg => mg.groupId);
    const allGroups = [...adminGroups, ...memberGroupIds];
    
    res.json({
      success: true,
      groups: allGroups
    });
    
  } catch (error) {
    console.error('Get user groups error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get group by ID
exports.getGroupById = async (req, res) => {
  try {
    const { groupId } = req.params;
    
    const group = await Group.findById(groupId);
    
    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }
    
    res.json({
      success: true,
      group
    });
    
  } catch (error) {
    console.error('Get group error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Add group member
exports.addGroupMember = async (req, res) => {
  try {
    const { groupId, userId, status } = req.body;
    
    // Check if group exists
    const group = await Group.findById(groupId);
    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }
    
    // Check if user exists
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Check if already a member
    const existingMember = await GroupMember.findOne({ groupId, userId });
    if (existingMember) {
      return res.status(400).json({ error: 'User already in group' });
    }
    
    // Add member
    const groupMember = new GroupMember({
      groupId,
      userId,
      status: status || 'pending'
    });
    
    await groupMember.save();
    
    res.status(201).json({
      success: true,
      message: 'Member added to group'
    });
    
  } catch (error) {
    console.error('Add group member error:', error);
    if (error.code === 11000) {
      return res.status(400).json({ error: 'User already in group' });
    }
    res.status(500).json({ error: 'Server error' });
  }
};

// Remove group member
exports.removeGroupMember = async (req, res) => {
  try {
    const { groupId, userId } = req.body;
    
    const result = await GroupMember.findOneAndDelete({ groupId, userId });
    
    if (!result) {
      return res.status(404).json({ error: 'Member not found in group' });
    }
    
    res.json({
      success: true,
      message: 'Member removed from group'
    });
    
  } catch (error) {
    console.error('Remove group member error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Update group member status
exports.updateGroupMemberStatus = async (req, res) => {
  try {
    const { groupId, userId } = req.params;
    const { status } = req.body;
    
    const groupMember = await GroupMember.findOneAndUpdate(
      { groupId, userId },
      { status },
      { new: true }
    );
    
    if (!groupMember) {
      return res.status(404).json({ error: 'Group member not found' });
    }
    
    res.json({
      success: true,
      message: `Member status updated to ${status}`
    });
    
  } catch (error) {
    console.error('Update group member status error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get group members
exports.getGroupMembers = async (req, res) => {
  try {
    const { groupId } = req.params;
    
    const members = await GroupMember.find({ 
      groupId, 
      status: 'accepted' 
    }).populate('userId', 'name username email');
    
    const memberUsers = members.map(member => member.userId);
    
    res.json({
      success: true,
      members: memberUsers
    });
    
  } catch (error) {
    console.error('Get group members error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get pending group invites
exports.getPendingGroupInvites = async (req, res) => {
  try {
    const { userId } = req.params;
    
    const pendingInvites = await GroupMember.find({
      userId,
      status: 'pending'
    }).populate('groupId');
    
    const groups = pendingInvites.map(invite => invite.groupId);
    
    res.json({
      success: true,
      groups
    });
    
  } catch (error) {
    console.error('Get pending invites error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Check if user is admin
exports.isUserAdmin = async (req, res) => {
  try {
    const { groupId, userId } = req.params;
    
    const group = await Group.findById(groupId);
    
    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }
    
    const isAdmin = group.adminId.toString() === userId;
    
    res.json({
      success: true,
      isAdmin
    });
    
  } catch (error) {
    console.error('Check admin status error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};