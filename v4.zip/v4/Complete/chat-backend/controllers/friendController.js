const User = require('../models/User');
const FriendRequest = require('../models/FriendRequest');

// Get all users except current user
exports.getAllUsersExcept = async (req, res) => {
  try {
    const { excludedUserId } = req.params;
    
    const users = await User.find({ 
      _id: { $ne: excludedUserId } 
    }).select('-password');
    
    res.json({
      success: true,
      users
    });
    
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get user by ID
exports.getUserById = async (req, res) => {
  try {
    const { userId } = req.params;
    
    const user = await User.findById(userId).select('-password');
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({
      success: true,
      user
    });
    
  } catch (error) {
    console.error('Get user by ID error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Send friend request
exports.sendFriendRequest = async (req, res) => {
  try {
    const { senderId, receiverId } = req.body;
    
    // Check if users exist
    const [sender, receiver] = await Promise.all([
      User.findById(senderId),
      User.findById(receiverId)
    ]);
    
    if (!sender || !receiver) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Check if request already exists
    const existingRequest = await FriendRequest.findOne({
      $or: [
        { senderId, receiverId },
        { senderId: receiverId, receiverId: senderId }
      ]
    });
    
    if (existingRequest) {
      if (existingRequest.status === 'pending') {
        return res.status(400).json({ error: 'Friend request already sent' });
      }
      if (existingRequest.status === 'accepted') {
        return res.status(400).json({ error: 'Already friends' });
      }
    }
    
    // Create new friend request
    const friendRequest = new FriendRequest({
      senderId,
      receiverId,
      status: 'pending'
    });
    
    await friendRequest.save();
    
    res.status(201).json({
      success: true,
      message: 'Friend request sent',
      requestId: friendRequest._id
    });
    
  } catch (error) {
    console.error('Send friend request error:', error);
    if (error.code === 11000) {
      return res.status(400).json({ error: 'Friend request already exists' });
    }
    res.status(500).json({ error: 'Server error' });
  }
};

// Get friend requests for user
exports.getFriendRequestsForUser = async (req, res) => {
  try {
    const { userId } = req.params;
    
    const requests = await FriendRequest.find({
      receiverId: userId,
      status: 'pending'
    }).populate('senderId', 'name username email');
    
    res.json({
      success: true,
      requests
    });
    
  } catch (error) {
    console.error('Get friend requests error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Update friend request status
exports.updateFriendRequestStatus = async (req, res) => {
  try {
    const { requestId } = req.params;
    const { status } = req.body;
    
    const validStatuses = ['accepted', 'rejected', 'removed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    
    const friendRequest = await FriendRequest.findByIdAndUpdate(
      requestId,
      { status },
      { new: true }
    );
    
    if (!friendRequest) {
      return res.status(404).json({ error: 'Friend request not found' });
    }
    
    res.json({
      success: true,
      message: `Friend request ${status}`
    });
    
  } catch (error) {
    console.error('Update friend request error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get friends list
exports.getFriends = async (req, res) => {
  try {
    const { userId } = req.params;
    
    // Find accepted friend requests
    const friendRequests = await FriendRequest.find({
      status: 'accepted',
      $or: [
        { senderId: userId },
        { receiverId: userId }
      ]
    }).populate('senderId receiverId', 'name username email');
    
    // Extract friend users
    const friends = friendRequests.map(request => {
      return request.senderId._id.toString() === userId 
        ? request.receiverId 
        : request.senderId;
    });
    
    res.json({
      success: true,
      friends
    });
    
  } catch (error) {
    console.error('Get friends error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Check if friend request is sent
exports.isFriendRequestSent = async (req, res) => {
  try {
    const { senderId, receiverId } = req.params;
    
    const existingRequest = await FriendRequest.findOne({
      senderId,
      receiverId,
      status: 'pending'
    });
    
    res.json({
      success: true,
      isSent: !!existingRequest
    });
    
  } catch (error) {
    console.error('Check friend request error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get friend request ID between users
exports.getFriendRequestIdBetweenUsers = async (req, res) => {
  try {
    const { user1, user2 } = req.params;
    
    const friendRequest = await FriendRequest.findOne({
      status: 'accepted',
      $or: [
        { senderId: user1, receiverId: user2 },
        { senderId: user2, receiverId: user1 }
      ]
    });
    
    res.json({
      success: true,
      requestId: friendRequest?._id || null
    });
    
  } catch (error) {
    console.error('Get friend request ID error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};