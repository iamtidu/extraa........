const Message = require('../models/Message');
const User = require('../models/User');

// Save message
exports.saveMessage = async (req, res) => {
  try {
    const { senderId, receiverId, groupId, content, chatId } = req.body;
    
    // Generate chatId if not provided
    let finalChatId = chatId;
    if (!finalChatId) {
      if (groupId) {
        finalChatId = `group_${groupId}`;
      } else if (receiverId) {
        const users = [senderId, receiverId].sort();
        finalChatId = `chat_${users[0]}_${users[1]}`;
      } else {
        return res.status(400).json({ error: 'Invalid chat parameters' });
      }
    }
    
    const message = new Message({
      senderId,
      receiverId,
      groupId,
      content,
      chatId: finalChatId,
      isRead: false
    });
    
    await message.save();
    
    // Populate sender details
    await message.populate('senderId', 'name username');
    
    res.status(201).json({
      success: true,
      message
    });
    
  } catch (error) {
    console.error('Save message error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get messages for chat
exports.getMessages = async (req, res) => {
  try {
    const { chatId } = req.params;
    
    const messages = await Message.find({ chatId })
      .populate('senderId', 'name username')
      .sort({ createdAt: 1 })
      .limit(100); // Limit to last 100 messages
    
    res.json({
      success: true,
      messages
    });
    
  } catch (error) {
    console.error('Get messages error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Clear messages for chat
exports.clearMessages = async (req, res) => {
  try {
    const { chatId } = req.params;
    
    await Message.deleteMany({ chatId });
    
    res.json({
      success: true,
      message: 'Messages cleared'
    });
    
  } catch (error) {
    console.error('Clear messages error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get all chat IDs for user
exports.getAllChatIds = async (req, res) => {
  try {
    const { userId } = req.params;
    
    // Find all chats where user is participant
    const messages = await Message.find({
      $or: [
        { senderId: userId },
        { receiverId: userId },
        { groupId: { $exists: true } } // User might be in groups
      ]
    }).select('chatId');
    
    // Extract unique chat IDs
    const chatIds = [...new Set(messages.map(msg => msg.chatId))];
    
    res.json({
      success: true,
      chatIds
    });
    
  } catch (error) {
    console.error('Get chat IDs error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get last message for chat
exports.getLastMessage = async (req, res) => {
  try {
    const { chatId } = req.params;
    
    const lastMessage = await Message.findOne({ chatId })
      .populate('senderId', 'name username')
      .sort({ createdAt: -1 });
    
    res.json({
      success: true,
      lastMessage
    });
    
  } catch (error) {
    console.error('Get last message error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Mark messages as read
exports.markAsRead = async (req, res) => {
  try {
    const { chatId, userId } = req.params;
    
    await Message.updateMany(
      { 
        chatId, 
        senderId: { $ne: userId },
        isRead: false 
      },
      { isRead: true }
    );
    
    res.json({
      success: true,
      message: 'Messages marked as read'
    });
    
  } catch (error) {
    console.error('Mark as read error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get unread count
exports.getUnreadCount = async (req, res) => {
  try {
    const { chatId, userId } = req.params;
    
    const count = await Message.countDocuments({
      chatId,
      senderId: { $ne: userId },
      isRead: false
    });
    
    res.json({
      success: true,
      count
    });
    
  } catch (error) {
    console.error('Get unread count error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};