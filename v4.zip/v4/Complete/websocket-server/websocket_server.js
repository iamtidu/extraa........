// /**
//  * Simple WebSocket Server for Real-Time Chat
//  * 
//  * Install dependencies:
//  * npm install ws
//  * 
//  * Run the server:
//  * node websocket_server.js
//  * 
//  * The server will run on ws://localhost:8080
//  */

// const WebSocket = require('ws');
// const http = require('http');

// const server = http.createServer();
// const wss = new WebSocket.Server({ server });

// // Store all connected clients
// const clients = new Set();

// // Handle client connections
// wss.on('connection', (ws) => {
//   console.log('New client connected');
//   clients.add(ws);

//   // Handle incoming messages from clients
//   ws.on('message', (data) => {
//     try {
//       const message = JSON.parse(data);
//       console.log('Received message:', message);

//       // Broadcast message to all connected clients
//       clients.forEach((client) => {
//         if (client.readyState === WebSocket.OPEN) {
//           client.send(JSON.stringify(message));
//         }
//       });
//     } catch (error) {
//       console.error('Error parsing message:', error);
//     }
//   });

//   // Handle client disconnection
//   ws.on('close', () => {
//     console.log('Client disconnected');
//     clients.delete(ws);
//   });

//   // Handle errors
//   ws.on('error', (error) => {
//     console.error('WebSocket error:', error);
//   });
// });

// // Start the server
// const PORT = process.env.PORT || 8080;
// server.listen(PORT, () => {
//   console.log(`WebSocket server running on ws://localhost:${PORT}`);
// });

const WebSocket = require('ws');
const http = require('http');

// Create HTTP server
const server = http.createServer();
const wss = new WebSocket.Server({ server });

// Store connected clients
const clients = new Map();

// Store message history
const messageHistory = new Map(); // chatId -> [messages]

wss.on('connection', (ws, req) => {
  console.log('New client connected');
  
  // Generate a unique ID for this connection
  const clientId = Date.now().toString();
  clients.set(clientId, ws);
  
  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);
      console.log('Received:', data);
      
      // Handle different message types
      switch (data.type) {
        case 'register':
          // Associate user ID with WebSocket connection
          ws.userId = data.userId;
          ws.chatId = data.chatId;
          console.log(`User ${data.userId} registered for chat ${data.chatId}`);
          break;
          
        case 'message':
          // Store message in history
          const chatId = data.chatId;
          if (!messageHistory.has(chatId)) {
            messageHistory.set(chatId, []);
          }
          messageHistory.get(chatId).push(data);
          
          // Broadcast to all clients in this chat
          clients.forEach((client, id) => {
            if (client.readyState === WebSocket.OPEN && 
                client.chatId === chatId && 
                id !== clientId) {
              client.send(JSON.stringify({
                ...data,
                timestamp: new Date().toISOString()
              }));
            }
          });
          break;
          
        case 'history':
          // Send message history for a chat
          const history = messageHistory.get(data.chatId) || [];
          ws.send(JSON.stringify({
            type: 'history',
            chatId: data.chatId,
            messages: history.slice(-50) // Last 50 messages
          }));
          break;
          
        case 'typing':
          // Broadcast typing indicator
          clients.forEach((client, id) => {
            if (client.readyState === WebSocket.OPEN && 
                client.chatId === data.chatId && 
                id !== clientId) {
              client.send(JSON.stringify({
                type: 'typing',
                userId: data.userId,
                userName: data.userName,
                isTyping: data.isTyping
              }));
            }
          });
          break;
      }
    } catch (error) {
      console.error('Error processing message:', error);
    }
  });
  
  ws.on('close', () => {
    console.log('Client disconnected');
    clients.delete(clientId);
  });
  
  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });
  
  // Send welcome message
  ws.send(JSON.stringify({
    type: 'connected',
    message: 'Connected to chat server',
    timestamp: new Date().toISOString()
  }));
});

// Start server
const PORT = 8080;
server.listen(PORT, () => {
  console.log(`WebSocket server running on ws://localhost:${PORT}`);
});

// Keep alive ping every 30 seconds
setInterval(() => {
  clients.forEach((client, id) => {
    if (client.readyState === WebSocket.OPEN) {
      client.ping();
    }
  });
}, 30000);