import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/group.dart';
import '../../models/user.dart';
import '../../providers/auth_provider.dart';
import '../../providers/group_provider.dart';
import '../../providers/user_provider.dart';
import '../../utils/app_constants.dart';
import 'add_members_to_group_screen.dart'; // To add new members

class GroupDetailsScreen extends StatefulWidget {
  static const routeName = '/group-details';

  const GroupDetailsScreen({super.key});

  @override
  State<GroupDetailsScreen> createState() => _GroupDetailsScreenState();
}

class _GroupDetailsScreenState extends State<GroupDetailsScreen> {
  final _formKey = GlobalKey<FormState>();
  late Group _currentGroup;
  late TextEditingController _nameController;
  late TextEditingController _descriptionController;
  String _groupPicture = ''; // Empty string, UI will show initials

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _currentGroup = ModalRoute.of(context)!.settings.arguments as Group;
      _nameController = TextEditingController(text: _currentGroup.name);
      _descriptionController = TextEditingController(text: _currentGroup.description);
      _groupPicture = _currentGroup.groupPicture;
      _loadMembers();
    });
  }

  Future<void> _loadMembers() async {
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    await groupProvider.loadGroupMembers(_currentGroup.id!);
  }

  void _saveGroupDetails() async {
    if (_formKey.currentState!.validate()) {
      final groupProvider = Provider.of<GroupProvider>(context, listen: false);
      final updatedGroup = _currentGroup.copyWith(
        name: _nameController.text,
        description: _descriptionController.text,
        groupPicture: _groupPicture,
      );

      await groupProvider.updateGroupDetails(updatedGroup);
      setState(() {
        _currentGroup = updatedGroup; // Update local state as well
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Group details updated!')),
      );
    }
  }

  void _removeMember(int userId) async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    final currentUserId = authProvider.currentUser!.id!;

    if (_currentGroup.adminId != currentUserId) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Only group admin can remove members.')),
      );
      return;
    }

    // Prevent admin from removing themselves unless they are the only member
    if (userId == currentUserId && groupProvider.groupMembers.length > 1) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Admin cannot remove themselves if other members exist.')),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove Member'),
        content: const Text('Are you sure you want to remove this member?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              await groupProvider.removeMemberFromGroup(_currentGroup.id!, userId);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Member removed.')),
              );
              Navigator.of(ctx).pop();
            },
            child: const Text('Remove'),
          ),
        ],
      ),
    );
  }

  void _leaveGroup() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    final currentUserId = authProvider.currentUser!.id!;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Leave Group'),
        content: const Text('Are you sure you want to leave this group?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              // If admin is leaving and they are the only member, delete group
              if (_currentGroup.adminId == currentUserId && groupProvider.groupMembers.length == 1) {
                await groupProvider.deleteGroup(_currentGroup.id!); // Assuming deleteGroup method in GroupProvider
              } else {
                await groupProvider.removeMemberFromGroup(_currentGroup.id!, currentUserId);
                // If admin leaves, promote another member to admin or handle
                // (for simplicity, we won't handle admin promotion in this demo)
              }
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('You have left the group.')),
              );
              Navigator.of(ctx).pop(); // Close dialog
              Navigator.of(context).pop(); // Go back to home screen
            },
            child: const Text('Leave'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final groupProvider = Provider.of<GroupProvider>(context);
    final userProvider = Provider.of<UserProvider>(context);
    final currentUserId = authProvider.currentUser!.id!;
    final isAdmin = _currentGroup.adminId == currentUserId;

    // Refresh members on UI updates for dynamic changes
    groupProvider.loadGroupMembers(_currentGroup.id!);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Group Details'),
        actions: [
          if (isAdmin)
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: _saveGroupDetails,
            ),
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: _leaveGroup,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: GestureDetector(
                  onTap: () {
                    if (isAdmin) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Image picker not implemented in this demo.')),
                      );
                    }
                  },
                  child: CircleAvatar(
                    radius: 70,
                    backgroundImage: AssetImage(_groupPicture),
                    child: isAdmin
                        ? const Align(
                            alignment: Alignment.bottomRight,
                            child: CircleAvatar(
                              radius: 20,
                              backgroundColor: Colors.blue,
                              child: Icon(Icons.camera_alt, color: Colors.white, size: 20),
                            ),
                          )
                        : null,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _nameController,
                readOnly: !isAdmin,
                decoration: InputDecoration(
                  labelText: 'Group Name',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.group),
                  fillColor: isAdmin ? Colors.white : Colors.grey[200],
                  filled: true,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a group name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _descriptionController,
                readOnly: !isAdmin,
                decoration: InputDecoration(
                  labelText: 'Description',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.description),
                  fillColor: isAdmin ? Colors.white : Colors.grey[200],
                  filled: true,
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Members (${groupProvider.groupMembers.length})',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  if (isAdmin)
                    TextButton.icon(
                      icon: const Icon(Icons.person_add),
                      label: const Text('Add'),
                      onPressed: () async {
                        await Navigator.of(context).pushNamed(
                          AddMembersToGroupScreen.routeName,
                          arguments: _currentGroup,
                        );
                        // Refresh members after adding
                        await _loadMembers();
                      },
                    ),
                ],
              ),
              const Divider(),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: groupProvider.groupMembers.length,
                itemBuilder: (context, index) {
                  final member = groupProvider.groupMembers[index];
                  final user = userProvider.getUserById(member.userId);
                  if (user == null) return const SizedBox.shrink();

                  return ListTile(
                    leading: CircleAvatar(
                      backgroundImage: AssetImage(user.profilePicture),
                    ),
                    title: Text(user.username),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (_currentGroup.adminId == user.id)
                          const Chip(
                            label: Text('Admin'),
                            backgroundColor: Colors.blueAccent,
                            labelStyle: TextStyle(color: Colors.white),
                          ),
                        if (isAdmin && user.id != currentUserId && _currentGroup.adminId != user.id)
                          IconButton(
                            icon: const Icon(Icons.remove_circle_outline, color: Colors.red),
                            onPressed: () => _removeMember(user.id!),
                          ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }
}
