class Message {
  final int? id;
  final int senderId;
  final int? receiverId; // For one-to-one chat
  final int? groupId; // For group chat
  final String content;
  final DateTime timestamp;

  Message({
    this.id,
    required this.senderId,
    this.receiverId,
    this.groupId,
    required this.content,
    required this.timestamp,
  }) : assert(receiverId != null || groupId != null,
            'Message must have either a receiverId or a groupId');

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'senderId': senderId,
      'receiverId': receiverId,
      'groupId': groupId,
      'content': content,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  factory Message.fromMap(Map<String, dynamic> map) {
    return Message(
      id: map['id'],
      senderId: map['senderId'],
      receiverId: map['receiverId'],
      groupId: map['groupId'],
      content: map['content'],
      timestamp: DateTime.parse(map['timestamp']),
    );
  }

  Message copyWith({
    int? id,
    int? senderId,
    int? receiverId,
    int? groupId,
    String? content,
    DateTime? timestamp,
  }) {
    return Message(
      id: id ?? this.id,
      senderId: senderId ?? this.senderId,
      receiverId: receiverId ?? this.receiverId,
      groupId: groupId ?? this.groupId,
      content: content ?? this.content,
      timestamp: timestamp ?? this.timestamp,
    );
  }
}
