import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../models/message.dart';

class WebSocketService {
  static final WebSocketService _instance = WebSocketService._internal();
  factory WebSocketService() => _instance;
  WebSocketService._internal();

  WebSocketChannel? _channel;
  late StreamController<Message> _messageController;
  bool _isConnected = false;

  bool get isConnected => _isConnected;
  Stream<Message> get messageStream => _messageController.stream;

  Future<void> connect(String wsUrl) async {
    try {
      if (_isConnected) return;

      _messageController = StreamController<Message>.broadcast();

      // Connect to WebSocket
      _channel = WebSocketChannel.connect(Uri.parse(wsUrl));

      // Listen for incoming messages
      _channel?.stream.listen(
        (message) {
          try {
            final messageData = jsonDecode(message);
            final parsedMessage = Message.fromMap(messageData);
            _messageController.add(parsedMessage);
          } catch (e) {
            print('Error parsing message: $e');
          }
        },
        onError: (error) {
          print('WebSocket error: $error');
          _isConnected = false;
          // Try to reconnect after 5 seconds
          Future.delayed(const Duration(seconds: 5), () => connect(wsUrl));
        },
        onDone: () {
          print('WebSocket closed');
          _isConnected = false;
          // Try to reconnect after 5 seconds
          Future.delayed(const Duration(seconds: 5), () => connect(wsUrl));
        },
      );

      _isConnected = true;
      print('WebSocket connected to $wsUrl');
    } catch (e) {
      print('WebSocket connection error: $e');
      _isConnected = false;
    }
  }

  Future<void> sendMessage(Message message) async {
    if (!_isConnected || _channel == null) {
      print('WebSocket not connected. Message not sent.');
      return;
    }

    try {
      final messageJson = jsonEncode(message.toMap());
      _channel!.sink.add(messageJson);
    } catch (e) {
      print('Error sending message: $e');
    }
  }

  Future<void> disconnect() async {
    try {
      _isConnected = false;
      await _channel?.sink.close();
      await _messageController.close();
      _channel = null;
      print('WebSocket disconnected');
    } catch (e) {
      print('Error disconnecting WebSocket: $e');
    }
  }

  void sendCustomMessage(Map<String, dynamic> data) {
    if (!_isConnected || _channel == null) {
      print('WebSocket not connected');
      return;
    }
    try {
      _channel!.sink.add(jsonEncode(data));
    } catch (e) {
      print('Error sending custom message: $e');
    }
  }
}
