import '../models/user.dart';
import 'database_helper.dart';

class UserDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insertUser(User user) async {
    return await _dbHelper.insertUser(user);
  }

  Future<User?> getUserById(int id) async {
    return await _dbHelper.getUserById(id);
  }

  Future<User?> getUserByUsername(String username) async {
    final users = await _dbHelper.getAllUsers();
    try {
      return users.firstWhere((user) => user.username == username);
    } catch (e) {
      return null;
    }
  }

  Future<List<User>> getAllUsers() async {
    return await _dbHelper.getAllUsers();
  }

  Future<int> updateUser(User user) async {
    await _dbHelper.updateUser(user);
    return 1; // Return 1 for success
  }

  Future<int> deleteUser(int id) async {
    await _dbHelper.deleteUser(id);
    return 1; // Return 1 for success
  }
}
