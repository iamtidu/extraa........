import '../models/message.dart';
import 'database_helper.dart';

class MessageDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insertMessage(Message message) async {
    return await _dbHelper.insertMessage(message);
  }

  Future<List<Message>> getOneToOneMessages(int user1Id, int user2Id) async {
    return await _dbHelper.getOneToOneMessages(user1Id, user2Id);
  }

  Future<List<Message>> getGroupMessages(int groupId) async {
    return await _dbHelper.getGroupMessages(groupId);
  }

  Future<List<Message>> getAllMessages() async {
    final messages = <Message>[];
    final messageMap = _dbHelper.messagesBox.values.toList();
    for (var msg in messageMap) {
      messages.add(Message.fromMap(msg.cast<String, dynamic>()));
    }
    return messages;
  }
}
