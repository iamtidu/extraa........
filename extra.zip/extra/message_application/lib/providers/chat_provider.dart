import 'dart:async';
import 'package:flutter/material.dart';
import '../models/message.dart';
import '../db/message_dao.dart';
import '../services/websocket_service.dart';

class ChatProvider with ChangeNotifier {
  final MessageDao _messageDao = MessageDao();
  final WebSocketService _wsService = WebSocketService();
  final StreamController<List<Message>> _oneToOneChatController = StreamController<List<Message>>.broadcast();
  final StreamController<List<Message>> _groupChatController = StreamController<List<Message>>.broadcast();
  late StreamSubscription _wsMessageSubscription;

  // Streams for real-time updates
  Stream<List<Message>> get oneToOneChatStream => _oneToOneChatController.stream;
  Stream<List<Message>> get groupChatStream => _groupChatController.stream;
  Stream<Message> get messageStream => _wsService.messageStream;

  List<Message> _messages = [];
  int? _currentOneToOnePeerId;
  int? _currentGroupId;

  List<Message> get messages => _messages;

  ChatProvider() {
    _initializeWebSocket();
  }

  Future<void> _initializeWebSocket() async {
    // Connect to WebSocket server
    // For local development, use: ws://localhost:8080
    // Update the URL based on your server setup
    const String wsUrl = 'ws://localhost:8080'; // Change this to your WebSocket server URL
    
    try {
      await _wsService.connect(wsUrl);
      
      // Listen to incoming WebSocket messages
      _wsMessageSubscription = _wsService.messageStream.listen((message) {
        _handleIncomingMessage(message);
      });
    } catch (e) {
      print('Error initializing WebSocket: $e');
      // Fall back to local updates if WebSocket fails
    }
  }

  void _handleIncomingMessage(Message message) async {
    // Check if message already exists to avoid duplicates
    final isDuplicate = _messages.any((msg) => 
        msg.senderId == message.senderId &&
        msg.receiverId == message.receiverId &&
        msg.groupId == message.groupId &&
        msg.content == message.content &&
        msg.timestamp.difference(message.timestamp).inSeconds < 2); // Within 2 seconds = likely duplicate
    
    if (isDuplicate) {
      print('Duplicate message ignored');
      return;
    }
    
    // Save received message to local database if not already saved
    int messageId;
    if (message.id == null) {
      messageId = await _messageDao.insertMessage(message);
      if (messageId <= 0) {
        print('Failed to save message');
        return;
      }
    } else {
      messageId = message.id!;
      // Still save it in case it's from another client
      await _messageDao.insertMessage(message);
    }
    
    final savedMessage = message.copyWith(id: messageId);
    
    // Add to messages list if not already there
    if (!_messages.any((msg) => msg.id == messageId)) {
      _messages.add(savedMessage);
    }
    
    // Broadcast to appropriate stream
    if (message.groupId != null) {
      if (_currentGroupId == message.groupId) {
        _groupChatController.add(List.from(_messages));
      }
    } else if (message.receiverId != null && _currentOneToOnePeerId != null) {
      if ((message.receiverId == _currentOneToOnePeerId || message.senderId == _currentOneToOnePeerId)) {
        _oneToOneChatController.add(List.from(_messages));
      }
    }
    
    notifyListeners();
  }

  // Load messages for a one-to-one chat
  Future<List<Message>> loadOneToOneMessages(int user1Id, int user2Id) async {
    _currentOneToOnePeerId = user2Id;
    _messages = await _messageDao.getOneToOneMessages(user1Id, user2Id);
    _messages.sort((a, b) => a.timestamp.compareTo(b.timestamp));
    print('Loaded ${_messages.length} messages for conversation between $user1Id and $user2Id');
    _oneToOneChatController.add(List.from(_messages));
    notifyListeners();
    return _messages;
  }

  // Send a one-to-one message
  Future<void> sendOneToOneMessage(int senderId, int receiverId, String content) async {
    final message = Message(
      senderId: senderId,
      receiverId: receiverId,
      content: content,
      timestamp: DateTime.now(),
    );
    
    try {
      // Save to local database first
      final id = await _messageDao.insertMessage(message);
      if (id > 0) {
        final newMessageWithId = message.copyWith(id: id);
        _messages.add(newMessageWithId);
        print('One-to-one message saved locally with ID: $id');
        
        // Send via WebSocket to other clients
        _wsService.sendMessage(newMessageWithId);
        
        _oneToOneChatController.add(List.from(_messages));
        notifyListeners();
      } else {
        print('Failed to save one-to-one message');
      }
    } catch (e) {
      print('Error sending one-to-one message: $e');
    }
  }

  // Load messages for a group chat
  Future<List<Message>> loadGroupMessages(int groupId) async {
    _currentGroupId = groupId;
    _messages = await _messageDao.getGroupMessages(groupId);
    _messages.sort((a, b) => a.timestamp.compareTo(b.timestamp));
    print('Loaded ${_messages.length} messages for group $groupId');
    _groupChatController.add(List.from(_messages));
    notifyListeners();
    return _messages;
  }

  // Send a group message
  Future<void> sendGroupMessage(int senderId, int groupId, String content) async {
    final message = Message(
      senderId: senderId,
      groupId: groupId,
      content: content,
      timestamp: DateTime.now(),
    );
    
    try {
      // Save to local database first
      final id = await _messageDao.insertMessage(message);
      if (id > 0) {
        final newMessageWithId = message.copyWith(id: id);
        _messages.add(newMessageWithId);
        print('Group message saved locally with ID: $id');
        
        // Send via WebSocket to other clients
        _wsService.sendMessage(newMessageWithId);
        
        _groupChatController.add(List.from(_messages));
        notifyListeners();
      } else {
        print('Failed to save group message');
      }
    } catch (e) {
      print('Error sending group message: $e');
    }
  }

  @override
  void dispose() {
    _wsMessageSubscription.cancel();
    _oneToOneChatController.close();
    _groupChatController.close();
    _wsService.disconnect();
    super.dispose();
  }
}
