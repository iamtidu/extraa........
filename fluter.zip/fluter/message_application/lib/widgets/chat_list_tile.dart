import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/message.dart';
import '../utils/app_constants.dart';

class ChatListTile extends StatelessWidget {
  final String avatarUrl;
  final String title;
  final Message? lastMessage;
  final VoidCallback onTap;

  const ChatListTile({
    super.key,
    required this.avatarUrl,
    required this.title,
    this.lastMessage,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: avatarUrl.isNotEmpty ? AssetImage(avatarUrl) : null,
        backgroundColor: Theme.of(context).primaryColor.withOpacity(0.2),
        child: avatarUrl.isEmpty
            ? Text(
                title.isNotEmpty ? title[0].toUpperCase() : '?',
                style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
              )
            : null,
      ),
      title: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: lastMessage != null
          ? Text(
              lastMessage!.content,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: Colors.grey[600]),
            )
          : const Text(
              'No messages yet',
              style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey),
            ),
      trailing: lastMessage != null
          ? Text(
              DateFormat('hh:mm a').format(lastMessage!.timestamp),
              style: TextStyle(fontSize: 12, color: Colors.grey[500]),
            )
          : null,
      onTap: onTap,
    );
  }
}
