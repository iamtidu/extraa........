import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'db/database_helper.dart'; // Initialize DB
import 'providers/auth_provider.dart';
import 'providers/chat_provider.dart';
import 'providers/group_provider.dart';
import 'providers/user_provider.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/register_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/chat/chat_screen.dart';
import 'screens/profile/edit_profile_screen.dart';
import 'screens/group/create_group_screen.dart';
import 'screens/group/group_details_screen.dart';
import 'screens/group/add_members_to_group_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Hive database
  await DatabaseHelper().initDatabase();
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProvider(create: (_) => ChatProvider()),
        ChangeNotifierProvider(create: (_) => GroupProvider()),
      ],
      child: Consumer<AuthProvider>(
        builder: (ctx, auth, _) => MaterialApp(
          title: 'Chat Application',
          theme: ThemeData(
            primarySwatch: Colors.blue,
            visualDensity: VisualDensity.adaptivePlatformDensity,
            appBarTheme: const AppBarTheme(
              backgroundColor: Colors.blueAccent,
              foregroundColor: Colors.white,
            ),
            floatingActionButtonTheme: const FloatingActionButtonThemeData(
              backgroundColor: Colors.blueAccent,
              foregroundColor: Colors.white,
            ),
            elevatedButtonTheme: ElevatedButtonThemeData(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
          home: auth.isAuthenticated ? const HomeScreen() : const LoginScreen(),
          routes: {
            LoginScreen.routeName: (ctx) => const LoginScreen(),
            RegisterScreen.routeName: (ctx) => const RegisterScreen(),
            HomeScreen.routeName: (ctx) => const HomeScreen(),
            ChatScreen.routeName: (ctx) => const ChatScreen(),
            EditProfileScreen.routeName: (ctx) => const EditProfileScreen(),
            CreateGroupScreen.routeName: (ctx) => const CreateGroupScreen(),
            GroupDetailsScreen.routeName: (ctx) => const GroupDetailsScreen(),
            AddMembersToGroupScreen.routeName: (ctx) => const AddMembersToGroupScreen(),
          },
          onGenerateRoute: (settings) {
            // A simple onGenerateRoute for dynamic arguments (e.g., chat screen)
            if (settings.name == ChatScreen.routeName) {
              final args = settings.arguments as Map<String, dynamic>;
              return MaterialPageRoute(builder: (context) {
                return ChatScreen(key: ValueKey(args['receiverUser']?.id ?? args['chatGroup']?.id));
              });
            }
            return null; // Let the default routing handle other routes
          },
        ),
      ),
    );
  }
}
