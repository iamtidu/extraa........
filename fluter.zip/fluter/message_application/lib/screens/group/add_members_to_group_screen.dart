import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/group.dart';
import '../../models/user.dart';
import '../../providers/auth_provider.dart';
import '../../providers/group_provider.dart';
import '../../providers/user_provider.dart';

class AddMembersToGroupScreen extends StatefulWidget {
  static const routeName = '/add-members-to-group';

  const AddMembersToGroupScreen({super.key});

  @override
  State<AddMembersToGroupScreen> createState() => _AddMembersToGroupScreenState();
}

class _AddMembersToGroupScreenState extends State<AddMembersToGroupScreen> {
  late Group _group;
  List<User> _selectedUsersToAdd = [];
  Set<int> _currentGroupMemberIds = {}; // To store IDs of users already in the group

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _group = ModalRoute.of(context)!.settings.arguments as Group;
      _loadExistingMembers();
    });
  }

  Future<void> _loadExistingMembers() async {
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    await groupProvider.loadGroupMembers(_group.id!);
    setState(() {
      _currentGroupMemberIds = groupProvider.groupMembers.map((m) => m.userId).toSet();
    });
  }

  void _addSelectedMembers() async {
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    for (var user in _selectedUsersToAdd) {
      await groupProvider.addMemberToGroup(_group.id!, user.id!);
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${_selectedUsersToAdd.length} members added to group.')),
    );
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final userProvider = Provider.of<UserProvider>(context);
    final currentUserId = authProvider.currentUser!.id!;

    final availableUsers = userProvider.allUsers.where((user) =>
        user.id != currentUserId && // Don't show current user
        !_currentGroupMemberIds.contains(user.id) // Don't show users already in the group
    ).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('Add Members to ${_group.name}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.check),
            onPressed: _addSelectedMembers,
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              'Select users to add (${_selectedUsersToAdd.length} selected)',
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ),
          Expanded(
            child: availableUsers.isEmpty
                ? const Center(child: Text('No new users available to add.'))
                : ListView.builder(
                    itemCount: availableUsers.length,
                    itemBuilder: (context, index) {
                      final user = availableUsers[index];
                      final isSelected = _selectedUsersToAdd.contains(user);

                      return CheckboxListTile(
                        title: Text(user.username),
                        subtitle: Text(user.status),
                        secondary: CircleAvatar(
                          backgroundImage: AssetImage(user.profilePicture),
                        ),
                        value: isSelected,
                        onChanged: (bool? checked) {
                          setState(() {
                            if (checked == true) {
                              _selectedUsersToAdd.add(user);
                            } else {
                              _selectedUsersToAdd.remove(user);
                            }
                          });
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
