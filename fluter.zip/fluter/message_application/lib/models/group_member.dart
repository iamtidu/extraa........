class GroupMember {
  final int? id;
  final int groupId;
  final int userId;
  final DateTime joinedAt;

  GroupMember({
    this.id,
    required this.groupId,
    required this.userId,
    required this.joinedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'groupId': groupId,
      'userId': userId,
      'joinedAt': joinedAt.toIso8601String(),
    };
  }

  factory GroupMember.fromMap(Map<String, dynamic> map) {
    return GroupMember(
      id: map['id'],
      groupId: map['groupId'],
      userId: map['userId'],
      joinedAt: DateTime.parse(map['joinedAt']),
    );
  }
}
