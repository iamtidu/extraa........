class AppConstants {
  static const String appName = 'Chat App';
  static const String avatarPlaceholder = ''; // Use empty string, UI will show initials
}
