import 'package:flutter/material.dart';
import '../models/user.dart';
import '../db/user_dao.dart';

class UserProvider with ChangeNotifier {
  final UserDao _userDao = UserDao();
  List<User> _allUsers = [];

  List<User> get allUsers => _allUsers;

  UserProvider() {
    _loadUsers();
  }

  Future<void> _loadUsers() async {
    _allUsers = await _userDao.getAllUsers();
    notifyListeners();
  }

  Future<void> reloadUsers() async {
    _allUsers = await _userDao.getAllUsers();
    notifyListeners();
  }

  User? getUserById(int userId) {
    try {
      return _allUsers.firstWhere((user) => user.id == userId);
    } catch (e) {
      return null;
    }
  }

  Future<void> addUser(User user) async {
    final id = await _userDao.insertUser(user);
    if (id > 0) {
      _allUsers.add(user.copyWith(id: id));
      notifyListeners();
    }
  }

  Future<void> updateUser(User user) async {
    await _userDao.updateUser(user);
    final index = _allUsers.indexWhere((u) => u.id == user.id);
    if (index != -1) {
      _allUsers[index] = user;
      notifyListeners();
    }
  }
}
