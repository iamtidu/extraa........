import 'package:flutter/material.dart';
import '../models/user.dart';
import '../db/user_dao.dart';

class AuthProvider with ChangeNotifier {
  User? _currentUser;
  final UserDao _userDao = UserDao();

  User? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null;

  // Initialize AuthProvider
  AuthProvider() {
    _loadCurrentUser();
  }

  Future<void> _loadCurrentUser() async {
    // Check if there's a logged-in user (this would be stored in a real app with SharedPreferences)
    // For demo purposes, we just try to reload from database if any
    // In production, store userId in SharedPreferences
  }

  Future<bool> login(String username) async {
    final user = await _userDao.getUserByUsername(username);
    if (user != null) {
      _currentUser = user;
      notifyListeners();
      return true;
    }
    return false;
  }

  Future<bool> register(String username) async {
    // Check if username already exists
    final existingUser = await _userDao.getUserByUsername(username);
    if (existingUser != null) {
      return false; // Username already taken
    }

    final newUser = User(username: username);
    final id = await _userDao.insertUser(newUser);
    if (id > 0) {
      _currentUser = newUser.copyWith(id: id);
      notifyListeners();
      return true;
    }
    return false;
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }

  Future<void> updateProfile(User updatedUser) async {
    if (_currentUser != null && updatedUser.id == _currentUser!.id) {
      await _userDao.updateUser(updatedUser);
      _currentUser = updatedUser;
      notifyListeners();
    }
  }
}
