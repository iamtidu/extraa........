# WebSocket Real-Time Chat Setup Guide

## Overview
This chat application now uses WebSocket for true real-time communication. Messages are sent and received instantly without polling.

## Architecture

```
Flutter Web App (Client)
        ↓
WebSocketChannel (web_socket_channel package)
        ↓
WebSocket Server (Node.js / ws library)
        ↓
All Connected Clients
```

## Setup Instructions

### 1. Install Node.js
Download and install Node.js from https://nodejs.org/

### 2. Set Up WebSocket Server

In the project root directory:

```bash
# Create a directory for the server
mkdir websocket-server
cd websocket-server

# Initialize npm project
npm init -y

# Install WebSocket library
npm install ws
```

### 3. Start the WebSocket Server

Copy the `websocket_server.js` file to the `websocket-server` directory.

```bash
# Run the server
node websocket_server.js
```

You should see:
```
WebSocket server running on ws://localhost:8080
```

### 4. Update Flutter App Configuration

The app is configured to connect to `ws://localhost:8080` by default.

**To change the server URL**, edit the following in `lib/providers/chat_provider.dart`:

```dart
const String wsUrl = 'ws://localhost:8080'; // Change this URL
```

### 5. Run the Flutter App

```bash
# Run the web app
flutter run -d chrome
```

## Features

✅ **Real-Time Messages**: Messages appear instantly without refresh
✅ **Bidirectional Communication**: Send and receive messages via WebSocket
✅ **Automatic Reconnection**: If connection drops, it attempts to reconnect after 5 seconds
✅ **Local Storage Fallback**: Messages are also saved to Hive local database
✅ **Multiple Clients**: All connected clients receive messages instantly
✅ **Error Handling**: Graceful error handling and reconnection logic

## Testing

### Test with Multiple Browsers

1. Start the WebSocket server:
   ```bash
   node websocket_server.js
   ```

2. Run the Flutter app:
   ```bash
   flutter run -d chrome
   ```

3. Open the app in multiple browser tabs or different browsers

4. Log in as different users in each browser

5. Send a message from one browser - it should appear instantly in the other browser

### Test Message Flow

- **Sender**: User writes message and clicks Send
- **Local Save**: Message is saved to Hive database
- **WebSocket Send**: Message is sent via WebSocket to server
- **Server Broadcast**: Server broadcasts to all connected clients
- **Receiver Display**: Message appears instantly in receiver's chat

## Troubleshooting

### WebSocket Not Connecting

1. Check if server is running:
   ```bash
   # You should see: WebSocket server running on ws://localhost:8080
   ```

2. Check browser console for errors:
   - Open Developer Tools (F12)
   - Go to Console tab
   - Look for WebSocket connection errors

3. Ensure port 8080 is not in use:
   ```bash
   # Windows
   netstat -ano | findstr :8080
   
   # macOS/Linux
   lsof -i :8080
   ```

### Messages Not Appearing

1. Verify both users are connected to the app
2. Check browser console for errors
3. Ensure WebSocket server is running
4. Try refreshing the page to reconnect

### Server Crashes

If the server crashes, restart it:

```bash
node websocket_server.js
```

## Deployment

For production deployment:

1. **Use a cloud WebSocket provider**:
   - AWS API Gateway WebSocket
   - Heroku
   - Socket.io
   - Firebase Realtime Database

2. **Update the connection URL** in `lib/providers/chat_provider.dart`

3. **Enable SSL/TLS**: Use `wss://` instead of `ws://` for secure connections

Example for Heroku:
```dart
const String wsUrl = 'wss://your-app.herokuapp.com';
```

## Performance Optimization

- WebSocket uses persistent connection (better than polling)
- Reduced bandwidth usage
- Lower latency
- Better scalability for multiple users

## Next Steps

- Add user typing indicators
- Add read receipts
- Implement message delivery confirmation
- Add file sharing support
- Implement group notifications
