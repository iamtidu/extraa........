class Group {
  final int? id;
  final String name;
  final String description;
  final String groupPicture; // Path to asset or URL
  final int adminId; // User ID of the group creator/admin
  final DateTime createdAt;

  Group({
    this.id,
    required this.name,
    this.description = '',
    this.groupPicture = '', // Empty string, UI will show initials
    required this.adminId,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'groupPicture': groupPicture,
      'adminId': adminId,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory Group.fromMap(Map<String, dynamic> map) {
    return Group(
      id: map['id'],
      name: map['name'],
      description: map['description'] ?? '',
      groupPicture: map['groupPicture'] ?? '', // Empty string, UI will show initials
      adminId: map['adminId'],
      createdAt: DateTime.parse(map['createdAt']),
    );
  }

  Group copyWith({
    int? id,
    String? name,
    String? description,
    String? groupPicture,
    int? adminId,
    DateTime? createdAt,
  }) {
    return Group(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      groupPicture: groupPicture ?? this.groupPicture,
      adminId: adminId ?? this.adminId,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
