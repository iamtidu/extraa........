import '../utils/app_constants.dart';

class User {
  final int? id;
  final String username;
  final String profilePicture; // Path to asset or URL
  final String status; // e.g., "Available", "Busy"

  User({
    this.id,
    required this.username,
    this.profilePicture = AppConstants.avatarPlaceholder,
    this.status = 'Hey there! I\'m using Chat App.',
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'username': username,
      'profilePicture': profilePicture,
      'status': status,
    };
  }

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['id'],
      username: map['username'],
      profilePicture: map['profilePicture'] ?? AppConstants.avatarPlaceholder,
      status: map['status'] ?? 'Hey there! I\'m using Chat App.',
    );
  }

  User copyWith({
    int? id,
    String? username,
    String? profilePicture,
    String? status,
  }) {
    return User(
      id: id ?? this.id,
      username: username ?? this.username,
      profilePicture: profilePicture ?? this.profilePicture,
      status: status ?? this.status,
    );
  }
}
