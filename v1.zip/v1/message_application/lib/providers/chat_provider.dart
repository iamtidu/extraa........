import 'dart:async';
import 'package:flutter/material.dart';
import '../models/message.dart';
import '../db/message_dao.dart';

class ChatProvider with ChangeNotifier {
  final MessageDao _messageDao = MessageDao();
  final StreamController<Message> _messageStreamController = StreamController<Message>.broadcast();

  // Stream for real-time message updates
  Stream<Message> get messageStream => _messageStreamController.stream;

  List<Message> _messages = [];

  List<Message> get messages => _messages;

  // Load messages for a one-to-one chat
  Future<List<Message>> loadOneToOneMessages(int user1Id, int user2Id) async {
    _messages = await _messageDao.getOneToOneMessages(user1Id, user2Id);
    notifyListeners();
    return _messages;
  }

  // Send a one-to-one message
  Future<void> sendOneToOneMessage(int senderId, int receiverId, String content) async {
    final message = Message(
      senderId: senderId,
      receiverId: receiverId,
      content: content,
      timestamp: DateTime.now(),
    );
    final id = await _messageDao.insertMessage(message);
    if (id > 0) {
      final newMessageWithId = message.copyWith(id: id);
      _messages.add(newMessageWithId);
      _messageStreamController.add(newMessageWithId); // Notify listeners of new message
      notifyListeners();
    }
  }

  // --- Group Chat Specific Methods (handled by GroupProvider for consistency) ---
  // However, messages themselves are still stored and streamed here, linked by groupId.

  Future<List<Message>> loadGroupMessages(int groupId) async {
    _messages = await _messageDao.getGroupMessages(groupId);
    notifyListeners();
    return _messages;
  }

  Future<void> sendGroupMessage(int senderId, int groupId, String content) async {
    final message = Message(
      senderId: senderId,
      groupId: groupId,
      content: content,
      timestamp: DateTime.now(),
    );
    final id = await _messageDao.insertMessage(message);
    if (id > 0) {
      final newMessageWithId = message.copyWith(id: id);
      _messages.add(newMessageWithId);
      _messageStreamController.add(newMessageWithId); // Notify listeners of new message
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _messageStreamController.close();
    super.dispose();
  }
}

// Extend Message model with copyWith for convenience
extension MessageCopyWith on Message {
  Message copyWith({
    int? id,
    int? senderId,
    int? receiverId,
    int? groupId,
    String? content,
    DateTime? timestamp,
  }) {
    return Message(
      id: id ?? this.id,
      senderId: senderId ?? this.senderId,
      receiverId: receiverId ?? this.receiverId,
      groupId: groupId ?? this.groupId,
      content: content ?? this.content,
      timestamp: timestamp ?? this.timestamp,
    );
  }
}
