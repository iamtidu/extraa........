import 'package:flutter/material.dart';
import '../models/group.dart';
import '../models/group_member.dart';
import '../db/group_dao.dart';
import '../db/message_dao.dart'; // For group messages
import '../models/message.dart'; // For group messages

class GroupProvider with ChangeNotifier {
  final GroupDao _groupDao = GroupDao();
  final MessageDao _messageDao = MessageDao(); // To get last message for group list
  List<Group> _allGroups = [];
  List<GroupMember> _groupMembers = []; // Temporary storage for current group's members

  List<Group> get allGroups => _allGroups;
  List<GroupMember> get groupMembers => _groupMembers;

  GroupProvider() {
    _loadAllGroups();
  }

  Future<void> _loadAllGroups() async {
    _allGroups = await _groupDao.getAllGroups();
    notifyListeners();
  }

  Future<void> loadGroupsForUser(int userId) async {
    _allGroups = await _groupDao.getGroupsForUser(userId);
    notifyListeners();
  }

  Future<Group?> getGroupById(int groupId) async {
    return await _groupDao.getGroupById(groupId);
  }

  Future<int> createGroup(String name, String description, int adminId) async {
    final group = Group(
      name: name,
      description: description,
      adminId: adminId,
      createdAt: DateTime.now(),
    );
    final groupId = await _groupDao.insertGroup(group);
    if (groupId > 0) {
      final newGroupWithId = group.copyWith(id: groupId);
      _allGroups.add(newGroupWithId);
      await addMemberToGroup(groupId, adminId); // Admin is automatically a member
      notifyListeners();
      return groupId;
    }
    return -1;
  }

  Future<void> updateGroupDetails(Group group) async {
    await _groupDao.updateGroup(group);
    final index = _allGroups.indexWhere((g) => g.id == group.id);
    if (index != -1) {
      _allGroups[index] = group;
      notifyListeners();
    }
  }

  Future<void> addMemberToGroup(int groupId, int userId) async {
    final member = GroupMember(
      groupId: groupId,
      userId: userId,
      joinedAt: DateTime.now(),
    );
    final id = await _groupDao.addGroupMember(member);
    if (id > 0) {
      _groupMembers.add(member.copyWith(id: id));
      notifyListeners();
    }
  }

  Future<void> removeMemberFromGroup(int groupId, int userId) async {
    await _groupDao.removeGroupMember(groupId, userId);
    _groupMembers.removeWhere((member) => member.groupId == groupId && member.userId == userId);
    notifyListeners();
  }

  Future<void> loadGroupMembers(int groupId) async {
    _groupMembers = await _groupDao.getGroupMembers(groupId);
    notifyListeners();
  }

  Future<List<Group>> getGroupsForUser(int userId) async {
    return await _groupDao.getGroupsForUser(userId);
  }

  bool isUserInGroup(int groupId, int userId) {
    return _groupMembers.any((member) => member.groupId == groupId && member.userId == userId);
  }

  Future<void> deleteGroup(int groupId) async {
    await _groupDao.deleteGroup(groupId);
    _allGroups.removeWhere((group) => group.id == groupId);
    notifyListeners();
  }

  Future<Message?> getLastGroupMessage(int groupId) async {
    final messages = await _messageDao.getGroupMessages(groupId);
    if (messages.isNotEmpty) {
      return messages.last;
    }
    return null;
  }
}

// Extend GroupMember model with copyWith for convenience
extension GroupMemberCopyWith on GroupMember {
  GroupMember copyWith({
    int? id,
    int? groupId,
    int? userId,
    DateTime? joinedAt,
  }) {
    return GroupMember(
      id: id ?? this.id,
      groupId: groupId ?? this.groupId,
      userId: userId ?? this.userId,
      joinedAt: joinedAt ?? this.joinedAt,
    );
  }
}
