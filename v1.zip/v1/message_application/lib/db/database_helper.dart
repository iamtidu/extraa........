import 'package:hive_flutter/hive_flutter.dart';
import '../models/user.dart';
import '../models/message.dart';
import '../models/group.dart';
import '../models/group_member.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static const String usersBoxName = 'users';
  static const String messagesBoxName = 'messages';
  static const String groupsBoxName = 'groups';
  static const String groupMembersBoxName = 'groupMembers';

  late Box<Map> usersBox;
  late Box<Map> messagesBox;
  late Box<Map> groupsBox;
  late Box<Map> groupMembersBox;

  Future<void> initDatabase() async {
    await Hive.initFlutter();
    
    usersBox = await Hive.openBox<Map>(usersBoxName);
    messagesBox = await Hive.openBox<Map>(messagesBoxName);
    groupsBox = await Hive.openBox<Map>(groupsBoxName);
    groupMembersBox = await Hive.openBox<Map>(groupMembersBoxName);
  }

  // User operations
  Future<int> insertUser(User user) async {
    final id = (usersBox.keys.cast<int>().fold<int>(0, (max, id) => id > max ? id : max)) + 1;
    final userMap = {...user.toMap(), 'id': id};
    await usersBox.put(id, userMap);
    return id;
  }

  Future<User?> getUserById(int id) async {
    final userMap = usersBox.get(id);
    if (userMap != null) {
      return User.fromMap(userMap.cast<String, dynamic>());
    }
    return null;
  }

  Future<List<User>> getAllUsers() async {
    return usersBox.values
        .map((userMap) => User.fromMap(userMap.cast<String, dynamic>()))
        .toList();
  }

  Future<void> updateUser(User user) async {
    final userMap = {...user.toMap(), 'id': user.id};
    await usersBox.put(user.id, userMap);
  }

  Future<void> deleteUser(int id) async {
    await usersBox.delete(id);
  }

  // Message operations
  Future<int> insertMessage(Message message) async {
    final id = (messagesBox.keys.cast<int>().fold<int>(0, (max, id) => id > max ? id : max)) + 1;
    final messageMap = {...message.toMap(), 'id': id};
    await messagesBox.put(id, messageMap);
    return id;
  }

  Future<List<Message>> getOneToOneMessages(int user1Id, int user2Id) async {
    return messagesBox.values
        .map((msg) => Message.fromMap(msg.cast<String, dynamic>()))
        .where((msg) => 
          ((msg.senderId == user1Id && msg.receiverId == user2Id) ||
           (msg.senderId == user2Id && msg.receiverId == user1Id)) &&
          msg.groupId == null)
        .toList();
  }

  Future<List<Message>> getGroupMessages(int groupId) async {
    return messagesBox.values
        .map((msg) => Message.fromMap(msg.cast<String, dynamic>()))
        .where((msg) => msg.groupId == groupId)
        .toList();
  }

  Future<void> deleteMessage(int id) async {
    await messagesBox.delete(id);
  }

  // Group operations
  Future<int> insertGroup(Group group) async {
    final id = (groupsBox.keys.cast<int>().fold<int>(0, (max, id) => id > max ? id : max)) + 1;
    final groupMap = {...group.toMap(), 'id': id};
    await groupsBox.put(id, groupMap);
    return id;
  }

  Future<Group?> getGroupById(int id) async {
    final groupMap = groupsBox.get(id);
    if (groupMap != null) {
      return Group.fromMap(groupMap.cast<String, dynamic>());
    }
    return null;
  }

  Future<List<Group>> getAllGroups() async {
    return groupsBox.values
        .map((groupMap) => Group.fromMap(groupMap.cast<String, dynamic>()))
        .toList();
  }

  Future<List<Group>> getGroupsForUser(int userId) async {
    final userGroups = groupMembersBox.values
        .map((gm) => GroupMember.fromMap(gm.cast<String, dynamic>()))
        .where((gm) => gm.userId == userId)
        .map((gm) => gm.groupId)
        .toSet();

    final groups = <Group>[];
    for (var groupId in userGroups) {
      final group = await getGroupById(groupId);
      if (group != null) {
        groups.add(group);
      }
    }
    return groups;
  }

  Future<void> updateGroup(Group group) async {
    final groupMap = {...group.toMap(), 'id': group.id};
    await groupsBox.put(group.id, groupMap);
  }

  Future<void> deleteGroup(int id) async {
    await groupsBox.delete(id);
    // Also delete all group members
    final valuesList = groupMembersBox.values.toList();
    final keysToDelete = <dynamic>[];
    for (int i = 0; i < valuesList.length; i++) {
      final gm = GroupMember.fromMap(valuesList[i].cast<String, dynamic>());
      if (gm.groupId == id) {
        keysToDelete.add(groupMembersBox.keyAt(i));
      }
    }
    for (var key in keysToDelete) {
      await groupMembersBox.delete(key);
    }
  }

  // Group member operations
  Future<int> addGroupMember(GroupMember member) async {
    final id = (groupMembersBox.keys.cast<int>().fold<int>(0, (max, id) => id > max ? id : max)) + 1;
    final memberMap = {...member.toMap(), 'id': id};
    await groupMembersBox.put(id, memberMap);
    return id;
  }

  Future<List<GroupMember>> getGroupMembers(int groupId) async {
    return groupMembersBox.values
        .map((gmMap) => GroupMember.fromMap(gmMap.cast<String, dynamic>()))
        .where((gm) => gm.groupId == groupId)
        .toList();
  }

  Future<void> removeGroupMember(int groupId, int userId) async {
    final valuesList = groupMembersBox.values.toList();
    final keysToDelete = <dynamic>[];
    for (int i = 0; i < valuesList.length; i++) {
      final gm = GroupMember.fromMap(valuesList[i].cast<String, dynamic>());
      if (gm.groupId == groupId && gm.userId == userId) {
        keysToDelete.add(groupMembersBox.keyAt(i));
      }
    }
    
    for (var key in keysToDelete) {
      await groupMembersBox.delete(key);
    }
  }
}
