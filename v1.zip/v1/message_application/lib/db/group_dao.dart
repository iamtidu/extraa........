import '../models/group.dart';
import '../models/group_member.dart';
import 'database_helper.dart';

class GroupDao {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<int> insertGroup(Group group) async {
    return await _dbHelper.insertGroup(group);
  }

  Future<Group?> getGroupById(int id) async {
    return await _dbHelper.getGroupById(id);
  }

  Future<List<Group>> getAllGroups() async {
    return await _dbHelper.getAllGroups();
  }

  Future<List<Group>> getGroupsForUser(int userId) async {
    return await _dbHelper.getGroupsForUser(userId);
  }

  Future<int> updateGroup(Group group) async {
    await _dbHelper.updateGroup(group);
    return 1; // Return 1 for success
  }

  Future<int> deleteGroup(int id) async {
    await _dbHelper.deleteGroup(id);
    return 1; // Return 1 for success
  }

  // Group member operations
  Future<int> addGroupMember(GroupMember member) async {
    return await _dbHelper.addGroupMember(member);
  }

  Future<List<GroupMember>> getGroupMembers(int groupId) async {
    return await _dbHelper.getGroupMembers(groupId);
  }

  Future<int> removeGroupMember(int groupId, int userId) async {
    await _dbHelper.removeGroupMember(groupId, userId);
    return 1; // Return 1 for success
  }
}
