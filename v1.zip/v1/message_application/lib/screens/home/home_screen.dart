import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import '../../providers/group_provider.dart';
import '../../providers/user_provider.dart';
import '../../models/user.dart';
import '../../models/group.dart';
import '../../models/message.dart';
import '../../widgets/chat_list_tile.dart';
import '../auth/login_screen.dart';
import '../chat/chat_screen.dart';
import '../profile/edit_profile_screen.dart';
import '../group/create_group_screen.dart';
import '../group/group_details_screen.dart';
import '../../utils/app_constants.dart';

class HomeScreen extends StatefulWidget {
  static const routeName = '/home';

  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0; // 0 for chats, 1 for users, 2 for groups

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);

    if (authProvider.currentUser != null) {
      // Force reload of users from database
      await userProvider.reloadUsers();
      await groupProvider.loadGroupsForUser(authProvider.currentUser!.id!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final currentUser = authProvider.currentUser;

    if (!authProvider.isAuthenticated || currentUser == null) {
      // If not authenticated, redirect to login
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).pushReplacementNamed(LoginScreen.routeName);
      });
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName),
        actions: [
          IconButton(
            icon: const Icon(Icons.person),
            onPressed: () {
              Navigator.of(context).pushNamed(EditProfileScreen.routeName);
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              authProvider.logout();
              Navigator.of(context).pushReplacementNamed(LoginScreen.routeName);
            },
          ),
        ],
      ),
      body: Column(
        children: [
          _buildSegmentedControl(),
          Expanded(
            child: Consumer<ChatProvider>(
              builder: (context, chatProvider, child) {
                // Listen to message stream to update UI in real-time
                chatProvider.messageStream.listen((message) {
                  // Only notify if message is relevant to visible list
                  // For simplicity, we just rebuild the whole list for now.
                  // A more optimized approach would be to update specific list items.
                  if (mounted) {
                    setState(() {});
                  }
                });

                return _buildCurrentView(currentUser.id!);
              },
            ),
          ),
        ],
      ),
      floatingActionButton: _selectedIndex == 2 // Only show FAB for groups to create new group
          ? FloatingActionButton(
              onPressed: () {
                Navigator.of(context).pushNamed(CreateGroupScreen.routeName);
              },
              child: const Icon(Icons.group_add),
            )
          : null,
    );
  }

  Widget _buildSegmentedControl() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: SegmentedButton<int>(
        segments: const [
          ButtonSegment<int>(value: 0, label: Text('Chats'), icon: Icon(Icons.chat)),
          ButtonSegment<int>(value: 1, label: Text('Users'), icon: Icon(Icons.people)),
          ButtonSegment<int>(value: 2, label: Text('Groups'), icon: Icon(Icons.groups)),
        ],
        selected: <int>{_selectedIndex},
        onSelectionChanged: (Set<int> newSelection) {
          setState(() {
            _selectedIndex = newSelection.first;
          });
        },
      ),
    );
  }

  Widget _buildCurrentView(int currentUserId) {
    switch (_selectedIndex) {
      case 0:
        return _buildChatsView(currentUserId);
      case 1:
        return _buildUsersView(currentUserId);
      case 2:
        return _buildGroupsView(currentUserId);
      default:
        return const Center(child: Text('Select an option'));
    }
  }

  Widget _buildChatsView(int currentUserId) {
    return FutureBuilder<Map<String, List>>(
      future: _getRecentChatsAndGroups(currentUserId),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        if (!snapshot.hasData || (snapshot.data!['chats']!.isEmpty && snapshot.data!['groups']!.isEmpty)) {
          return const Center(child: Text('Start a chat or create a group!'));
        }

        final List<dynamic> combinedChats = [];
        // Add one-to-one chats
        for (var entry in snapshot.data!['chats']!) {
          combinedChats.add(entry); // entry is { 'user': User, 'lastMessage': Message }
        }
        // Add group chats
        for (var entry in snapshot.data!['groups']!) {
          combinedChats.add(entry); // entry is { 'group': Group, 'lastMessage': Message }
        }

        // Sort by last message timestamp (most recent first)
        combinedChats.sort((a, b) {
          final DateTime? timeA = a['lastMessage']?.timestamp;
          final DateTime? timeB = b['lastMessage']?.timestamp;

          if (timeA == null && timeB == null) return 0;
          if (timeA == null) return 1; // Put chats without messages at the end
          if (timeB == null) return -1;
          return timeB.compareTo(timeA);
        });

        return ListView.builder(
          itemCount: combinedChats.length,
          itemBuilder: (context, index) {
            final chatItem = combinedChats[index];
            final dynamic entity = chatItem.keys.contains('user') ? chatItem['user'] : chatItem['group'];
            final String avatar = entity is User ? entity.profilePicture : entity.groupPicture;
            final String title = entity is User ? entity.username : entity.name;
            final Message? lastMessage = chatItem['lastMessage'];

            return ChatListTile(
              avatarUrl: avatar,
              title: title,
              lastMessage: lastMessage,
              onTap: () {
                if (entity is User) {
                  Navigator.of(context).pushNamed(
                    ChatScreen.routeName,
                    arguments: {
                      'receiverUser': entity,
                    },
                  );
                } else if (entity is Group) {
                  Navigator.of(context).pushNamed(
                    ChatScreen.routeName,
                    arguments: {
                      'chatGroup': entity,
                    },
                  );
                }
              },
            );
          },
        );
      },
    );
  }

  Future<Map<String, List>> _getRecentChatsAndGroups(int currentUserId) async {
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    final messageDao = Provider.of<ChatProvider>(context, listen: false); // Using ChatProvider for message DAO

    final List<User> allUsers = userProvider.allUsers.where((user) => user.id != currentUserId).toList();
    final List<Group> userGroups = await groupProvider.getGroupsForUser(currentUserId);

    List<Map<String, dynamic>> oneToOneChats = [];
    List<Map<String, dynamic>> groupChats = [];

    // Get last message for each one-to-one chat
    for (User user in allUsers) {
      final messages = await messageDao.loadOneToOneMessages(currentUserId, user.id!);
      final lastMessage = messages.isNotEmpty ? messages.last : null;
      oneToOneChats.add({'user': user, 'lastMessage': lastMessage});
    }

    // Get last message for each group chat
    for (Group group in userGroups) {
      final messages = await messageDao.loadGroupMessages(group.id!);
      final lastMessage = messages.isNotEmpty ? messages.last : null;
      groupChats.add({'group': group, 'lastMessage': lastMessage});
    }

    return {'chats': oneToOneChats, 'groups': groupChats};
  }

  Widget _buildUsersView(int currentUserId) {
    return Consumer<UserProvider>(
      builder: (context, userProvider, child) {
        final otherUsers = userProvider.allUsers.where((user) => user.id != currentUserId).toList();
        if (otherUsers.isEmpty) {
          return const Center(child: Text('No other users registered yet.'));
        }
        return ListView.builder(
          itemCount: otherUsers.length,
          itemBuilder: (context, index) {
            final user = otherUsers[index];
            return ListTile(
              leading: CircleAvatar(
                backgroundImage: user.profilePicture.isNotEmpty ? AssetImage(user.profilePicture) : null,
                backgroundColor: Theme.of(context).primaryColor.withOpacity(0.2),
                child: user.profilePicture.isEmpty
                    ? Text(
                        user.username.isNotEmpty ? user.username[0].toUpperCase() : '?',
                        style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                      )
                    : null,
              ),
              title: Text(user.username),
              subtitle: Text(user.status),
              onTap: () {
                Navigator.of(context).pushNamed(
                  ChatScreen.routeName,
                  arguments: {
                    'receiverUser': user,
                  },
                );
              },
            );
          },
        );
      },
    );
  }

  Widget _buildGroupsView(int currentUserId) {
    return Consumer<GroupProvider>(
      builder: (context, groupProvider, child) {
        final groups = groupProvider.allGroups; // These are groups the current user is a member of

        if (groups.isEmpty) {
          return const Center(child: Text('No groups yet. Create one!'));
        }
        return ListView.builder(
          itemCount: groups.length,
          itemBuilder: (context, index) {
            final group = groups[index];
            return ListTile(
              leading: CircleAvatar(
                backgroundImage: AssetImage(group.groupPicture),
              ),
              title: Text(group.name),
              subtitle: Text(group.description.isNotEmpty ? group.description : 'Tap to view group'),
              onTap: () {
                Navigator.of(context).pushNamed(
                  GroupDetailsScreen.routeName,
                  arguments: group,
                );
              },
            );
          },
        );
      },
    );
  }
}
