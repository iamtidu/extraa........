import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/group.dart';
import '../../models/user.dart';
import '../../providers/auth_provider.dart';
import '../../providers/group_provider.dart';
import '../../providers/user_provider.dart';
import '../../utils/app_constants.dart';
import 'add_members_to_group_screen.dart'; // To add new members

/// GroupDetailsScreen - A stateful widget that displays detailed information about a group
/// 
/// This screen allows:
/// - Viewing group name, description, and picture
/// - Editing group details (if user is admin)
/// - Viewing all group members
/// - Adding new members (if user is admin)
/// - Removing members from the group (if user is admin)
/// - Leaving the group (any member)
///
/// Uses Provider package for state management with three providers:
/// - AuthProvider: To get current authenticated user
/// - GroupProvider: To manage group data and members
/// - UserProvider: To fetch user details by ID
class GroupDetailsScreen extends StatefulWidget {
  /// Named route constant for navigation
  static const routeName = '/group-details';

  /// Constructor with optional key parameter
  const GroupDetailsScreen({super.key});

  @override
  State<GroupDetailsScreen> createState() => _GroupDetailsScreenState();
}

/// _GroupDetailsScreenState - The mutable state class for GroupDetailsScreen
/// 
/// Manages:
/// - Form validation using GlobalKey<FormState>
/// - Text controllers for group name and description
/// - Local group data and picture URL
/// - Lifecycle events through initState and dispose
class _GroupDetailsScreenState extends State<GroupDetailsScreen> {
  /// GlobalKey to manage form validation state
  final _formKey = GlobalKey<FormState>();
  
  /// Holds the current group object being displayed
  late Group _currentGroup;
  
  /// TextEditingController for group name input field
  late TextEditingController _nameController;
  
  /// TextEditingController for group description input field
  late TextEditingController _descriptionController;
  
  /// Stores the group picture/avatar image path (empty string shows initials instead)
  String _groupPicture = '';

  @override
  void initState() {
    super.initState();
    // WidgetsBinding.instance.addPostFrameCallback is used to execute code after the first frame
    // This ensures the context is fully available when accessing ModalRoute
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Extract the Group object passed as arguments during navigation
      _currentGroup = ModalRoute.of(context)!.settings.arguments as Group;
      
      // Initialize text controllers with current group data
      _nameController = TextEditingController(text: _currentGroup.name);
      _descriptionController = TextEditingController(text: _currentGroup.description);
      
      // Set the group picture from the group object
      _groupPicture = _currentGroup.groupPicture;
      
      // Load all members of the group asynchronously
      _loadMembers();
    });
  }

  /// _loadMembers() - Loads all members of the current group from the provider
  ///
  /// This function:
  /// - Gets the GroupProvider instance without listening to changes
  /// - Calls loadGroupMembers() with the current group ID
  /// - Used during initialization and after member operations
  /// - Returns a Future that completes when members are loaded
  Future<void> _loadMembers() async {
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    await groupProvider.loadGroupMembers(_currentGroup.id!);
  }

  /// _saveGroupDetails() - Saves the updated group details to the database
  ///
  /// Functionality:
  /// 1. Validates the form using the global form key
  /// 2. Creates a new Group object with updated values:
  ///    - Group name from the text controller
  ///    - Group description from the text controller
  ///    - Group picture (if changed)
  /// 3. Calls the GroupProvider to update the group in the database
  /// 4. Updates the local _currentGroup variable
  /// 5. Shows a success SnackBar confirmation message
  ///
  /// Only called when form validation passes
  void _saveGroupDetails() async {
    if (_formKey.currentState!.validate()) {
      final groupProvider = Provider.of<GroupProvider>(context, listen: false);
      
      // Create a new Group instance with updated values using copyWith pattern
      final updatedGroup = _currentGroup.copyWith(
        name: _nameController.text,
        description: _descriptionController.text,
        groupPicture: _groupPicture,
      );

      // Update the group in the database through the provider
      await groupProvider.updateGroupDetails(updatedGroup);
      
      // Update the local state variable
      setState(() {
        _currentGroup = updatedGroup;
      });
      
      // Show success notification
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Group details updated!')),
      );
    }
  }

  /// _removeMember(int userId) - Removes a specific member from the group
  ///
  /// Parameters:
  /// - userId: The ID of the user to be removed from the group
  ///
  /// Business Logic:
  /// 1. Gets the current user ID from AuthProvider
  /// 2. Verifies that only the group admin can remove members
  /// 3. Prevents admin from removing themselves if other members exist
  /// 4. Shows a confirmation dialog before removal
  /// 5. Removes the member via GroupProvider
  /// 6. Shows success notification
  ///
  /// Permissions:
  /// - Only group admin can call this function
  /// - Admin cannot remove themselves if they're not the only member
  void _removeMember(int userId) async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    
    // Get the ID of the currently logged-in user
    final currentUserId = authProvider.currentUser!.id!;

    // Check if the current user is the group admin
    if (_currentGroup.adminId != currentUserId) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Only group admin can remove members.')),
      );
      return;
    }

    // Prevent admin from removing themselves unless they are the only member
    if (userId == currentUserId && groupProvider.groupMembers.length > 1) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Admin cannot remove themselves if other members exist.')),
      );
      return;
    }

    // Show confirmation dialog
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove Member'),
        content: const Text('Are you sure you want to remove this member?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              // Remove the member from the group via provider
              await groupProvider.removeMemberFromGroup(_currentGroup.id!, userId);
              
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Member removed.')),
              );
              
              // Close the dialog
              Navigator.of(ctx).pop();
            },
            child: const Text('Remove'),
          ),
        ],
      ),
    );
  }

  /// _leaveGroup() - Allows the current user to leave the group
  ///
  /// Behavior:
  /// 1. If the user is the admin and the only member:
  ///    - Deletes the entire group
  /// 2. If the user is the admin but not the only member:
  ///    - Removes them from the group (admin role remains with other member)
  /// 3. If the user is a regular member:
  ///    - Removes them from the group
  /// 4. Shows confirmation dialog before proceeding
  /// 5. Navigates back to home screen after leaving
  ///
  /// Note: Admin promotion to another member could be implemented here
  void _leaveGroup() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    
    // Get the ID of the currently logged-in user
    final currentUserId = authProvider.currentUser!.id!;

    // Show confirmation dialog
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Leave Group'),
        content: const Text('Are you sure you want to leave this group?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              // Check if current user is admin and the only member
              if (_currentGroup.adminId == currentUserId && groupProvider.groupMembers.length == 1) {
                // Delete the entire group if admin is the only member
                await groupProvider.deleteGroup(_currentGroup.id!);
              } else {
                // Remove the user from the group
                await groupProvider.removeMemberFromGroup(_currentGroup.id!, currentUserId);
                // TODO: Implement admin promotion logic if needed
              }
              
              // Show confirmation message
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('You have left the group.')),
              );
              
              // Close the confirmation dialog
              Navigator.of(ctx).pop();
              
              // Navigate back to the home screen
              Navigator.of(context).pop();
            },
            child: const Text('Leave'),
          ),
        ],
      ),
    );
  }

  /// build() - Constructs the main UI for the GroupDetailsScreen
  ///
  /// UI Components:
  /// 1. AppBar: Contains edit and leave buttons
  ///    - Edit button: Only visible to admin
  ///    - Leave button: Visible to all members
  /// 2. Group Picture: Circular avatar with optional edit icon (admin only)
  /// 3. Form Fields:
  ///    - Group Name: Editable only by admin
  ///    - Description: Editable only by admin
  /// 4. Members Section:
  ///    - Member count and Add Members button (admin only)
  ///    - ListView of all members with their avatars and roles
  ///    - Remove button for each member (admin can remove non-admin members)
  ///
  /// Uses Provider to listen to real-time data changes from:
  /// - AuthProvider: Current user information
  /// - GroupProvider: Group and members data
  /// - UserProvider: Individual user details
  @override
  Widget build(BuildContext context) {
    // Get provider instances
    final authProvider = Provider.of<AuthProvider>(context);
    final groupProvider = Provider.of<GroupProvider>(context);
    final userProvider = Provider.of<UserProvider>(context);
    
    // Get current user ID
    final currentUserId = authProvider.currentUser!.id!;
    
    // Check if current user is the group admin
    final isAdmin = _currentGroup.adminId == currentUserId;

    // Refresh members on UI updates for dynamic changes
    groupProvider.loadGroupMembers(_currentGroup.id!);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Group Details'),
        actions: [
          // Edit button only visible to admin
          if (isAdmin)
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: _saveGroupDetails,
            ),
          // Leave group button visible to all
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: _leaveGroup,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Group Picture Section
              Center(
                child: GestureDetector(
                  // Allow admin to tap to change group picture
                  onTap: () {
                    if (isAdmin) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Image picker not implemented in this demo.')),
                      );
                    }
                  },
                  child: CircleAvatar(
                    radius: 70,
                    backgroundImage: AssetImage(_groupPicture),
                    // Show camera icon overlay for admin users
                    child: isAdmin
                        ? const Align(
                            alignment: Alignment.bottomRight,
                            child: CircleAvatar(
                              radius: 20,
                              backgroundColor: Colors.blue,
                              child: Icon(Icons.camera_alt, color: Colors.white, size: 20),
                            ),
                          )
                        : null,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              
              // Group Name Text Field
              TextFormField(
                controller: _nameController,
                // Only admin can edit the name
                readOnly: !isAdmin,
                decoration: InputDecoration(
                  labelText: 'Group Name',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.group),
                  // Gray background for non-editable fields
                  fillColor: isAdmin ? Colors.white : Colors.grey[200],
                  filled: true,
                ),
                // Validate that group name is not empty
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a group name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              
              // Group Description Text Field
              TextFormField(
                controller: _descriptionController,
                // Only admin can edit the description
                readOnly: !isAdmin,
                decoration: InputDecoration(
                  labelText: 'Description',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.description),
                  // Gray background for non-editable fields
                  fillColor: isAdmin ? Colors.white : Colors.grey[200],
                  filled: true,
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 30),
              
              // Members Header with Add Button
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Display member count
                  Text(
                    'Members (${groupProvider.groupMembers.length})',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  // Add Members button only visible to admin
                  if (isAdmin)
                    TextButton.icon(
                      icon: const Icon(Icons.person_add),
                      label: const Text('Add'),
                      onPressed: () async {
                        // Navigate to AddMembersToGroupScreen with current group as argument
                        await Navigator.of(context).pushNamed(
                          AddMembersToGroupScreen.routeName,
                          arguments: _currentGroup,
                        );
                        // Refresh members list after adding new members
                        await _loadMembers();
                      },
                    ),
                ],
              ),
              const Divider(),
              
              // Members List
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: groupProvider.groupMembers.length,
                itemBuilder: (context, index) {
                  // Get the group member object
                  final member = groupProvider.groupMembers[index];
                  
                  // Fetch the user details using the member's user ID
                  final user = userProvider.getUserById(member.userId);
                  
                  // Return empty widget if user not found
                  if (user == null) return const SizedBox.shrink();

                  return ListTile(
                    // Display user's profile picture
                    leading: CircleAvatar(
                      backgroundImage: AssetImage(user.profilePicture),
                    ),
                    // Display username
                    title: Text(user.username),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Show "Admin" badge if user is group admin
                        if (_currentGroup.adminId == user.id)
                          const Chip(
                            label: Text('Admin'),
                            backgroundColor: Colors.blueAccent,
                            labelStyle: TextStyle(color: Colors.white),
                          ),
                        // Show remove button for admin users (but not for themselves or the group admin)
                        if (isAdmin && user.id != currentUserId && _currentGroup.adminId != user.id)
                          IconButton(
                            icon: const Icon(Icons.remove_circle_outline, color: Colors.red),
                            onPressed: () => _removeMember(user.id!),
                          ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// dispose() - Cleans up resources when the widget is disposed
  ///
  /// This method:
  /// 1. Disposes the name text controller to free memory
  /// 2. Disposes the description text controller to free memory
  /// 3. Calls super.dispose() to complete the disposal process
  ///
  /// Important: Always dispose of TextEditingController instances to prevent memory leaks
  @override
  void dispose() {
    // Clean up the group name text controller
    _nameController.dispose();
    
    // Clean up the description text controller
    _descriptionController.dispose();
    
    // Call parent class dispose method
    super.dispose();
  }
}
