import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/user.dart';
import '../../providers/auth_provider.dart';
import '../../providers/group_provider.dart';
import '../../providers/user_provider.dart';
import '../chat/chat_screen.dart'; // To navigate to group chat after creation

class CreateGroupScreen extends StatefulWidget {
  static const routeName = '/create-group';

  const CreateGroupScreen({super.key});

  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final List<User> _selectedMembers = [];

  void _createGroup() async {
    if (_formKey.currentState!.validate()) {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final groupProvider = Provider.of<GroupProvider>(context, listen: false);
      final currentUserId = authProvider.currentUser!.id!;

      final groupId = await groupProvider.createGroup(
        _nameController.text,
        _descriptionController.text,
        currentUserId,
      );

      if (groupId > 0) {
        // Add selected members to the group
        for (var member in _selectedMembers) {
          await groupProvider.addMemberToGroup(groupId, member.id!);
        }
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Group created successfully!')),
        );
        // Find the newly created group to navigate to its chat screen
        final newGroup = await groupProvider.getGroupById(groupId);
        if (newGroup != null) {
          Navigator.of(context).pushReplacementNamed(
            ChatScreen.routeName,
            arguments: {'chatGroup': newGroup},
          );
        } else {
          Navigator.of(context).pop();
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to create group.')),
        );
      }
    }
  }

  void _showAddMembersDialog() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        final userProvider = Provider.of<UserProvider>(context, listen: false);
        final authProvider = Provider.of<AuthProvider>(context, listen: false);
        final currentUserId = authProvider.currentUser!.id!;
        final availableUsers = userProvider.allUsers
            .where((user) => user.id != currentUserId && !_selectedMembers.contains(user))
            .toList();

        return StatefulBuilder(
          builder: (BuildContext context, StateSetter modalSetState) {
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text('Add Members', style: Theme.of(context).textTheme.headlineSmall),
                ),
                Expanded(
                  child: availableUsers.isEmpty
                      ? const Center(child: Text('No other users available to add.'))
                      : ListView.builder(
                          itemCount: availableUsers.length,
                          itemBuilder: (context, index) {
                            final user = availableUsers[index];
                            return CheckboxListTile(
                              title: Text(user.username),
                              value: _selectedMembers.contains(user),
                              onChanged: (bool? checked) {
                                modalSetState(() {
                                  if (checked == true) {
                                    _selectedMembers.add(user);
                                  } else {
                                    _selectedMembers.remove(user);
                                  }
                                });
                              },
                            );
                          },
                        ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {}); // Update parent widget to show selected members
                      Navigator.of(context).pop();
                    },
                    child: const Text('Done'),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Create New Group'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Group Name',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a group name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Group Description (Optional)',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _showAddMembersDialog,
                icon: const Icon(Icons.person_add),
                label: const Text('Add Members'),
              ),
              if (_selectedMembers.isNotEmpty) ...[
                const SizedBox(height: 10),
                const Text('Selected Members:', style: TextStyle(fontWeight: FontWeight.bold)),
                Wrap(
                  spacing: 8.0,
                  children: _selectedMembers.map((user) {
                    return Chip(
                      label: Text(user.username),
                      onDeleted: () {
                        setState(() {
                          _selectedMembers.remove(user);
                        });
                      },
                    );
                  }).toList(),
                ),
              ],
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: _createGroup,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  textStyle: const TextStyle(fontSize: 18),
                ),
                child: const Text('Create Group'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }
}
