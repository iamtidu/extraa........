import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/group.dart';
import '../../models/message.dart';
import '../../models/user.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import '../../providers/user_provider.dart';
import '../../widgets/message_bubble.dart';

class ChatScreen extends StatefulWidget {
  static const routeName = '/chat';

  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  User? _receiverUser;
  Group? _chatGroup;
  late StreamSubscription<Message> _messageSubscription;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadChatData();
      _scrollToBottom();
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Subscribe to message stream only once
    final chatProvider = Provider.of<ChatProvider>(context, listen: false);
    _messageSubscription = chatProvider.messageStream.listen((_) {
      _scrollToBottom();
    });
  }

  Future<void> _loadChatData() async {
    final args = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    _receiverUser = args['receiverUser'] as User?;
    _chatGroup = args['chatGroup'] as Group?;

    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final chatProvider = Provider.of<ChatProvider>(context, listen: false);
    final currentUserId = authProvider.currentUser!.id!;

    if (_receiverUser != null) {
      await chatProvider.loadOneToOneMessages(currentUserId, _receiverUser!.id!);
    } else if (_chatGroup != null) {
      await chatProvider.loadGroupMessages(_chatGroup!.id!);
    }
  }

  void _sendMessage() async {
    if (_messageController.text.trim().isEmpty) return;

    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final chatProvider = Provider.of<ChatProvider>(context, listen: false);
    final currentUserId = authProvider.currentUser!.id!;
    final messageContent = _messageController.text.trim();

    if (_receiverUser != null) {
      await chatProvider.sendOneToOneMessage(currentUserId, _receiverUser!.id!, messageContent);
    } else if (_chatGroup != null) {
      await chatProvider.sendGroupMessage(currentUserId, _chatGroup!.id!, messageContent);
    }

    _messageController.clear();
    _scrollToBottom();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final chatProvider = Provider.of<ChatProvider>(context);
    final userProvider = Provider.of<UserProvider>(context);
    final currentUserId = authProvider.currentUser!.id!;

    return Scaffold(
      appBar: AppBar(
        title: Text(_receiverUser?.username ?? _chatGroup?.name ?? 'Chat'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(8.0),
              itemCount: chatProvider.messages.length,
              itemBuilder: (context, index) {
                final message = chatProvider.messages[index];
                final isMe = message.senderId == currentUserId;
                final senderUser = userProvider.getUserById(message.senderId);
                final senderUsername = senderUser?.username ?? 'Unknown';

                return MessageBubble(
                  message: message,
                  isMe: isMe,
                  senderUsername: senderUsername,
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(
                      hintText: 'Type your message...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    ),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                const SizedBox(width: 8),
                FloatingActionButton(
                  onPressed: _sendMessage,
                  child: const Icon(Icons.send),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _messageSubscription.cancel(); // Cancel the subscription
    super.dispose();
  }
}
