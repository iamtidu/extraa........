const WebSocket = require("ws");

const wss = new WebSocket.Server({ port: 8080 });

let users = {}; // username -> ws

wss.on("connection", (ws) => {
  ws.on("message", (data) => {
    const msg = JSON.parse(data);

    // LOGIN
    if (msg.type === "login") {
      ws.username = msg.username;
      users[msg.username] = ws;

      broadcastUsers();
    }

    // FRIEND REQUEST
    if (msg.type === "friend_request") {
      const target = users[msg.to];
      if (target) {
        target.send(JSON.stringify({
          type: "friend_request",
          from: msg.from
        }));
      }
    }

    // ACCEPT REQUEST
    if (msg.type === "accept_request") {
      const target = users[msg.to];
      if (target) {
        target.send(JSON.stringify({
          type: "request_accepted",
          from: msg.from
        }));
      }
    }
  });

  ws.on("close", () => {
    if (ws.username) {
      delete users[ws.username];
      broadcastUsers();
    }
  });
});

function broadcastUsers() {
  const list = Object.keys(users);
  Object.values(users).forEach(ws => {
    ws.send(JSON.stringify({
      type: "users",
      users: list
    }));
  });
}

console.log("WebSocket running on ws://localhost:8080");
