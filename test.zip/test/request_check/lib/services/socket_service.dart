import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';

class WSService {
  static final WSService _instance = WSService._internal();
  factory WSService() => _instance;
  WSService._internal();

  late WebSocketChannel channel;

  void connect(String username, Function(dynamic) onMessage) {
    channel = WebSocketChannel.connect(
      Uri.parse("ws://localhost:8080"),
    );

    channel.stream.listen(onMessage);

    channel.sink.add(jsonEncode({
      "type": "login",
      "username": username
    }));
  }

  void send(Map data) {
    channel.sink.add(jsonEncode(data));
  }
}
