import 'package:hive/hive.dart';

class HiveBoxes {
  static Box usersBox() => Hive.box('users');
  static Box requestsBox() => Hive.box('requests');
}
