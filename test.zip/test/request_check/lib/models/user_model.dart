class UserModel {
  final String name;

  UserModel(this.name);
}
