import 'package:flutter/material.dart';
import '../utils/storage.dart';

class FriendProvider extends ChangeNotifier {
  String? loggedUser;
  String requestStatus = "none"; // none | sent | received | accepted

  Future<void> login(String name) async {
    loggedUser = name;
    await Storage.save("user", name);
    notifyListeners();
  }

  Future<void> sendRequest() async {
    requestStatus = "sent";
    await Storage.save("request", "received");
    notifyListeners();
  }

  Future<void> loadRequest() async {
    requestStatus = await Storage.read("request") ?? "none";
    notifyListeners();
  }

  Future<void> acceptRequest() async {
    requestStatus = "accepted";
    await Storage.save("request", "accepted");
    notifyListeners();
  }
}
