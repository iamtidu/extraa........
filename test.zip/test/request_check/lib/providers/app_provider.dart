import 'package:flutter/material.dart';
import '../utils/storage.dart';

class AppProvider extends ChangeNotifier {
  String? currentUser;
  List<String> allUsers = [];
  Map<String, String> requests = {}; // fromUser -> status

  Future<void> login(String name) async {
    currentUser = name;

    allUsers = await Storage.getUsers();
    if (!allUsers.contains(name)) {
      allUsers.add(name);
      await Storage.saveUsers(allUsers);
    }

    await refresh();
  }

  Future<void> refresh() async {
    requests.clear();
    for (var user in allUsers) {
      if (user != currentUser) {
        final status =
            await Storage.getRequest("${user}_to_$currentUser");
        if (status != null) {
          requests[user] = status;
        }
      }
    }
    notifyListeners();
  }

  Future<void> sendRequest(String toUser) async {
    await Storage.saveRequest(
        "${currentUser}_to_$toUser", "pending");
    notifyListeners();
  }

  Future<void> acceptRequest(String fromUser) async {
    await Storage.saveRequest(
        "${fromUser}_to_$currentUser", "accepted");
    notifyListeners();
  }

  Future<void> rejectRequest(String fromUser) async {
    await Storage.removeRequest("${fromUser}_to_$currentUser");
    notifyListeners();
  }
}
