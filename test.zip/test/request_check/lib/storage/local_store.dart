import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class LocalStore {
  static Future<void> saveUsers(List<String> users) async {
    final p = await SharedPreferences.getInstance();
    p.setString("users", jsonEncode(users));
  }

  static Future<List<String>> loadUsers() async {
    final p = await SharedPreferences.getInstance();
    final data = p.getString("users");
    return data == null ? [] : List<String>.from(jsonDecode(data));
  }

  static Future<void> saveRequests(List<String> req) async {
    final p = await SharedPreferences.getInstance();
    p.setString("requests", jsonEncode(req));
  }

  static Future<List<String>> loadRequests() async {
    final p = await SharedPreferences.getInstance();
    final data = p.getString("requests");
    return data == null ? [] : List<String>.from(jsonDecode(data));
  }
}
