import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/socket_service.dart';

class HomeScreen extends StatefulWidget {
  final String user;
  HomeScreen(this.user);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<String> users = [];
  List<String> friends = [];
  List<String> requests = [];

  @override
  void initState() {
    super.initState();
    loadLocal();

    WSService().connect(widget.user, (data) async {
      final msg = jsonDecode(data);

      if (msg["type"] == "users") {
        setState(() {
          users = List<String>.from(msg["users"])
            ..remove(widget.user);
        });
      }

      if (msg["type"] == "friend_request") {
        setState(() => requests.add(msg["from"]));
        saveLocal();
      }

      if (msg["type"] == "request_accepted") {
        setState(() => friends.add(msg["from"]));
        saveLocal();
      }
    });
  }

  Future<void> loadLocal() async {
    final sp = await SharedPreferences.getInstance();
    friends = sp.getStringList("friends") ?? [];
    requests = sp.getStringList("requests") ?? [];
    setState(() {});
  }

  Future<void> saveLocal() async {
    final sp = await SharedPreferences.getInstance();
    sp.setStringList("friends", friends);
    sp.setStringList("requests", requests);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.user)),
      body: Column(
        children: [
          Text("Users"),
          ...users.map((u) => ListTile(
            title: Text(u),
            trailing: IconButton(
              icon: Icon(Icons.person_add),
              onPressed: () {
                WSService().send({
                  "type": "friend_request",
                  "from": widget.user,
                  "to": u
                });
              },
            ),
          )),

          Divider(),
          Text("Requests"),
          ...requests.map((r) => ListTile(
            title: Text(r),
            trailing: IconButton(
              icon: Icon(Icons.check),
              onPressed: () {
                WSService().send({
                  "type": "accept_request",
                  "from": widget.user,
                  "to": r
                });
                friends.add(r);
                requests.remove(r);
                saveLocal();
                setState(() {});
              },
            ),
          )),
        ],
      ),
    );
  }
}
