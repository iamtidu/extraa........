import 'package:shared_preferences/shared_preferences.dart';

class Storage {
  static Future<SharedPreferences> _prefs() async =>
      await SharedPreferences.getInstance();

  static Future<List<String>> getUsers() async {
    final p = await _prefs();
    return p.getStringList("users") ?? [];
  }

  static Future<void> saveUsers(List<String> users) async {
    final p = await _prefs();
    await p.setStringList("users", users);
  }

  static Future<void> saveRequest(String key, String value) async {
    final p = await _prefs();
    await p.setString(key, value);
  }

  static Future<String?> getRequest(String key) async {
    final p = await _prefs();
    return p.getString(key);
  }

  static Future<void> removeRequest(String key) async {
    final p = await _prefs();
    await p.remove(key);
  }
}
