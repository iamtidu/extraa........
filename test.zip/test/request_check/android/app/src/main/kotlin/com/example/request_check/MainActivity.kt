package com.example.request_check

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
